const jsforce = require('jsforce');
const fetch = require('node-fetch-retry');
const https = require('https');
const fs = require('fs');
const conn = new jsforce.Connection();
const userName = 'saambrosio@deloitte.it.lmnx';
const password = 'Bancarellona99?';
const securityToken = '00DE0000000JTmI!AQwAQE.5ruD2itLrgJoFOBX5wSXKdYooAV.W_uK98AbhTxR4h1TMZDuhIDe2D5rkFLy6v4rH5DnOCSjEsIGIroZC_GQqqGfy';
const path = require("path");
const objectApiName = 'Apttus_Proposal__Proposal__c';
const waitTime1=1000;
const waitTime2=3000;
/*Account
const objectApiName= 'Account';*/

/*Agreement Line Item 
const objectApiName= 'Apttus__AgreementLineItem__c';*/

/*Agreement Line Item 
const objectApiName= 'Apttus__AgreementLineItem__c';*/

/*Agreement Line Item 
const objectApiName= 'Apttus__AgreementLineItem__c';*/

/*Agreement 
const objectApiName= 'Apttus__APTS_Agreement__c';*/

/*Agreement 
const objectApiName= 'Apttus__APTS_Agreement__c';*/

/*Quote (Proposal) Line Item 
const objectApiName= 'Apttus_Proposal__Proposal__c';*/

/*Quote (Proposal) 
const objectApiName= 'Apttus_Proposal__Proposal_Line_Item__c';*/

/*Contact 
const objectApiName= 'Contact';*/

/*Lead 
const objectApiName= 'Lead';*/

/*Opportunity 
const objectApiName= 'Opportunity';*/

/*Opportunity Product 
const objectApiName= 'OpportunityLineItem';*/

/*Order Oracle 
const objectApiName= 'Order__c';*/

/*Order SAP 
const objectApiName= 'Order__c';*/

/*Order Line Item Oracle 
const objectApiName= 'Order_Line_Item__c';*/

/*Order Line Item SAP 
const objectApiName= 'Order_Line_Item__c';*/

/*Installed Product (Oracle) 
const objectApiName= 'SVMXC__Installed_Product__c';*/

/*Service Contract  
const objectApiName= 'SVMXC__Service_Contract__c ';*/

/*Service Contract Line Item 
const objectApiName= 'SVMXC__Service_Contract_Products__c';*/

/*Oracle Site (Location) 
const objectApiName= 'SVMXC__Site__c';*/

/*SAP Site  
const objectApiName= 'SVMXC__Site__c';*/

const baseDir='salesforce'
const queryObjectApiName='Attachment'
const query = 'SELECT id, name, parentId, bodyLength FROM '+queryObjectApiName+' WHERE parentId IN (SELECT id from '+objectApiName+')';
const batchSize=500;

try {
    // first check if the directory already exists
    if (!fs.existsSync('./'+baseDir+'/'+objectApiName)) {
        fs.mkdirSync('./'+baseDir+'/'+objectApiName)
        console.log('Directory is created.')
    } else {
        console.log('Directory already exists.')
    }
} catch (err) {
    console.log(err)
}

//connect to sf
const retrieveData = async function () {
    if(conn){
        const dataList=[];
        console.log('retrieveData Method: ');
        console.log('Query: '+query);
        await conn.bulk.query(query)
        .on('record', function(rec) { dataList.push(rec); })
        .on('error', function(err) { console.error(err); })
        .on('end',async function(){
            console.log('datasize '+dataList.length);
            await createDirStucture(dataList);
            await processData(dataList);
        });
        /*conn.query(query, async function(err,result){
            if(err){
                console.log('Error when querying:\n'+err)
            }
            let response=result.records;
            let listAttch=[];
            console.log('returned: '+response.length);
            response.forEach((singleObject) => {
                listAttch.push({
                    "id":singleObject.Id,
                    "FileName":singleObject.Name,
                    "ParentId":singleObject.ParentId,
                    "BodyLength":singleObject.BodyLength
                });
                createDirStucture(listAttch);
            });
            
        });*/
    }
};

const createDirStucture = async function(recordList) {
    if(recordList){
        recordList.forEach((rec) => {
            try {
                // first check if the directory already exists
                if (!fs.existsSync('./'+baseDir+'/'+objectApiName+'/' + rec.ParentId)) {
                    fs.mkdirSync('./'+baseDir+'/'+objectApiName+'/'+ rec.ParentId)
                    //console.log('Directory is created.')
                } else {
                    //console.log('Directory already exists.')
                }
            } catch (err) {
                console.log('error while creating: '+rec.Id);
            }
        });
    }
}

const processData = async function(dataList){
    if(dataList){
        const chunks=dataList.length/batchSize;
        console.log('process data: ');
        console.log('there are '+dataList.length+' documents to process');
        console.log('they will be process in '+batchSize+' at time');
        console.log('there will be '+chunks+' batches');
        console.log('process starts at: '+new Date());
        console.log('it will take approximately: (min) '+batchSize*(waitTime1/1000)/60+' for each batch to be processed');
        console.log('it will take approximately: (min) '+(((batchSize*(waitTime1/1000))+(waitTime2/1000))*chunks)/60+' for entire execution');

        let currentBatch=0;
        while(currentBatch < chunks){
            console.log('batch n#'+currentBatch+' out of '+chunks+' Starts at: '+new Date());
            for(let index=batchSize*currentBatch; index<(currentBatch+1)*batchSize && index<dataList.length; index++){
                let singleFile=dataList[index];
                //console.log('single file: '+JSON.stringify(singleFile));
                await downloadAndSave(singleFile);
                await sleep(waitTime1);
            }
            console.log('batch n#'+currentBatch+' out of '+chunks+' Ends at: '+new Date());
            currentBatch++;
            await sleep(waitTime2);
        }
    }
}

const downloadAndSave = async function(singleFile){
    try {
        if (!fs.existsSync('./'+baseDir+'/'+objectApiName+'/' + singleFile.ParentId)) {
            fs.mkdirSync('./'+baseDir+'/'+objectApiName+'/'  + singleFile.ParentId)
        } else {
        }
    } catch (err) {
    }
    var fileOut = fs.createWriteStream('./'+baseDir+'/'+objectApiName+'/' + singleFile.ParentId + '/' + singleFile.Name)
    await conn.sobject(queryObjectApiName).record(singleFile.Id).blob("Body").pipe(fileOut)
    
}       

const sleep= function(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }

conn.login(userName,password, async function(err, res){
    if(err){
        //error with connection
        console.log('Error while connecting to org\n'+err);
    }

    console.log('Connection info:');
    console.log('Token: '+conn.accessToken);
    console.log('Instance url: '+conn.instanceUrl);
    console.log('User: '+res.id);
    console.log('Org Id: '+res.organizationId);
    console.log('Execution started at: '+new Date());
    await retrieveData();
    await console.log('Execution end at: '+new Date());
});

