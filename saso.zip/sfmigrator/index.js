const jsforce = require('jsforce');

const axios = require('axios');

 

// LOGIN VARIABLES = SalesforceUsername, salesforcePassword, salesforceSecurityToken

// CONNECTION VARIABLES salesforceLoginUrl, salesforceAttachmentObject, sharepointSiteUrl,sharepointLibraryName

 

 

// Salesforce and SharePoint API credentials and URLs

const salesforceUsername = 'saambrosio@deloitte.it.lmnx';

const salesforcePassword = 'Bancarellona99?';

const salesforceSecurityToken = '';

const salesforceLoginUrl = 'https://login.salesforce.com';

const salesforceAttachmentObject = 'Attachment';

 

const sharepointSiteUrl = 'https://resources.deloitte.com/sites/TestSFmigrator';

const sharepointLibraryName = 'Shared Documents/General'; // Customize this based on your SharePoint setup

const responseGet =  axios.get(`https://resources.deloitte.com/sites/TestSFmigrator/_api/web/GetFolderByServerRelativeUrl('Shared Documents/Fold')/Files`)

if (responseGet.status === 200) {

    console.log('this is respo: '+responseGet);

  } else {

    console.error(`error`);

  }

// Initialize Salesforce connection

/*const sfConn = new jsforce.Connection({

  loginUrl: salesforceLoginUrl,

});

 

// Authenticate with Salesforce

sfConn.login(salesforceUsername, salesforcePassword + salesforceSecurityToken, (err, userInfo) => {

  if (err) {

    console.error('Error authenticating with Salesforce:', err);

    return;

  }

 

  // Query Salesforce attachments

  const query = `SELECT Id, Name, Body, ParentId FROM ${salesforceAttachmentObject} LIMIT 2`;

  sfConn.query(query, (queryErr, result) => {

    if (queryErr) {

      console.error('Error querying Salesforce attachments:', queryErr);

      return;

    }

 

    // Iterate through Salesforce attachments and upload to SharePoint

    result.records.forEach(async (attachment) => {

      const attachmentData = {

        filename: attachment.Name,

        body: attachment.Body,

      };

 

      try {

        // Upload the attachment to SharePoint

        const sharepointUploadUrl = `${sharepointSiteUrl}/_api/web/GetFolderByServerRelativeUrl('${sharepointLibraryName}')/Files/add(url=testfile.docx,overwrite=true)`;

        const response = await axios.post(sharepointUploadUrl, attachmentData.body, {

          headers: {

            'Accept': 'application/json;odata=verbose',

            'Content-Type': 'application/octet-stream',

          },

        });

 

        if (response.status === 200) {

          console.log(`Uploaded ${attachmentData.filename} to SharePoint`);

        } else {

          console.error(`Failed to upload ${attachmentData.filename} to SharePoint`);

        }

      } catch (uploadErr) {

        console.error('Error uploading attachment to SharePoint:', uploadErr);

      }

    });

  });

});*/