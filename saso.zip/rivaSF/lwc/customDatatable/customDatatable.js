import { LightningElement, api, wire } from "lwc";
import executeQuery from "@salesforce/apex/LWCUtilitiesController.executeQuery";
import getColumns from "@salesforce/apex/LWCUtilitiesController.getColumns";
import updateLines from "@salesforce/apex/LWCUtilitiesController.updateLines";
import { refreshApex } from '@salesforce/apex';
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
export default class CustomDatatable extends LightningElement {

	@api inlineEditEnabled;
	@api queryRecordsToShow;
	@api sObject;
	@api columns;
	@api records;
	@api title;
	@api spinnerShow;
	@api draftValues;
	@api columnEditFields;
	@api iconName;
	refreshHook;

	_columnsFields;
	_columnFieldLabels;


	@api get columnFields(){
		return this._columnsFields;
	}

	set columnFields(value){
		//this._columnsFields = value.split(";");
		this._columnsFields=value;
	}

	@api get columnFieldLabels(){
		return this._columnFieldLabels;
	}

	set columnFieldLabels(value){
		this._columnFieldLabels = value.split(";");
	}

	@wire(executeQuery,{SobjectType:'$sObject',query:'$queryRecordsToShow'})
	retrieveData(data,error){
		this.refreshHook = data;
		if(data){
			console.log('data:: '+JSON.stringify(data));
			this.records=data?.data;
		}else{
			console.error('errorr:: '+JSON.stringify(error));
		}
	}

	@wire(getColumns,{fieldList:'$columnFields',sobjectType:'$sObject'})
	retrieveColumns(data,error){
		if(data){
			console.log('column data:: '+JSON.stringify(data));
			let flatColumns=data?.data;
			let updatedColumns = [];
			if(this.inlineEditEnabled){
				flatColumns.forEach(element => {
					if(!this.columnEditFields.split(';').includes(element.fieldName)){
						updatedColumns.push(element);
					}else{
						let single = JSON.parse(JSON.stringify(element));
						single.editable = true;
						updatedColumns.push(single);
					}
				});
				this.columns=updatedColumns;
			}else{
				this.columns=flatColumns;
			}
			
		}else{
			console.error('error:: '+JSON.stringify(error))
		}
	}

	connectedCallback(){
		if(this.columnFields && this.columnFieldLabels){
			//this.createColumnsArray();
		}
		this.spinnerShow = false;
	}

	createColumnsArray(){
		let columnArray=[];
		
		for(let i=0; i < this._columnsFields.length; i++){
			let apiname=this._columnsFields[i];
			let label=this._columnFieldLabels[i];
			let singleColumn={
				label:label,
				fieldName:apiname
			}
			columnArray.push(singleColumn);
		}

		this.columns=columnArray;
	}

	async handleSave(event){
		this.spinnerShow=true;
		console.log('handleSave:: '+JSON.stringify(event.detail));
		let draftValues = event.detail.draftValues;
		let toUpdate = [];
		draftValues.forEach(draft => {
			let draftRowId = draft.id.split('-')[1];
			let recordToUpdate = JSON.parse(JSON.stringify(this.records[draftRowId]));
			console.log('rowId: '+draftRowId+'\nrecord: '+JSON.stringify(recordToUpdate));
			let draftWithId = JSON.parse(JSON.stringify(draft));
			delete draftWithId.id;
			draftWithId.Id = recordToUpdate.Id;
			console.log('rowId: '+draftRowId+'\nrecordAfter: '+JSON.stringify(draftWithId));
			toUpdate.push(draftWithId);
		})
		try {
			console.log('toUpdateList:: '+JSON.stringify(toUpdate));
			if(toUpdate.length > 0){
				let updateResult = await updateLines({lines:toUpdate});
				console.log('updateResult: '+JSON.stringify(updateResult));
				if(updateResult){
					this.spinnerShow = false;
					this.showToast('Update Successful', 'All changes have been saved successfully', 'success');
					this.draftValues = null
					refreshApex(this.refreshHook);
				}else{
					this.showToast('Update Failed', 'An error occurred', 'error');
				}
			}
		} catch (error) {
			console.error('An error occurred while updating lines: '+JSON.stringify(error));
		}
	}

	showToast(label, msg, type) {
        const event = new ShowToastEvent({
            title: label,
            message: msg,
            variant: type,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }
}