import { LightningElement, api } from "lwc";
import {
  ShowToastEvent
} from 'lightning/platformShowToastEvent';
import LightningAlert from 'lightning/alert'
import Conf_Product_Code from '@salesforce/label/c.Conf_Product_Code';
import Conf_Product_Name from '@salesforce/label/c.Conf_Product_Name';
import Conf_Pricing_Type from '@salesforce/label/c.Conf_Pricing_Type';
import Conf_Unit_Of_Measure from '@salesforce/label/c.Conf_Unit_Of_Measure';
import Conf_Category_Code from '@salesforce/label/c.Conf_Category_Code';
import Conf_Category_Name from '@salesforce/label/c.Conf_Category_Name';
import Conf_Product from '@salesforce/label/c.Conf_Product';
import Conf_Sales_Price from '@salesforce/label/c.Conf_Sales_Price';
import Conf_Discount_Percentage from '@salesforce/label/c.Conf_Discount_Percentage';
import Conf_Average_Extra_Price from '@salesforce/label/c.Conf_Average_Extra_Price';
import Conf_Final_Price from '@salesforce/label/c.Conf_Final_Price';
import Conf_Quantity from '@salesforce/label/c.Conf_Quantity';
export default class SalesAgreementProductConfiguration extends LightningElement {
  @api
  records;
  @api
  draftRecords;
  @api
  productLevel;
  @api businessCountry
  draftValues;

  discountAvailableProducts=['85','PA'];

  columns = [
    {
      label: "Product",
      fieldName: "Name",
      hideDefaultActions: true,
      wrapText: true
    },
    {
      label: 'Pricing Type',
      fieldName: 'Pricing_Type__c',
      hideDefaultActions: true,
      editable:true
    },
    {
      label: "List Price",
      fieldName: "ListPrice",
      type: "currency",
      editable: false,
      hideDefaultActions: true
    },
    {
      label: "Initial Total Quantity",
      fieldName: "InitialPlannedQuantity",
      type: "number",
      editable: true,
      hideDefaultActions: true,
      cellAttributes: {
        required: true
      }
    },
    {
      label: "Sales Price",
      fieldName: "SalesPrice",
      type: "currency",
      editable: true,
      hideDefaultActions: true
    },
    {
      label: "Discount Percentage",
      fieldName: "DiscountPercentage",
      type: "number",
      editable: true,
      hideDefaultActions: true
    },
    {
      label: "Planned Amount",
      fieldName: "InitialPlannedAmount",
      type: "currency",
      editable: true,
      hideDefaultActions: true
    }
  ];

  data = [
    {
      Name: "Vergelle",
      ListPrice: 10,
      SalesPrice: 10
    }
  ];

  connectedCallback() {
    console.log("product level: " + this.productLevel);
    console.log("business country: "+this.businessCountry)
    let discountEditable=this.businessCountry === 'FRA' && this.records.filter(el => this.discountAvailableProducts.includes(el.Product_Code__c)).length > 0;
    if (this.productLevel === "PRODUCT") {
      this.columns = [
        {
          label: Conf_Product_Name,
          fieldName: "Name",
          hideDefaultActions: true,
          wrapText: true
        },
        {
          label: Conf_Pricing_Type,
          fieldName: 'Pricing_Type__c',
          hideDefaultActions: true,
          editable:true,
          wrapText: true
        },
        {
          label: Conf_Quantity,
          fieldName: "InitialPlannedQuantity",
          type: "number",
          editable: true,
          hideDefaultActions: true,
          cellAttributes: {
            required: true
          }
        },
        {
          label: Conf_Unit_Of_Measure,
          fieldName: "Unit_of_Measure__c",
          editable: false,
          hideDefaultActions: true
        },
        {
          label: Conf_Sales_Price,
          fieldName: "SalesPrice",
          type: "currency",
          editable: true,
          hideDefaultActions: true
        },
        {
          label: Conf_Discount_Percentage,
          fieldName: "DiscountPercentage",
          type: "number",
          editable: discountEditable,
          displayReadOnlyIcon:discountEditable,
          hideDefaultActions: true
        },
        {
          label: Conf_Average_Extra_Price,
          fieldName: "Average_Extra_Price__c",
          type: "currency",
          editable: true,
          hideDefaultActions: true
        },
        {
          label: Conf_Final_Price,
          fieldName: "Final_Price__c",
          type: "currency",
          editable: false,
          hideDefaultActions: true
        }/*,
        {
          label: "Planned Amount",
          fieldName: "InitialPlannedAmount",
          type: "currency",
          editable: false,
          hideDefaultActions: true
        }*/
      ];
    } else {
      this.columns = [
        {
          label: Conf_Category_Name,
          fieldName: "Name",
          hideDefaultActions: true,
          wrapText: true
        },
        {
          label: Conf_Pricing_Type,
          fieldName: 'Pricing_Type__c',
          hideDefaultActions: true,
          editable:true,
          wrapText: true
        },
        {
          label: Conf_Quantity,
          fieldName: "InitialPlannedQuantity",
          type: "number",
          editable: true,
          hideDefaultActions: true
        },
        {
          label: Conf_Unit_Of_Measure,
          fieldName: "Unit_of_Measure__c",
          editable: false,
          hideDefaultActions: true
        },
        {
          label: Conf_Sales_Price,
          fieldName: "SalesPrice",
          type: "currency",
          editable: true,
          hideDefaultActions: true
        },
        {
          label: Conf_Discount_Percentage,
          fieldName: "DiscountPercentage",
          type: "number",
          editable: discountEditable,
          displayReadOnlyIcon:discountEditable,
          hideDefaultActions: true
        },
        {
          label: Conf_Average_Extra_Price,
          fieldName: "Average_Extra_Price__c",
          type: "currency",
          editable: true,
          hideDefaultActions: true
        },
        {
          label: Conf_Final_Price,
          fieldName: "Final_Price__c",
          type: "currency",
          editable: false,
          hideDefaultActions: true
        }/*,
        {
          label: "Planned Amount",
          fieldName: "InitialPlannedAmount",
          type: "currency",
          editable: false,
          hideDefaultActions: true
        }*/
      ];
    }
    if (this.records) {
      let tempData=JSON.parse(JSON.stringify(this.records));
      tempData.forEach(el => {
        if(this.discountAvailableProducts.includes(el.Product_Code__c)){
          //07-11-2024 - saambrosio@deloitte.it - START:: fix price for other country
          el.SalesPrice = this.businessCountry === 'FRA' ? 1170 : null;
          //07-11-2024 - saambrosio@deloitte.it - END:: fix price for other country
        }
      })
      this.data = tempData;
      this.draftRecords = JSON.parse(JSON.stringify(this.data));
      this.draftValues = JSON.parse(JSON.stringify(this.data));
      console.log(this.records);
    } else {
      console.log("no records found");
    }
  }

  handleCellChange(event) {
    console.log("dV: " + JSON.stringify(this.draftValues));
    console.log("change" + JSON.stringify(event.detail.draftValues[0]));
    console.log(this.data);
    let rowId = event.detail.draftValues[0].id.replace("row-", "") * 1;
    let columnName = "";
    for (let prop in event.detail.draftValues[0]) {
      if (prop !== "id") {
        columnName = prop;
        break;
      }
    }
    let columnValue = event.detail.draftValues[0][columnName];
    if(columnName === 'DiscountPercentage' && !this.discountAvailableProducts.includes(this.draftValues[rowId].Product_Code__c) && columnValue.length > 0){
      console.log('Prod Code:'+this.draftValues[rowId].Product_Code__c);
      this.showToast('Error!','Discount is not available for product: '+this.draftValues[rowId].Name+'. Please blank out the field','error');
      columnValue=null
    }
    this.draftRecords[rowId][columnName] = columnValue;
    console.log("10");
    let tempData = JSON.parse(JSON.stringify(this.draftRecords[rowId]));
    console.log(typeof tempData.DiscountPercentage);
    console.log(typeof tempData.SalesPrice);
    console.log(typeof tempData.InitialPlannedQuantity);
    console.log('avg extra price:: '+tempData.Average_Extra_Price__c);
    /*let amount =
      (parseFloat(tempData.SalesPrice) -
        (parseFloat(tempData.SalesPrice) *
          parseFloat(
            tempData.DiscountPercentage == null
              ? 0
              : tempData.DiscountPercentage
          )) /
          100) *
      parseInt(tempData.InitialPlannedQuantity);
    */
    let fullPrice=parseFloat(tempData.SalesPrice || 0)+parseFloat(tempData.Average_Extra_Price__c || 0);
    let discountAmount=parseFloat(fullPrice) * parseFloat(tempData.DiscountPercentage || 0) / 100;
    let discountedAmount=parseFloat(fullPrice)-parseFloat(discountAmount || 0);
    console.log('fullprice:: '+fullPrice);
    console.log('discountAmount:: '+discountAmount);
    console.log('discountedAmount:: '+discountedAmount);
    let amount=parseFloat(discountedAmount || 0)*parseInt(tempData.InitialPlannedQuantity || 0);
    console.log("tempa data: " + amount);
    tempData.Final_Price__c = discountedAmount;
    tempData.InitialPlannedAmount = amount;
    console.log("11");
    this.draftValues[rowId] = tempData;
    this.data = this.draftValues;
    this.draftRecords = this.draftValues;
    //this.data=tempData.map((value)=>({...value}))
    console.log("12");
    console.log(this.draftRecords);
  }

  showToast(label, msg, type) {
    const event = new ShowToastEvent({
        title: label,
        message: msg,
        variant: type,
        mode: 'dismissable'
    });
    this.dispatchEvent(event);
}

  onsave(event) {
    console.log("test save");
  }
}