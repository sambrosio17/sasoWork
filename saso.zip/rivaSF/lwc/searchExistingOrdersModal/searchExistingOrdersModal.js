import { api,track } from "lwc";
import LightningModal from 'lightning/modal';
import { NavigationMixin } from 'lightning/navigation';
import Toast from 'lightning/toast'
import searchExistingOrders from '@salesforce/apex/CloneExistingOrderController.searchExistingOrders';


export default class SearchExistingOrdersModal extends NavigationMixin(LightningModal) {

    @api salesAgreementId;
    @api customerOrderId;
    @api dateFrom;
    @api dateTo;
    @api shipmentSite;
    @api deliveryAddress;
    @api processedOrders = [];
    @api orderKeysOrder = [];
    @api lineItemsKeysOrder = [];
    @api selectedOrderId;
    @track searchPerformed = false;
    

    get showNoResultsMessage() {
        return this.searchPerformed && this.processedOrders.length === 0 ;
    }

    shipmentLocationFilter = {
        criteria: [
            {
                fieldPath: 'LocationType',
                operator: 'eq',
                value: 'Site',
            },
            {
                fieldPath: 'LocationType',
                operator: 'eq',
                value: 'Warehouse'
            }
        ],
        filterLogic: '(1 OR 2)',
    };

    handleCustomerOrderIdChange(event) {
        console.log('customerOrderId => '+event.target.value);
        this.customerOrderId = event.target.value;
    }

    handleDateFromChange(event) {
        this.dateFrom = event.target.value;
    }

    handleDateToChange(event) {
        this.dateTo = event.target.value;
    }

    handleShipmentSiteChange(event) {
        console.log('ShipmentSiteId => '+event.detail.recordId);
        this.shipmentSite = event.detail.recordId;
    }

    handleDeliveryAddressChange(event) {
        console.log('DeliveryAddressId => '+event.detail.recordId);
        this.deliveryAddress = event.detail.recordId;
    }

    handleSearch() {

        
        this.searchPerformed = false;

        const searchCriteria = {
            salesAgreementId: this.salesAgreementId,
            dateFrom: this.dateFrom,
            dateTo: this.dateTo,
            shipmentSiteId: this.shipmentSite,
            deliveryAddressId: this.deliveryAddress,
            customerOrderId: this.customerOrderId
        };

        console.log('searchCriteria =>'+JSON.stringify(searchCriteria));

        searchExistingOrders({ searchObj: searchCriteria })
                .then(result => {
                    console.log('processedOrders =>'+JSON.stringify(result));
                    if(result.orders.length > 0 ){
                        this.processedOrders = this.preprocessOrders(result.orders, result.orderKeysOrder, result.lineItemsKeysOrder);
                        this.orderKeysOrder = result.orderKeysOrder;
                        this.lineItemsKeysOrder = result.lineItemsKeysOrder;
                    }else{
                        this.processedOrders  = [];
                    }
                    
                    this.searchPerformed = true;
                })
                .catch(error => {
                    console.error('Error fetching orders: ', error);
                    this.searchPerformed = true;
                });
    }

    preprocessOrders(orders, orderKeysOrder, lineItemsKeysOrder) {
        return orders.map((order, orderIndex) => {
            const orderDetails = orderKeysOrder.map(key => ({ key, value: order.orderLine[key] }));
            const lineItems = order.lineItems.map((item, itemIndex) => {
                const itemDetails = lineItemsKeysOrder.map(key => ({ key, value: item[key] }));
                return { id: `${orderIndex}-${itemIndex}`, itemDetails };
            });

            return {
                orderId: order.orderLine['Order ID'],
                orderHeaderLine: 'Order '+orderKeysOrder.map(key => orderDetails.find(detail => detail.key === key).value).join(' | ')+' € ',
                orderDetails,
                lineItems,
                originalLineItems:order.lineItems
            };
        });
    }
    
    handleSave(event){
        let title=this.value;
        console.log('handleSave-modal::'+title);
        let body=this.textareaValue;
        console.log('handleSave-modal::'+body);
        let icon=this.options.filter(el => el.value == this.value)[0].icon
        console.log('handleSave-modal::'+icon);
        let note={
            title:title,
            body:body,
            icon:icon
        }
        console.log('handleSave-modal::'+note);
        let noteEvent=new CustomEvent("modalsave",{detail:note});
        this.dispatchEvent(noteEvent);
        this.close();
    }

    connectedCallback(){
        this.buttonState=false;
    }

    showToast(label,msg,type){
        Toast.show({
            label:label,
            message:msg,
            mode:'dismissible',
            variant:type
        },this);
    }


    handleCloneOrder(event) {
        const orderId = event.currentTarget.dataset.orderId;
        this.selectedOrderId = orderId;
        console.log('orderId => '+this.selectedOrderId);
        console.log('handleCloneOrder::');
        this.sendEventToParent();
        console.log('handleCloneOrder-2::');
        
    }

    sendEventToParent() {
        const cloneEvent = new CustomEvent('cloneexistingorder', {
            detail: {
                selectedOrderId: this.selectedOrderId
            }
        });
        this.dispatchEvent(cloneEvent);
        this.close();
        console.log('Event sent to parent: ' + JSON.stringify(cloneEvent.detail));
    }

    orderHeaderLabel(order) {
        return this.orderKeysOrder.map(key => order.orderDetails.find(detail => detail.key === key).value).join(' | ');
    }

    get orderItemsColumns() {
        console.log('lineItemsKeysOrder:', this.lineItemsKeysOrder);
        let orderItemsColumns = this.lineItemsKeysOrder.map(key => ({ label: key, fieldName: key, type: 'text' }));
        console.log('orderItemsColumns: '+JSON.stringify(orderItemsColumns));
        return orderItemsColumns;
    }

}