/* eslint-disable @lwc/lwc/no-api-reassignments */
import { LightningElement, api, track, wire } from "lwc";
import getOngoingOrders from "@salesforce/apex/CustomerOngoingOrdersController.getOngoingOrders";

// eslint-disable-next-line @lwc/lwc/no-leading-uppercase-api-name
export default class CustomerOngoingOrders extends LightningElement {
	@api parentId;
	@api recordId;
	@api selectedProduct='all';
	
	ongoingOrderFullList;
	ongoingOrderComposedList;
	unfilteredSearchList
	_currentList='all';
	@api searchText="";
	@api _ongoingOrderShowList;

	@track productOptions = [{label:'ALL',value:'all'}]
	@api groupTotals = [];

	@wire(getOngoingOrders,{accountId: '$recordId'})
	getOrders(data,error){
		if(data){
			console.log('Data Found!'+this.recordId);
			console.log(JSON.stringify(data))
			this.ongoingOrderFullList = data?.data;
			
			let composedList = [];
			let processedFullList={}

			for(let orderList in this.ongoingOrderFullList){
				let tempList = this.calculateParentTotals(this.ongoingOrderFullList[orderList]);
				this.buildOptions(orderList,orderList);
				processedFullList[orderList] = tempList;
				composedList = composedList.concat(tempList);
			}

			this.ongoingOrderFullList = processedFullList;
			this.ongoingOrderComposedList = composedList;
			this._ongoingOrderShowList = composedList;
			this.unfilteredSearchList = composedList;

			console.log(JSON.stringify(this._ongoingOrderShowList))
			this.groupTotals = this.calculateGroupTotal(this._ongoingOrderShowList);
		}else{
			console.error('An error occurred while getting orders: '+JSON.stringify(error));
		}
	}

	buildOptions(label,value){
		let partial = JSON.parse(JSON.stringify(this.productOptions));
		partial.push({label:label.toUpperCase(),value:value});
		this.productOptions = partial;
	}

	handleSelectionChange(event){
		console.log('handleSelectionChange.event: '+JSON.stringify(event.detail));
		let key = event.detail.value;
		this._currentList = key;
		if(key === 'all'){
			this._ongoingOrderShowList = this.ongoingOrderComposedList;
			this.unfilteredSearchList = this.ongoingOrderComposedList;
		}else{
			console.log('not ALL:  '+JSON.stringify(this.ongoingOrderFullList[key]))
			this._ongoingOrderShowList = this.ongoingOrderFullList[key];
			this.unfilteredSearchList = this.ongoingOrderFullList[key];
		}
		this.groupTotals = this.calculateGroupTotal(this._ongoingOrderShowList);
		console.log('calculatedTotals:: '+JSON.stringify(this.groupTotals));
		console.log('for key: '+key)
		console.log('handleSelectionChange.list:'+JSON.stringify(this._ongoingOrderShowList));
	}

	calculateParentTotals(orderList){

		let returnList = [];
		for(let order of orderList){
			if(!order.lines || order.lines.lenght == 0)
				continue;
			let initialValue = 0;
			let sumOrderd = Number(order.lines.reduce((acc,curr) => acc+curr.orderedQuantity,initialValue)).toFixed(2);
			let sumShipped = Number(order.lines.reduce((acc,curr) => acc+curr.shippedQuantity,initialValue)).toFixed(2);
			let residual = Number(sumOrderd - sumShipped).toFixed(2);

			let copyOrder = JSON.parse(JSON.stringify(order));
			copyOrder.orderedQuantity = sumOrderd;
			copyOrder.shippedQuantity = sumShipped;
			copyOrder.residualQuantity = residual;

			returnList.push(copyOrder);
		}

		console.log('processed list: '+JSON.stringify(returnList));

		return returnList;
	}

	handleExpand(event){
		console.log('handleExpand:')
		console.log('handleExpand.event.target.dataset: '+JSON.stringify(event?.target?.dataset));

		let parentId = event?.target?.dataset?.parent;

		let toggleList = this.template.querySelectorAll('[data-parentId="'+parentId+'"]');
		toggleList.forEach(el => el.classList.toggle('hiddenRow'));

		let root = this.template.querySelector('[data-root="'+parentId+'"]');
		console.log('handleExpand.rott.ariaExpanded: '+root.ariaExpanded);
		root.ariaExpanded=root.ariaExpanded === 'true' ? 'false' : 'true';
		console.log('handleExpand.rott.ariaExpanded: '+root.ariaExpanded);
		console.log('handleExpand.toggleList: '+JSON.stringify(toggleList));
	}

	async handleSearch(event){
		console.log('handleSearch:')
		console.log('handleSearch.currentList: '+this._currentList);
		console.log('handleSearch.event.detail: '+JSON.stringify(event.detail));

		let searchInput = event?.detail?.value;
		this.searchText = searchInput;
		let searchList = this._currentList === 'all' ? this.ongoingOrderComposedList : this.ongoingOrderFullList[this._currentList];
		this._ongoingOrderShowList = [];
		if(!searchInput || searchInput.length < 3){
			this._ongoingOrderShowList = searchList;
		}else if(searchInput.length >=3){
			
			searchInput = searchInput.toUpperCase();
			let filteredList = []
			searchList.forEach(row => {
				if(row.uniqueId.toUpperCase().includes(searchInput)){
					filteredList.push(row);
				}
			})
			this._ongoingOrderShowList = filteredList;
		}
	}

	calculateGroupTotal(list){
		console.log('customerOngoingOrders.calculateGroupTotal:: ');
		console.log('customerOngoingOrders.calculateGroupTotal-availableOptions:: '+JSON.stringify(this.productOptions));

		let calculatedTotals = [];
		this.productOptions.forEach(option => {
			if(option.value.toLowerCase() == 'all'){
				return;
			}
			let filteredListOption = list.filter(parentRow => parentRow.productGroup.toLowerCase() == option.value.toLowerCase());
			let totalOrder = 0;
			let totalShipped = 0;
			let totalResidual = 0;

			if(filteredListOption.length == 0){
				return;
			}
			for(let row of filteredListOption){
				totalOrder += parseFloat(row.orderedQuantity);
				totalShipped += parseFloat(row.shippedQuantity);
				totalResidual += parseFloat(row.residualQuantity);
			}

			calculatedTotals.push({
				groupKey: option.value,
				groupLabel: option.label,
				totalOrder: totalOrder,
				totalShipped: totalShipped,
				totalResidual: totalResidual,
			})
			
		})
		return calculatedTotals;
	}


	//----------CONSTANTS------
	@api COLUMNS = [
		{
			label: 'AS400 Number',
			value: 'orderCode',
			active: true,
			classes: ""
		},
		{
			label: 'Order Number',
			value: 'customerOrderReference',
			active: true,
			classes: ""
		},
		{
			label: 'Product Code',
			value: 'productCode',
			active: false,
			classes: ""
		},
		{
			label: 'Product Name',
			value: 'productName',
			active: true,
			classes: "prodNameColumn"
		},
		{
			label: 'Quality',
			value: 'quality',
			active: true,
			classes: ""
		},
		{
			label: 'Panel',
			value: 'panel',
			active: true,
			classes: ""
		},
		{
			label: 'Diameter',
			value: 'diameter',
			active: true,
			classes: ""
		},
		{
			label: 'Lenght',
			value: 'lenght',
			active: true,
			classes: ""
		},
		{
			label: 'Delivery Date',
			value: 'deliveryDate',
			active: true,
			classes: ""
		},
		{
			label: 'Delivery Point',
			value: 'deliveryPoint',
			active: true,
			classes: ""
		},
		{
			label: 'Orderd Qty (TN)',
			value: 'orderedQuantity',
			active: true,
			classes: ""
		},
		{
			label: 'Shipped Qty (TN)',
			value: 'shippedQuantity',
			active: true,
			classes: ""
		},
		{
			label: 'Residual Qty (TN)',
			value: 'residualQuantity',
			active: true,
			classes: ""
		},
		{
			label: 'Base Price',
			value: 'basePrice',
			active: true,
			classes: ""
		},
		{
			label: 'Extra Price',
			value: 'extraPrice',
			active: true,
			classes: ""
		},
		{
			label: 'Discount (%)',
			value: 'discount',
			active: true,
			classes: ""
		},
		{
			label: 'Final Price',
			value: 'finalPrice',
			active: true,
			classes: ""
		}
	]
}