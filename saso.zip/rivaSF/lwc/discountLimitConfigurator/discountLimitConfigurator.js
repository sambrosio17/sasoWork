import { LightningElement, api, wire } from "lwc";
import SaveButtonLabel from "@salesforce/label/c.SaveButtonLabel"
import MeshDiscountLimitTitle from "@salesforce/label/c.MeshDiscountLimitTitle"
import getConfigurableSettingsByLabel from "@salesforce/apex/LWCUtilitiesController.getConfigurableSettingsByLabel"
import updateConfigurableSettings from "@salesforce/apex/LWCUtilitiesController.updateConfigurableSettings";
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
export default class DiscountLimitConfigurator extends LightningElement {

    label = {
        "saveButton":SaveButtonLabel,
        "componentTitle":MeshDiscountLimitTitle
    }

    @api
    discountValue;
    customSetting;

    @wire(getConfigurableSettingsByLabel,{label:'MeshDiscountLimit'})
    getDefaultValue(data,error){
        if(data){
            console.log('data received:: '+JSON.stringify(data));
            this.customSetting=data?.data;
            this.discountValue=this.customSetting?.Value__c;
        }else{
            console.log('error:: '+JSON.stringify(error));
        }
    }

    handleFieldChange(event){
        console.log('field changed: '+JSON.stringify(event.target?.value));
        this.discountValue=event.target?.value;
        console.log('discount value:: '+this.discountValue);
    }

    async handleSave(event){
        console.log('handling save');
        try {
            if(this.discountValue==this.customSetting?.Value__c){
                console.log('no updated needed')
                this.showToast('Success!','Limit updated','success');
            }else{
                let cs=JSON.parse(JSON.stringify(this.customSetting));
                cs.Value__c=this.discountValue;
                this.customSetting=cs;
                console.log('update cs: '+JSON.stringify(this.customSetting))
                const result=await updateConfigurableSettings({cs:this.customSetting});
                if(result && result == 'OK'){
                    console.log('Updated with success');
                    this.showToast('Success!','Limit updated','success');
                }else{
                    console.error('errorrr');
                    this.showToast('Error!','An error occurred while updating limit','error');
                }
            }
        } catch (error) {
            console.error('ERROR occurred:: '+JSON.stringify(error));
        }
    }

    showToast(label, msg, type) {
        const event = new ShowToastEvent({
            title: label,
            message: msg,
            variant: type,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }

}