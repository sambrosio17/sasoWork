import { LightningElement, api } from "lwc";
export default class ExperienceSiteTest extends LightningElement {
	@api userId;
	@api accountId;
}