import { LightningElement,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { FlowNavigationNextEvent, FlowNavigationFinishEvent } from 'lightning/flowSupport';

export default class ShowToast extends LightningElement {

    @api mode;
    @api variant;
    @api message;
    @api title;

    @api
    availableActions = [];

    connectedCallback(){
        this.handleShowToast();
        this.handleClose();
    }

    handleShowToast(){
        const event = new ShowToastEvent({
            title: this.title,
            mode: this.mode,
            variant: this.variant,
            message: this.message
        });
        this.dispatchEvent(event);

    }

    handleClose(){
         // Check if FINISH is allowed on this screen
         if (this.availableActions.find((action) => action === 'FINISH')) {
            const navigateFinishEvent = new FlowNavigationFinishEvent();
            this.dispatchEvent(navigateFinishEvent);
        }
        // check if NEXT is allowed on this screen
        if (this.availableActions.find((action) => action === 'NEXT')) {
            const navigateNextEvent = new FlowNavigationNextEvent();
            this.dispatchEvent(navigateNextEvent);
        }
        
    }

}