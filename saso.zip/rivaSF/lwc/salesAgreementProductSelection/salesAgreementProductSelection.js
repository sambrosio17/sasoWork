import {
  LightningElement,
  api,
  wire
} from 'lwc';
import getFilteredCategories from '@salesforce/apex/SalesAgreementConfiguratorController.getFilteredCategories';
import refreshApex from '@salesforce/apex';
import {
  FlowNavigationFinishEvent,
  FlowNavigationNextEvent
} from 'lightning/flowSupport';
import LightningAlert from 'lightning/alert'
export default class SalesAgreementProductSelection extends LightningElement {

  disableState = false;
  loadingSearchState = false;
  @api
  records;
  @api
  selectedRows;
  @api
  productLevel;
  @api
  recordId;
  @api
  metadataRecords;
  @api
  locationId;
  @api
  excluded;
  @api
  countOfProducts;
  /*@wire(getFilteredCategories, {
    locationId: locationId,
    excluded: this.excluded
  })
  categories(
    data,
    error
  ) {
    if (data) {
      this.data = data;
    } else {
      console.log('nodata');
    }
  }*/
  showLocation = false;
  data = [{
      name: 'Billette',
      ProductCode: '10',
      unitPrice: '150'
    },
    {
      name: 'Vergelle',
      ProductCode: '12',
      unitPrice: '30.50'
    }
  ];
  columns = [{
      label: 'Product Name',
      fieldName: 'Name'
    },
    {
      label: 'Product Code',
      fieldName: 'ProductCode'
    },
    {
      label: 'List Price',
      fieldName: 'UnitPrice',
      type: 'currency'
    }
  ]

  async handleLocationChange(event) {
    console.log('event:: ' + event.target.value);
    console.log('count:: ' + parseInt(this.countOfProducts,10));
    if (this.locationId != event.target.value && parseInt(this.countOfProducts,10) > 0) {
      console.log('inner if');
      this.triggerAlert('Remove existing products before changing Location', 'warning');
    }
    if(!event.target.value){
      this.locationId = event.target.value;
      this.categories = [];
      this.data = [];
      this.result = [];
    }else{
      this.locationId = event.target.value;
      this.getCategories();
    }
    /*if(event.target.value.length <= 0)
        return;*/
    
  }



  connectedCallback() {
    console.log('loc:' + this.locationId);
    console.log('c: ' + this.excluded);
   
    if (this.productLevel === 'PRODUCT') {
      this.columns = [{
          label: 'Product Code',
          fieldName: 'ProductCode',
          hideDefaultActions: true
        },
        {
          label: 'Product Name',
          fieldName: 'Product_Name__c',
          hideDefaultActions: true,
          wrapText: true
        },
        {
          label: 'Pricing Type',
          fieldName: 'Pricing_Type__c',
          hideDefaultActions: true
        },
        {
          label: 'Unit of Measure',
          fieldName: 'Unit_of_Measure__c',
          hideDefaultActions: true
        }
        /*{
            label: 'Base Price',
            fieldName: 'UnitPrice',
            type: 'currency',
            cellAttributes: { alignment: 'left' },
            hideDefaultActions: true
        }*/
      ]
    } else {
      this.columns = [{
          label: 'Category Code',
          fieldName: 'Code',
          hideDefaultActions: true
        },
        {
          label: 'Category Name',
          fieldName: 'Name_Translated__c',
          hideDefaultActions: true,
          wrapText: true
        },
        {
          label: 'Pricing Type',
          fieldName: 'Pricing_Type__c',
          hideDefaultActions: true
        },
        {
          label: 'Unit of Measure',
          fieldName: 'Unit_of_Measure__c',
          hideDefaultActions: true
        }
      ]
      this.showLocation = true;
      this.getCategories();

    }
    console.log('this records: '+JSON.stringify(this.records));
    if (this.records) {
      this.data = this.productLevel == 'PRODUCT' ? this.records : this.categories;
      console.log('datass:: '+JSON.stringify(this.data));

    } else {
      console.log('no records found');
      const navigateNextEvent = new FlowNavigationNextEvent();
      this.dispatchEvent(navigateNextEvent);
    }
  }

  handleSearchOnChange(event) {
    if(this.productLevel !== 'PRODUCT' && !this.locationId){
      console.log('no location');
      this.data = [];
    }
    if(this.productLevel === 'PRODUCT' || this.locationId){
    this.loadingSearchState = true;
    let queryTerm = event.target.value.toUpperCase();
    console.log('changing: ' + JSON.stringify(event.target.value));
    console.log('records:: '+this.records);
    let filterByName = this.records.filter(el => el.Name.includes(queryTerm));
    let filterByCode = this.records.filter(el => this.productLevel === 'PRODUCT' ? el.ProductCode.includes(queryTerm) : el.Code.includes(queryTerm));
    console.log('result by Name:: '+JSON.stringify(filterByName))
    console.log('result by Code:: '+JSON.stringify(filterByCode))
    if (filterByCode.length > 0) {
      this.data = filterByCode;
      this.loadingSearchState = false;
    } else if (filterByName.length > 0) {
      this.data = filterByName;
      this.loadingSearchState = false;
    }
  }
  }

  handleRowSelection(event) {
    this.selectedRows = event.detail.selectedRows;
  }

  async triggerAlert(msg, type) {
    await LightningAlert.open({
      message: msg,
      theme: type,
      label: 'Error!',
    });
    const navigateNextEvent = new FlowNavigationNextEvent();
    this.dispatchEvent(navigateNextEvent);
  }

  async renderedCallback(){
    //this.getCategories();
  }

  async getCategories(){
    let locId=this.locationId;
    console.log('getCategories:: '+locId);
    let result=await getFilteredCategories({locationId:locId,excluded:this.excluded});
    console.log('JSON:'+JSON.stringify(result));
    if(result){
      console.log('JSON:'+JSON.stringify(result));
      this.categories=result;
      this.data=result;
      this.records=result;
    }
    if(result.length == 0) {
      console.log('no records found');
      const navigateNextEvent = new FlowNavigationNextEvent();
      this.dispatchEvent(navigateNextEvent);
    }
  }



}