let instance = {};

const setInstanceData = async (orderOverrides) => {
    console.log('set instance');
    instance = orderOverrides;
    console.log('OrderConfiguratorSingleton.orderOverrides::'+JSON.stringify(instance));

};

const getInstanceData = async () => instance;

export { getInstanceData, setInstanceData };