import { LightningElement, api } from "lwc";
import {
	ShowToastEvent
  } from 'lightning/platformShowToastEvent';
export default class DisposableMessage extends LightningElement {
	@api message;
	@api recordId;
	@api objectApiName;
	@api title;
	@api type;

	showToast(label, msg, type) {
		const event = new ShowToastEvent({
			title: label,
			message: msg,
			variant: type,
			mode: 'dismissable'
		});
		this.dispatchEvent(event);
	}


	connectedCallback(){
		console.log('connected::')
		console.log('connected-msg:: '+this.message);

		if(this.message){
			this.showToast(this.title,this.message,this.type);
		}
	}
}