import { LightningElement, api, track } from "lwc";
import LightningModal from 'lightning/modal';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class AddAttachmentModal extends LightningModal {

    @api
    uploadedFiles;
    toBeDeleted;
    @api removed;
    @api
    buttonState;


    mimeToIcon={
        image:'doctype:image',
        pdf:'doctype:pdf',
        word:'doctype:word',
        zip:'doctype:zip',
        ppt:'doctype:ppt',
        csv:'doctype:csv',
        excel:'doctype:excel',
        default:'doctype:attachment'
    }

    @track
    actions = [
        { label: 'Delete', value: 'delete', iconName: 'utility:delete' },
    ];

    handleAction(event){
        let actionType=event.detail.action.value;
        let docId=event.target.dataset.id;
        console.log('addAttachmentModal-handleaction-docId:: '+docId);
        console.log('addAttachmentModal-handleaction-tobedeleted1:: '+JSON.stringify(this.toBeDeleted));
        console.log('addAttachmentModal-handleaction:: '+'prepush');
        if(!this.toBeDeleted || this.toBeDeleted == null)
            this.toBeDeleted=[];
        console.log('addAttachmentModal-handleaction-tobedeleted2:: '+JSON.stringify(this.toBeDeleted));
        let temp=JSON.parse(JSON.stringify(this.toBeDeleted));
        temp.push(docId);
        this.toBeDeleted=temp;
        console.log('addAttachmentModal-handleaction-tobedeleted3:: '+JSON.stringify(this.toBeDeleted));
        console.log('addAttachmentModal-handleaction:: '+'postpush');
        this.uploadedFiles=this.uploadedFiles.filter(el => el.documentId!=docId);
        console.log('addAttachmentModal-handleaction:: '+actionType+docId);
        this.buttonState=!this.uploadedFiles.length>0;
        this.showToast('Success!','File removed!','success');
    }
    
    connectedCallback(){
        this.toBeDeleted=this.removed;
        console.log('addAttachmentModal:: '+JSON.stringify(this.uploadedFiles));
        console.log('addAttachmentModal:: '+JSON.stringify(this.toBeDeleted));
        this.buttonState=true;
        
    }

    handleUploadFinished(event){
        console.log('handleUploadFinished::')
        let uploadedFiles = event.detail.files;
        uploadedFiles.forEach( el => {
            let mimeType=el.mimeType;
            for(let mime in this.mimeToIcon){
                if(mimeType.includes(mime)){
                    el.icon=this.mimeToIcon[mime];
                    break;
                }
            }
            if(!el.icon){
                el.icon=this.mimeToIcon.default;
            }
        })
        //let tempArray=JSON.parse(JSON.stringify(this.uploadedFiles));
        //tempArray.push(...uploadedFiles);
        //uploadedFiles.push(...this.uploadedFiles);
        let fullarray=uploadedFiles.concat(this.uploadedFiles).filter(el => el!=null);
        this.uploadedFiles=fullarray;
        this.buttonState=!this.uploadedFiles.length>0;
        console.log('files: '+JSON.stringify(this.uploadedFiles));
        //alert('No. of files uploaded : ' + uploadedFiles.length);
    }
    handleSave(event){
        console.log('addAttachmentModal-save::');
        let fileList={
            toBeAdded:this.uploadedFiles,
            toBeRemove:this.toBeDeleted
        }
        console.log('addAttachmentModal-save::'+JSON.stringify(fileList));
        let fileEvent=new CustomEvent("modalsave",{detail:fileList});
        this.dispatchEvent(fileEvent);
        this.close();
    }

    showToast(label,msg,type){
        const event = new ShowToastEvent({
            title: label,
            message: msg,
            variant: type,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }
}