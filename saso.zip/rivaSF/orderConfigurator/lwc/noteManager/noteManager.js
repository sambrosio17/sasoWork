import { LightningElement, api, track } from "lwc";
import createNotes from "@salesforce/apex/OrderConfiguratorController.createNotes"
export default class NoteManager extends LightningElement {

     
    
    _notelist;

    @api get notelist(){
        return this._notelist;
    }

    set notelist(value){
        this._notelist=value;
    }

    @track
    actions = [
        { label: 'Delete', value: 'delete', iconName: 'utility:delete' }
        
    ];
 



    connectedCallback(){
        console.log('NoteManager-pre:: '+JSON.stringify(this.notelist));
        this.notelist=[]
        console.log('NoteManager--after:: '+this.notelist);
    }


    @api
    async saveNotes(recordId){
        console.log('NoteManager.saveNotes::')
        let noteToSave=[];
        this.notelist.forEach(el => {
            let single={
                ParentId:recordId,
                Body:el.body,
                Title:el.title,
                IsPrivate:false,
                Id:el?.Id
            };
            noteToSave.push(single);
        })
        let reps=await createNotes({notes:JSON.stringify(noteToSave)});
        console.log('NoteManager.saveNotes--resp::'+reps);
    }

    handleAction(event){
        let actionType=event.detail.action.value;
        let idToRemove=event?.target?.dataset?.id;
        console.log('noteManager.handleAction:: '+actionType);
        console.log('noteManager.handleAction-id:: '+idToRemove);
        let filteredNotes = this.notelist.filter(note => note.uniqueId != idToRemove);
        console.log('noteManager.handleAction-filtered:: '+JSON.stringify(filteredNotes));
        this.notelist = filteredNotes;
        let noteDeletedEvent = new CustomEvent('notedeleted',{detail:filteredNotes});
        this.dispatchEvent(noteDeletedEvent);
    }
    

    
}