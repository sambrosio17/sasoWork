import {
    LightningElement,
    api,
    wire
} from "lwc";
import LightningModal from 'lightning/modal';
import getAvailableEntryByLocation from '@salesforce/apex/OrderConfiguratorController.getAvailableEntryByLocation'
import {
	ShowToastEvent
} from 'lightning/platformShowToastEvent';
import LightningConfirm from 'lightning/confirm';
export default class AddProductModal extends LightningModal {

    productLevel='PRODUCT'

    @api
    label;
    //[ADD,EDIT]
    _viewMode;

    @api
    showAddMode;

    @api get viewMode(){
        return this._viewMode;
    }

    set viewMode(value){
        this._viewMode = value;
        this.showAddMode= this._viewMode=='ADD';
    }

    @api
    pricebookId;
    @api
    locationId;
    @api
    businessCountry;
    @api
    deliveryLocationId;
    //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
    @api
    orderUnitOfMeasure; //this is quantity UM
    @api
    priceUnitOfMeasure; //this is price UM
    //29-10-2024 - saambrosio@deloitte.it - END:: Managing different unit of measure for BEL and DEU
    @api
    columns = [{
            label: "Product Code",
            fieldName: "ProductCode",
            hideDefaultActions: true
        },
        {
            label: "Product Name",
            fieldName: "Product_Name__c",
            hideDefaultActions: true,
            wrapText: true
        },
        {
            label: "Pricing Type",
            fieldName: "Pricing_Type__c",
            hideDefaultActions: true
        },
        {
            label: "Unit of Measure",
            fieldName: "Unit_of_Measure__c",
            hideDefaultActions: true
        }
    ];

    @api isTrader;
    @api
    get entries(){
        return this._entries;
    }

    set entries(value){
        this._entries=value;
    }

    _unfilteredEntries;
    _selectedRows;
    _entries;
    @api
    editProduct;


    @api
    buttonState

    @api
    get selectedRows(){
        return this._selectedRows;
    }

    set selectedRows(value){
        this._selectedRows=value;
        this.buttonState=this._selectedRows?.length <= 0;
    }


    async connectedCallback(){
        console.log('productModal-loc: '+this.locationId);
        console.log('productModal-pb: '+this.pricebookId);
        console.log('productModal-del: '+this.deliveryLocationId);
        console.log('productModal-bc: '+this.businessCountry);
        console.log('productModal-row::'+JSON.stringify(this.editProduct));
        console.log('productModal--wapper::'+JSON.stringify(this.orderWrapper));
        
        //editmode
        if(this.locationId!=null && this.pricebookId!=null){
            this.initEntries();
            this.buttonState=false;
        }else{
            this.buttonState = true;
        }
    }

    async initEntries(){
        console.log('AddProductModal.initEntries:: ');
        this._unfilteredEntries=await getAvailableEntryByLocation({pricebookId:this.pricebookId});
        if(this._unfilteredEntries){
            console.log('AddProductModal.initEntries-ok:: '+JSON.stringify(this._unfilteredEntries));
            this.entries=this._unfilteredEntries[this.locationId];
        }else{
            console.log('AddProductModal.initEntries-ERROR:: '+JSON.stringify(this._unfilteredEntries));
        }
        
    }

    handleSearchOnChange(event) {
        this.loadingSearchState = true;
        let queryTerm = event.target.value.toUpperCase();
        console.log("changing: " + event.target.value);
        let filterByName = this.entries.filter((el) => el.Name.includes(queryTerm));
        let filterByCode = this.entries.filter((el) =>
            this.productLevel === "PRODUCT" ?
            el.ProductCode.includes(queryTerm) :
            el.Code.includes(queryTerm)
        );
        if (filterByCode.length > 0) {
            this.entries = filterByCode;
            this.loadingSearchState = false;
        } else if (filterByName.length > 0) {
            this.entries = filterByName;
            this.loadingSearchState = false;
        }
    }

    handleRowSelection(event) {
        this.selectedRows = event.detail.selectedRows;
    }

    handleAdd(event){
        console.log('addProductModal.handleAdd::')
        this.viewMode='EDIT';
    }

    async handleSave(event){
        console.log('addProductModal.handleSave::')
        let childCmp=this.template.querySelector('c-order-line-configurator');
        let missingFields=childCmp.checkRequiredFields;
        let warnings=childCmp.checkWarnings;
        console.log('addProductModal.handleSave--missing'+JSON.stringify(missingFields));
        if(missingFields.length>0){
            this.showToast('Error!', 'Please review required fields: '+JSON.stringify(missingFields).replace('[', "").replace(']', '').replaceAll('"', ''), 'error');
            return;
        }
        let missingDependencies=childCmp.checkFieldDependencies;
        console.log('addProductModal.handleSave--missingDep'+JSON.stringify(missingDependencies));
        if(missingDependencies.length > 0){
            missingDependencies.forEach(element => {
                this.showToast('Error!',element.masterFieldLabel+' requires following field to be filled: '+element.dependentFieldLabel,'error');
            });
            return;
        }
        let formData=childCmp.productRecord;
        let promptResult;
        //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
        console.log('addProductModal.handleSave--warnings:: '+JSON.stringify(warnings));
        if(warnings.result.length > 0){
            let joined = warnings.result.join('\n');
            promptResult = await this.showConfirmationPrompt(joined,warnings.anyMandatory);
            if(!promptResult || warnings.anyMandatory){
                return;
            }
        }
        //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message
        console.log('addProductModal.handleSave--rec::'+JSON.stringify(formData));
        if(!this.editProduct){
            let addRecordEvent=new CustomEvent('addrecord',{detail:formData});
            this.dispatchEvent(addRecordEvent);
            this.close();
        }else{
            let editRecordEvent=new CustomEvent('editrecord',{detail:formData});
            this.dispatchEvent(editRecordEvent);
            this.close();
        }
    }

    showToast(label, msg, type) {
		const event = new ShowToastEvent({
			title: label,
			message: msg,
			variant: type,
			mode: 'dismissable'
		});
		this.dispatchEvent(event);
	}

    @api orderWrapper;
    //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
    async showConfirmationPrompt(msg,showError){
		return await LightningConfirm.open({
            message: msg,
            theme: showError ? 'error' : 'warning',
            //theme: 'info',
            //label: 'Warning!', //this is optional
            //cancelLabel: 'No', //this is optional
            //confirmLabel: 'Yes' //this is optional
            //theme defaults to "default"
            label: showError ? 'Error!!' : 'Warning!!', // this is the header text
        });
	}
    //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message

}