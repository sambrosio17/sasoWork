import { api } from "lwc";
import LightningModal from 'lightning/modal';
import Toast from 'lightning/toast'
export default class AddNoteModal extends LightningModal {

    @api
    content;
    @api
    value='Note for Shipper'
    @api
    options=[
        {
            label:'Note for Shipper',
            value:'Note for Shipper',
            icon:'custom:custom98'
        },
        {
            label:'Note for Carrier',
            value:'Note for Carrier',
            icon:'custom:custom14'
        },
        {
            label:'Sales Office Internal Notes',
            value:'Sales Office Internal Notes',
            icon:'standard:field_sales'
        },
        {
            label:'General notes for Customer',
            value:'General notes for Customer',
            icon:'standard:customer_360'
        },
        {
            label:'Analysis notes for Customer',
            value:'Analysis notes for Customer',
            icon:'standard:indicator_performance_period'
        },
        {
            label:'Particular notes for Customer',
            value:'Particular notes for Customer',
            icon:'standard:procedure_detail'
        }
    ]
    @api
    textareaValue;
    @api
    buttonState

    handleTextAreaChange(event){
        this.textareaValue=event.detail.value;
        //this.buttonState=!(this.textareaValue.length > 0 && this.value.lenght > 0);
    }

    handleChange(event){
        this.value=event.detail.value;
        //this.buttonState=!(this.textareaValue.length > 0 && this.value.length > 0);
        console.log('handleChange-modal::'+this.value);
    }

    
    handleSave(event){
        let title=this.value;
        console.log('handleSave-modal::'+title);
        let body=this.textareaValue;
        console.log('handleSave-modal::'+body);
        let icon=this.options.filter(el => el.value == this.value)[0].icon
        console.log('handleSave-modal::'+icon);
        let note={
            title:title,
            body:body,
            icon:icon,
            uniqueId:this.generateUniqueId()
        }
        console.log('handleSave-modal::'+note);
        let noteEvent=new CustomEvent("modalsave",{detail:note});
        this.dispatchEvent(noteEvent);
        this.close();
    }

    connectedCallback(){
        this.buttonState=false;
    }

    showToast(label,msg,type){
        Toast.show({
            label:label,
            message:msg,
            mode:'dismissible',
            variant:type
        },this);
    }

    generateUniqueId() {
        return Date.now().toString(36) + Math.floor(Math.pow(10, 12) + Math.random() * 9 * Math.pow(10, 12)).toString(36)
    }
}