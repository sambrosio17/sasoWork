import {
    LightningElement,
    api,
    wire
} from "lwc";
import getQualitiesByCountryAndProduct from "@salesforce/apex/OrderConfiguratorController.getQualitiesByCountryAndProduct";
export default class ConfiguratorSpecialField extends LightningElement {

    @api object;
    @api field=''
    @api label;
    @api businesscountry;
    @api productcode;
    @api objectPicker;
    @api required;
    @api version;
    @api accountId
    _values={};
    _value;
    _options;
    _filter;
    _filteringCriteria
    _matchingInfo;
    _displayInfo;

    @api get filteringCriteria(){
        return this._filteringCriteria;
    }

    set filteringCriteria(value){
        this._filteringCriteria=value;
    }

    @api get filter(){
        let currentFilter={};
        if(this.field === 'C0141_Shipment_Location__c'){
            currentFilter={
                criteria:[
                    {
                        fieldPath:'ParentRecord.Id',
                        operator:'eq',
                        value: this.accountId
                    },
                    {
                        fieldPath:'Active__c',
                        operator:'eq',
                        value: true
                    }
                ],
                filterLogic:'1 AND 2'
            }
        }if(this.field === 'Shipment_Site__c'){
            currentFilter={
                criteria:[
                    {
                        fieldPath:'ExternalReference',
                        operator:'in',
                        value:this.filteringCriteria
                    }
                ]
            }
        }
        return currentFilter;
    }

    set filter(value){
        this._filter=value;
    }

    @api get values(){
        return this._values;
    }

    set values(value){
        console.log('receiving values:: '+JSON.stringify(value));
        this._values=value;
    }

    @api get options() {
        return this._options;
    }

    set options(value) {
        console.log('options-receiving:: '+JSON.stringify(value));
        this._options = value;
    }

    @api get value() {
        let value=this.showQuality ? this._value : this.values?.[this.field]
        console.log('getting:: '+value+' for:: '+this.field);
        return value; 
    }

    set value(value) {
        this._value = value;
        console.log('setting special value' + value);
    }


    /*@api matchingInfo = {
        primaryField: { fieldPath: 'Location_Name__c'},
        additionalFields: [{fieldPath: 'Location.Location_Main_Address__c'}]
    }*/

    @api get matchingInfo(){
        let matching={};
        if(this.field === 'C0141_Shipment_Location__c'){
            matching = {
                primaryField: { fieldPath: 'Location_Name__c'},
                additionalFields: [{fieldPath: 'Location.Location_Main_Address__c'}]
            }
        }
        if(this.field === 'Shipment_Site__c'){
            matching = {
                primaryField: { fieldPath: 'Name'},
                additionalFields: [{fieldPath: 'ExternalReference'}]
            }
        }
        return matching;
    }

    set matchingInfo(value){
        this._matchingInfo=value;
    }

    @api get displayInfo(){
        let display={};
        if(this.field === 'C0141_Shipment_Location__c'){
            display ={
                primaryField: 'Location_Name__c',
                additionalFields: ['Location.Location_Main_Address__c']
            }
        }
        if(this.field === 'Shipment_Site__c'){
            display = {
                primaryField: 'Name',
                additionalFields: ['ExternalReference']
            }
        }
        return display;
    }

    /*@api displayInfo = {
        primaryField: 'Location_Name__c',
        additionalFields: ['Location.Location_Main_Address__c']
    }*/


    connectedCallback() {
        console.log('ConfiguratorSpecialFields--connected::')
        console.log('ConfiguratorSpecialFields--connected-object::' + this.object)
        console.log('ConfiguratorSpecialFields--connected-field::' + this.field)
        console.log('ConfiguratorSpecialFields--connected-label::' + this.label)
        console.log('ConfiguratorSpecialFields--connected-bc::' + this.businesscountry)
        console.log('ConfiguratorSpecialFields--connected-pc::' + this.productcode)
        console.log('ConfiguratorSpecialFields--connected-options::' + JSON.stringify(this.options))
        console.log('ConfiguratorSpecialFields--connected-filteringCriteria::' + JSON.stringify(this.filteringCriteria))

        if(this.field === 'C0003T_Raggruppamento_Conferma__c' && !this.value){
            this.options = [
                {
                    value:'',
                    label:'--None--'
                }
            ]
            this.values = {
                "C0003T_Raggruppamento_Conferma__c":''
            }
        }


    }

    renderedCallback() {
        console.log('ConfiguratorSpecialFields--rendered::')
        console.log('ConfiguratorSpecialFields--rendered-object::' + this.object)
        console.log('ConfiguratorSpecialFields--rendered-field::' + this.field)
        console.log('ConfiguratorSpecialFields--rendered-label::' + this.label)
        console.log('ConfiguratorSpecialFields--rendered-bc::' + this.businesscountry)
        console.log('ConfiguratorSpecialFields--rendered-pc::' + this.productcode)
        console.log('ConfiguratorSpecialFields--rendered--options::' + JSON.stringify(this.options))
        console.log('ConfiguratorSpecialFields--rendered-filteringCriteria::' + JSON.stringify(this.filteringCriteria))

    }

    handleChange(event) {
        console.log('configuratorSpecialField.handleChange::' + event.detail.value + event.detail.recordId);
        let value = this.showQuality ? event.detail.value : event.detail.recordId;
        this.value = value;
        this.dispatchOnFieldChangeEvent(value);
    }

    dispatchOnFieldChangeEvent(value) {
        let event = new CustomEvent('fieldchange', {
            detail: {
                fieldApiName: this.field,
                value: value
            }
        });
        this.dispatchEvent(event);
    }

    @api get showQuality(){
        return this.field == 'Quality__c';
    }

    @api get showRecordPicker(){
        return this.field == 'C0141_Shipment_Location__c' || this.field == 'Shipment_Site__c';
    }

    @api get showSelect(){
        return this.field === 'C0003T_Raggruppamento_Conferma__c';
    }


}