import { LightningElement, api } from "lwc";
import { NavigationMixin } from 'lightning/navigation';
import SearchExistingOrdersModal from "c/searchExistingOrdersModal";
import AddNoteModal from "c/addNoteModal";
import getOverrides from '@salesforce/apex/CloneExistingOrderController.getOverrides'



export default class OrderConfiguratorLauncher extends NavigationMixin(LightningElement) {

    @api
    salesAgreementId

    @api
    selectedOrderId

    handleNewClick(event){
        console.log('handleClickLauncher::')
        this.navigateToCustomTab();
        console.log('handleClickLauncher-2::')
    }

    navigateToCustomTab() {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: '/lightning/n/OrderConfigurator?c__id='+this.salesAgreementId
            }
        });
    }

    handleCloneExistingOrder(event) {
        const selectedOrderId = event.detail.selectedOrderId;
        console.log('Received order ID from child: ' + selectedOrderId);
        // Handle the received order ID as needed
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: '/lightning/n/OrderConfigurator?c__id='+this.salesAgreementId+'c__orderid='+selectedOrderId
            }
        });

    }

    handleCloneOrderClick(event) {
        console.log('handleCloneOrderLauncher::')
        this.handleCloneOrder();
        console.log('handleCloneOrderLauncher-2::')
    }

    handleCloneOrder(event) {
        const result = SearchExistingOrdersModal.open({
            size: 'small',
            salesAgreementId: this.salesAgreementId, // Pass the salesAgreementId here
            oncloneexistingorder: (e) => {
                console.log('event =>'+JSON.stringify(e))
                this.selectedOrderId = e.detail.selectedOrderId;
                e.stopPropagation();
                this.navigateToCloneOrderConfigurator(e.detail)
            }
        })
    }

    async navigateToCloneOrderConfigurator() {
        console.log('navigateToCloneOrderConfigurator');

        this[NavigationMixin.Navigate]({
                type: 'standard__webPage',
                attributes: {
                    url: '/lightning/n/OrderConfigurator?c__id='+this.salesAgreementId+'&c__orderid='+this.selectedOrderId
                }
            });
        

    }

    handleAddNote(event) {
        const result = AddNoteModal.open({
            size: 'small',
            onmodalsave: (e) => {
                e.stopPropagation();
                this.handleModalSave(e.detail)
            }
        })
    }

    


}