import {
    LightningElement,
    api,
    wire
} from "lwc";
import getConfiguratorFields from "@salesforce/apex/OrderConfiguratorController.getConfiguratorFields";
import getAllConfiguratorFields from "@salesforce/apex/OrderConfiguratorController.getAllConfiguratorFields";
import saveOrder from "@salesforce/apex/OrderConfiguratorController.saveOrder";
import getAgreementWithLines from "@salesforce/apex/OrderConfiguratorController.getAgreementWithLines";
import getLocationAddress from "@salesforce/apex/OrderConfiguratorController.getLocationAddress";
import initOrder from "@salesforce/apex/OrderConfiguratorController.initOrder"
import getCreditInformation from "@salesforce/apex/FidoWebservice.getCreditInformation"
import getAssociatedLocationByLocationId from "@salesforce/apex/OrderConfiguratorController.getAssociatedLocationByLocationId"
import * as orderConfiguratorSingleton from "c/orderConfiguratorSingleton";
import getDefaultValuesByFilters from "@salesforce/apex/OrderConfiguratorController.getDefaultValuesByFilters"
import NoShipmentSiteFound from "@salesforce/label/c.NoShipmentSiteFound"
import CustomerOrderIdMsg from "@salesforce/label/c.CustomerOrder"
import getValidShipmentSitesByProductsInvokable from "@salesforce/apex/OrderConfiguratorController.getValidShipmentSitesByProductsInvokable"
import searchOrderByRef from "@salesforce/apex/OrderConfiguratorController.searchOrderByRef"
import getPaymentTriplets from "@salesforce/apex/OrderConfiguratorController.getPaymentTriplets";
import getDataFromAccount from "@salesforce/apex/OrderConfiguratorController.getDataFromAccount";
import getNotesFromLocation from "@salesforce/apex/OrderConfiguratorController.getNotesFromLocation";
import getHeaderPriceRuleOutput from "@salesforce/apex/OrderConfiguratorController.getHeaderPriceRuleOutput";
import getOrderGroupsByFilters from "@salesforce/apex/OrderConfiguratorController.getOrderGroupsByFilters";
import getOverrides from "@salesforce/apex/CloneExistingOrderController.getOverrides";
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
import AddNoteModal from "c/addNoteModal";
import {
	getRecord
} from "lightning/uiRecordApi";

import {refreshApex} from '@salesforce/apex'

import SA_NAME from '@salesforce/schema/SalesAgreement.Name';
import SA_ACCOUNT from '@salesforce/schema/SalesAgreement.AccountId';
import SA_PRICEBOOK from '@salesforce/schema/SalesAgreement.PricebookId';

export default class OrderHeaderConfigurator extends LightningElement {
    @api
    fields;
    fieldError;

    //record;

    fieldMap;
    salesAgreement;

    @api
    agreementWithLines;
    
    _locationId;

    configuratorField;

    @api
    agreementid='';
    @api
    orderId;
    @api
    x01_customerandshipping;
    @api
    x02_customerorderinfo;
    @api
    x03_certificateinfo;
    @api
    x04_incoterminfo;
    @api
    x025_agentfields;
    @api
    x026_credicheck;
    x99_required_to_save;
    @api
    noteList;
    @api creditSectionSpinner;
    @api validShipmentSites;
    isPurchasingGroup;
    oldUnitOfMeasure;
    //07-18: Modifica per purchasing group - START
    _accountId;
    @api isClone;
    @api sourceOrder;


    @api
    get accountId(){
        //return this.agreementWithLines?.agreement?.Account?.Id;
        //07-18: Modifica per purchasing group - START
        /*console.log('gettingAccountId::')
        console.log('gettingAccountId.AccountId:'+this.orderHeader.AccountId);
        return this.orderHeader.AccountId;*/
        return this._accountId;
    }

    set accountId(value){
        this._accountId = value; 
    }

    @api
    get locationId(){
        this._locationId;
    }

    set locationId(value){
        console.log('setting location id'+JSON.stringify(value));
        this._locationId=value;
        let event=new CustomEvent('locationchange',{detail:value});
        this.dispatchEvent(event);
    }


   disabledField=['AccountId','Purchasing_Group__c','Ongoing_Order_Value__c','Available_Order_Plafond__c','Available_Shipment_Plafond__c','Total_Order_Plafond__c'];


    @api get formData() {
        console.log('OrderHeaderConfigurator.formData:: '+JSON.stringify(this.orderHeader));
        let tempHeader=JSON.parse(JSON.stringify(this.orderHeader));
        
        if(tempHeader?.Sales_Agreement_Created_Date__c){
            delete tempHeader?.Sales_Agreement_Created_Date__c;
        }
        console.log('OrderHeaderConfigurator.formData--removedProp:: '+JSON.stringify(tempHeader));
        this.orderHeader = tempHeader;
        return this.orderHeader;
        /*
        let record = {}
        let formField = this.template.querySelectorAll('lightning-input-field');
        console.log('OrderHeaderConfigurator.formData-fields:: ' + JSON.stringify(formField));
        formField.forEach(el => {
            record[el.dataset.apiname] = el.value
            //console.log('OrderHeaderConfigurator.formData-id: '+el.dataset.apiname);
            //console.log('OrderHeaderConfigurator.formData-value: '+el.value);
        })
        record.Id = this.orderId;
        record.Pricebook2Id=this.agreementWithLines?.agreement?.PricebookId;
        //record.SalesAgreementId=agreement?.Id;
        console.log('OrderHeaderConfigurator.formData-record:: ' + JSON.stringify(record))
        return record;*/
    }

    @api get orderRecordId() {
        return this.orderId;
    }

    @api get locationRecordId() {
        return this.locationId;
    }

    _deliveryAddress;

    @api get deliveryAddress(){
        return this._deliveryAddress;
    }

    set deliveryAddress(value){
        this._deliveryAddress=value;
        console.log('delivery address'+this._deliveryAddress);
        //this.configuratorField['C0141_Shipment_Location__c'].value=value;
        this.setDeliveryAddress(value);
        
    }

    createAndDispatchEvent(eventName,detail){
        let event=new CustomEvent(eventName,{detail:detail});
        this.dispatchEvent(event);
    }

    async handleFieldChange(event){
        console.log('field change'+JSON.stringify(event.target.value));
        console.log('field change'+JSON.stringify(event.target.dataset));
        let apiName=event?.target?.dataset?.apiname;
        let value=event.target.value;
        //change 26-06
        let oldValue=this.orderHeader?.[apiName];
        console.log('field change--oldValue'+oldValue);
        let temp=JSON.parse(JSON.stringify(this.orderHeader));
        temp[apiName]=value;
        this.orderHeader=temp;
        if(apiName == 'Status' && !this.orderHeader?.Id & value!='New'){
            this.showToast('Error!','Order can only be created with Status New','error');
            temp=JSON.parse(JSON.stringify(this.orderHeader));
            temp[apiName]='New';
            this.orderHeader=temp;
            this.configuratorField(apiName).value='New';
            return;
    }
        if(event?.target?.dataset?.apiname == 'Shipment_Site__c'){
            this.locationId=event.target.value;
            console.log('field change'+JSON.stringify(this.locationId));
            
        }
        if(event?.target?.dataset?.apiname =='C0141_Shipment_Location__c' ){
            console.log('field change'+JSON.stringify(this.configuratorField));
            this.deliveryAddress=event.target.value;
        }

        //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
        let businessCountry = this.orderHeader?.Business_Country_Code__c;
        let specialBusinessCountry = ['BEL','DEU'];
        if(apiName == 'C0616_Unita_di_Misura_Quantita_Ordine__c'){
            console.log('oldUM-pre: '+this.oldUnitOfMeasure);
            this.oldUnitOfMeasure=oldValue;
            console.log('oldUM-post: '+this.oldUnitOfMeasure);
            console.log('currentUM:'+value);
            console.log('priceMeasure:'+this.orderHeader?.Unit_di_Misura_Prezzo__c);
            let oldAndNew={
                "oldValue":this.oldUnitOfMeasure,
                "newValue":value,
                "priceMeasure":this.orderHeader?.Unit_di_Misura_Prezzo__c
            }
            this.createAndDispatchEvent('measurechange',oldAndNew);
            if(!specialBusinessCountry.includes(businessCountry))
                this.setValueOnRecord('Unit_di_Misura_Prezzo__c',value)
        }
        if(apiName == 'Unit_di_Misura_Prezzo__c'){
            if(!specialBusinessCountry.includes(businessCountry)){
                this.setValueOnRecord('C0616_Unita_di_Misura_Quantita_Ordine__c',value)
            }
            let oldAndNew={
                "oldValue":this.oldUnitOfMeasure,
                "newValue":this.orderHeader?.C0616_Unita_di_Misura_Quantita_Ordine__c,
                "priceMeasure":value
            }
            this.createAndDispatchEvent('measurechange',oldAndNew);
                
        }
        //29-10-2024 - saambrosio@deloitte.it - END:: Managing different unit of measure for BEL and DEU
        if(apiName=='C0003T_Raggruppamento_Conferma__c'){
            let searchInput={
                targetObject:'Order',
                orderGroup:value,
                businessCountry:this.orderHeader?.Business_Country_Code__c
            }
            console.log('handleFieldChange-searchInput:: '+JSON.stringify(searchInput));
            let defaultValues=await getDefaultValuesByFilters({input:JSON.stringify(searchInput)});
            console.log('orderHeaderConfigurator.defaultValues:: '+JSON.stringify(defaultValues));
            this.manageDefaultValues(defaultValues);
        }
        if(apiName == 'C0011_Riferimento_Ordine_Cliente__c'){
            if(value.length >= 3){
                console.log('searchOrderByRef::')
                let searchResult = await searchOrderByRef({ref:value});
                if(searchResult && searchResult.length > 0){
                    let msg = CustomerOrderIdMsg.replace('{0}',value).replace('{1}',searchResult.length);
                    this.showToast('Warning!',msg,'warning');
                }
            }
        }
        if(apiName == 'Account_of_Purchasing_Group__c'){
            let isPurchasingGroup = false;
            if(value != null && value.length > 0){
                isPurchasingGroup = true;
                this.accountId = value;
                let paymentTriplets = await getPaymentTriplets({accountId: value});
                let wrapperCopy = JSON.parse(JSON.stringify(this.orderWrapper));
                if(paymentTriplets){
                    console.log('chiamate ok');
                    console.log('receivedPaymetTripletsOnChange:: '+JSON.stringify(paymentTriplets));
                    wrapperCopy.paymentTripletsPG.primary=paymentTriplets.primary || {};
                    wrapperCopy.paymentTripletsPG.secondary=paymentTriplets.secondary || {};
                }else{
                    wrapperCopy.paymentTripletsPG.primary={};
                    wrapperCopy.paymentTripletsPG.secondary={};
                }
                this.orderWrapper = wrapperCopy;
                await this.createAndDispatchEvent('purchasingroupset',{isPurchasingGroup: true});
            }else{
                this._accountId = this.orderHeader?.AccountId;
                //emptyOut - paymentTripletsPG
                let wrapperCopy = JSON.parse(JSON.stringify(this.orderWrapper));
                wrapperCopy.paymentTripletsPG.primary={};
                wrapperCopy.paymentTripletsPG.secondary={};
                this.orderWrapper = wrapperCopy;
                await this.createAndDispatchEvent('purchasingroupset',{isPurchasingGroup: false});
            }
            console.log('PaymentTripletsForPurchasingGroup:: '+JSON.stringify(this.orderWrapper));
            await this.managePurchasingGroupFields(isPurchasingGroup);
            await this.handleGetCreditInformation();
        }
        if(this.priceRuleTrackedField.includes(apiName)){
            this.handleHeaderPriceRule();
        }
        //this.orderHeader[apiName]=value;
        
        console.log('header:: '+JSON.stringify(this.orderHeader));
       
    }

    async managePurchasingGroupFields(isPurchasingGroup){
        if(isPurchasingGroup){
            let accountData = await getDataFromAccount({accountId : this.accountId});
            let notes = await getNotesFromLocation({locationId : this.accountId});
            if(accountData){
                this.mapDataToFields(accountData);
            }
            if(notes){
                this.noteList = this.reMapNotes(notes,null);
            }
        }else{
            this.mapDataToFields(this.orderWrapper.orderHeader);
            this.noteList = this.reMapNotes(this.orderWrapper.notes,null);
        }
    }

    mapDataToFields(wrapper){
        console.log('mapDataToFields:: '+JSON.stringify(wrapper));
        for(let field of this.fieldsToMap){
            let value = wrapper?.[field] || "";
            this.setValueOnRecord(field,value);
        }
    }

    fieldsToMap = ['C0406_Email_per_invio_Certificato__c','C0405_Email_per_invio_conferma__c','C0051_Agente__c','C0062_Venditore_interno__c']

    manageDefaultValues(defs){
        console.log('manageDefaultValues:: ')
        let record=JSON.parse(JSON.stringify(this.orderHeader));
        for(let def in defs){
            console.log('manageDefaultValues:: ')
            console.log('manageDefaultValues.prop:: '+def)
            console.log('manageDefaultValues.value:: '+defs[def])
            //this.setValueOnRecord(def,defs[def]);
            let configuratorField=this.configuratorField?.[def];
            
            record[def]=defs?.[def];
            
        if(configuratorField){
            //configuratorField.reset();
            configuratorField.value=defs[def];
            //this.setValueOnRecord(def,defs[def]);
        }
            if(def==='Shipment_Site__c'){
                this.locationId=defs[def];
                this.specialFieldValues = {field:def, value:defs[def]}
            }
            if(def == 'C0616_Unita_di_Misura_Quantita_Ordine__c'){
                //this.createAndDispatchEvent('measurechange',value);
            }
        }
        this.orderHeader=record;
    }

    setValueOnRecord(field,value){
        let record=JSON.parse(JSON.stringify(this.orderHeader));
        record[field]=value;
        this.orderHeader=record;
        let configuratorField=this.configuratorField?.[field];
        if(configuratorField){
            configuratorField.value=value;
        }
    }

    async setDeliveryAddress(locationId){
        console.log('set delivery address');
        let locationAddress=await getLocationAddress({locationId:locationId});
        console.log('field change-loc'+JSON.stringify(locationAddress));
        let field=this.configuratorField['Delivery_Address__c'];
        if(field){
            field.value=locationAddress?.locationAddress == null ? null : locationAddress?.locationAddress;
            this.createAndDispatchEvent('deliverychange',locationAddress?.locationId);
            let temp=JSON.parse(JSON.stringify(this.orderHeader));
            temp['C0141_Shipment_Location__c']=locationAddress?.locationId;
            this.orderHeader=temp;
        }
        if(locationAddress?.notes){
            let tempNotes=JSON.parse(JSON.stringify(this.noteList)).filter(el => el.type != 'locationNote');
            tempNotes.push(...this.reMapNotes(locationAddress?.notes,'locationNote'));
            this.noteList=tempNotes;
        }else{
            this.noteList=JSON.parse(JSON.stringify(this.noteList)).filter(el => el.type != 'locationNote');
        }
    }

    /*@wire(getAgreementWithLines,{agreementid:'$this.agreementid'})
    getAgreementWithLines(data,error){
        if(data){
            console.log('agreeemnet-new::.'+JSON.stringify(data))
        }else{
            console.log('errrorrr: '+JSON.stringify(error));
        }
    }*/



    @wire(getAllConfiguratorFields, {
        objectName: 'Order'
    })
    getConfiguratorMap(result, error) {
        if (result.data) {
            console.log('getAllConfiguratorFields:: ' + JSON.stringify(result.data));
            this.x01_customerandshipping = result.data.x01_customerandshipping;
            this.x02_customerorderinfo = result.data.x02_customerorderinfo;
            this.x03_certificateinfo = result.data.x03_certificateinfo;
            this.x04_incoterminfo = result.data.x04_incoterminfo;
            this.x99_required_to_save = result.data.x99_required_to_save;
            this.x025_agentfields=result.data.x025_agentfields;
            this.x026_credicheck=result.data.x026_credicheck;
            let event = new CustomEvent('loaded', {
                detail: false
            });
            this.dispatchEvent(event);
        } else {
            console.log('getAllConfiguratorFields-ERROR:: ' + error);
            this.fiedlError = error
        }
    }

    async connectedCallback() {
        console.log("hello world"+this.agreementid);
        console.log('isclone:: '+this.isClone);
        console.log('sourceOrder:: '+this.sourceOrder);
        this.fields = console.log("data: " + JSON.stringify(this.fields));
        this.noteList = [];
        //this.agreementWithLines=await getAgreementWithLines({agreementId:this.agreementid});
        
        await this.getOrderWrapper(this.agreementid);
        
        
        
    }

    

    renderedCallback(){
        console.log('renderedCallback::')
        //this.initOrder(this.agreementWithLines);
        if(!this.oldUnitOfMeasure){
            this.oldUnitOfMeasure=this.orderHeader?.C0616_Unita_di_Misura_Quantita_Ordine__c;
        }
        this.doInitOrder();
        
        //console.log('rendered fieldmap: '+JSON.stringify(this.configuratorField));
        
    }

    initOrder(agreement){
        console.log('initOrder::'+JSON.stringify(agreement))
        let orderFields=this.template.querySelectorAll('lightning-input-field');
        let configuratorField={};
        orderFields.forEach(el => {
            console.log('initOrder: '+el.dataset.apiname)
            let apiName=el.dataset.apiname;
            switch(apiName){
                case 'AccountId': el.value=agreement?.agreement?.Account?.Id;break;
                case 'Status': el.value='New';break;
                case 'EffectiveDate': el.value=new Date().toISOString().split('T')[0];break;
                case 'Available_Order_Plafond__c':el.value=40221838; break;
                case 'Available_Shipment_Plafond__c':el.value=44283069; break;
                case 'Total_Order_Plafond__c':el.value=50000000;break;
                case 'Ongoing_Order_Value__c':el.value=3861231; break;
                case 'Purchasing_Group__c':el.value=agreement?.agreement?.Account?.Purchasing_Group__c; el['disabled']=true; break;
                case 'C0405_Email_per_invio_conferma__c':el.value=agreement?.agreement?.Account?.Email_for_order_confirmation__c; break;
                case 'C0406_Email_per_invio_Certificato__c':el.value=agreement?.agreement?.Account?.Email_for_certificate__c; break;
                case 'C0792_Tipo_Pagamento__c':el.value=agreement?.agreement?.Account?.Payment_Type__c; break;
                case 'C0012_Data_Ordine_Cliente__c':el.value=new Date().toISOString().split('T')[0];break;
                case 'C0402_Invio_Certificato_per_EMail__c':el.value='M';break;
                case 'Delivery_Address__c':el.value="";break;
                case 'T8001_Tipo_Certificato__c':el.value="00";break;
                case 'C0118_COD_APPLICAZIONE_IVA__c':el.value="20";break;
            }
            configuratorField[apiName]=el;
            
        })
        this.configuratorField=configuratorField;
        /*let initEvent=new CustomEvent('initorder',{detail:agreement});
        this.dispatchEvent(initEvent);*/
    }

    handleModalSave(detail) {
        console.log('handleModalSave:: ' + JSON.stringify(detail));
        let notes = JSON.parse(JSON.stringify(this.noteList));
        notes.push(detail);
        this.noteList = notes;
        console.log('handleModalSave:: ' + JSON.stringify(this.noteList));
        this.showToast('Success!', 'Note addedd succesfully!', 'success');
    }

    clickHandler(event) {
        console.log('ev:: ' + JSON.stringify(event.target.getAttribute('data-id')));
        event.detail.openSections = null;
    }

    handleAddNote(event) {
        const result = AddNoteModal.open({
            size: 'small',
            onmodalsave: (e) => {
                e.stopPropagation();
                this.handleModalSave(e.detail)
            }
        })
    }

    showToast(label, msg, type) {
        const event = new ShowToastEvent({
            title: label,
            message: msg,
            variant: type,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }

    @api
    async handleSaveOrder(record) {
        try {
            console.log('handleSaveOrder:: ' + record);
            console.log('handleSavedOrder.orderId:: '+this.orderId);
            let check = this.checkRequiredField(record);
            if (check.length > 0) {
                this.showToast('Error!', 'Please review required fields: ' + JSON.stringify(check).replace('[', "").replace(']', '').replaceAll('"', ''), 'error');
                let event = new CustomEvent('ordersaved', {
                    detail: null
                });
                this.dispatchEvent(event);
                return;
            }
            if(this.orderId){
                record.Id=this.orderId;
            }
            this.orderId = await saveOrder({
                orderRecord: JSON.stringify(record)
            });
            console.log('handleSaveOrder-recordId:: ' + this.orderId);
            let event = new CustomEvent('ordersaved', {
                detail: this.orderId
            });
            this.dispatchEvent(event);
        } catch (error) {
            this.showToast('Error!', 'An error occurred while saving order', 'error');
            console.log('handleSaveOrder-error:: ' + JSON.stringify(error));
        }
    }

    @api
    async saveChildNotes(recordId){
        let noteCmp=this.template.querySelector('c-note-Manager').saveNotes(recordId);
    }

    checkRequiredField(record) {
        try {
            console.log('OrderHeaderConfigurator.checkRequiredField::')
            let missingField = [];
            let missingFieldLabel = [];
            for (let f of this.x99_required_to_save) {
                if (record[f.fieldApiName] == null || record[f.fieldApiName].length == 0) {
                    missingField.push(f.fieldApiName);
                    missingFieldLabel.push(f.fieldLabel)
                }
            }
            console.log('OrderHeaderConfigurator.checkRequiredField--fields:: ' + JSON.stringify(missingField));
            return missingFieldLabel;
        } catch (error) {
            console.log('ERROR::: ' + JSON.stringify(error))
        }
    }

    onclicksection(event){
        console.log('sezioneeee'+JSON.stringify(event.target.querySelector('section')));
    }


    //refactored code
    @api orderWrapper;
    @api orderHeader = {};
    @api orderLines;
    _headerFieldsMap;
    
    


    async getOrderWrapper(recordId){
        console.log('OrderConfigurator.getOrderWrapper--clone::'+this.isClone);
        console.log('OrderConfigurator.getOrderWrapper--sourceOrder::'+this.sourceOrder);
        console.log('OrderConfigurator.getOrderWrapper--recordId::'+recordId);
        let orderWrapper = {}
        if(this.isClone && this.sourceOrder){
            let response = await getOverrides({
                params: {
                    orderId: this.sourceOrder,
                    salesAgreementId:recordId
                }
            });
            if(response){
                orderWrapper = response.wrapper;
            }
            console.log('OrderConfigurator.getOrderWrapper:: CLONE');
            console.log('OrderConfigurator.getOrderWrapper:: CLONE::: '+JSON.stringify(orderWrapper));
        }else{
            orderWrapper = await initOrder({recordId:recordId});
            console.log('OrderConfigurator.getOrderWrapper:: NEW');
        }
        
        console.log('OrderConfigurator.getOrderWrapper::'+JSON.stringify(orderWrapper));
        if(orderWrapper){
            this.orderWrapper=orderWrapper;
            this.orderHeader=orderWrapper.orderHeader;
            this.orderLines=orderWrapper.orderLines;
            this.validShipmentSites=orderWrapper?.validShipmentSites;
            this.isPurchasingGroup = orderWrapper.isPurchasingGroup;
            let notes=orderWrapper.notes;
            console.log('OrderWrappernotes:: '+JSON.stringify(notes));
            if(notes!=null){
                console.log('notesfound:: '+JSON.stringify(notes));
                let tempnotes=this.reMapNotes(notes,null);
                this.noteList=tempnotes;
            }else{
                this.noteList=[];
            }
            if(this.validShipmentSites == null || this.validShipmentSites.length == 0){
                this.showToast('Warning!',NoShipmentSiteFound,'warning');
            }
        }
    }

    doInitOrder(){

        /*let instance = orderConfiguratorSingleton.getInstanceData();
        console.log('instance => '+JSON.stringify(instance));
        if(instance.wrapper && instance.wrapper?.isClone){
            console.log('orderHeaderConfigurator:: clone situation');
            try{

                this.orderWrapper = instance.wrapper;
                
                this.orderHeader=instance.wrapper?.orderHeader;
                this.orderLines=instance.wrapper?.orderLines;
                this.validShipmentSites=instance.wrapper?.validShipmentSites;
                this.isPurchasingGroup=instance.wrapper?.isPurchasingGroup;
                this.note
                /*let orderHeaderOverrides = instance.orderOverrides.orderOverrides;
                console.log('orderHeaderOverrides => '+JSON.stringify(orderHeaderOverrides));
        
                for (const [key, value] of Object.entries(orderHeaderOverrides)) {
                    try{
                        console.log(`${key}: ${value}`);
                        this.orderHeader[`${key}`] = value;    
                    }catch(e){
                        console.log('eroreeee!');
                    }
                }
            }catch(e){
                console.log('empty obj!');
            }
        }*/


        console.log('Order Header => '+JSON.stringify(this.orderHeader));


        console.log('OrderConfigurator.doInitOrder::');
        let orderFields=this.template.querySelectorAll('lightning-input-field');
        let fieldMap={};
        orderFields.forEach(el =>{
            let fieldName=el.dataset.apiname;
            console.log('OrderConfigurator.doInitOrder-currentField:: '+fieldName);
            console.log('OrderConfigurator.doInitOrder-currentField-value:: '+el.value);
            let defaultValue=this.orderHeader[fieldName];
            if(defaultValue)
                el.value=defaultValue;
            if(fieldName == 'C0616_Unita_di_Misura_Quantita_Ordine__c'){
                let oldNew={
                    "oldValue":this.oldUnitOfMeasure,
                    "newValue":defaultValue,
                    "priceMeasure":this.orderHeader?.Unit_di_Misura_Prezzo__c
                }
                this.createAndDispatchEvent('measurechange',oldNew);
            }
            if(fieldName==='Shipment_Site__c'){
                this.locationId=defaultValue
            }
            if(this.disabledField.includes(fieldName)){
                el.disabled=true;
            }
            fieldMap[fieldName]=el;
        })
        if(this.orderHeader.C0141_Shipment_Location__c!=null){
            this.initDeliveryAddress(this.orderHeader.C0141_Shipment_Location__c)
        }
        if(this.orderHeader.Shipment_Site__c != null){
            this.initSpecialField({'Shipment_Site__c':this.orderHeader.Shipment_Site__c})
        }
        if(this.orderHeader.C0003T_Raggruppamento_Conferma__c != null){
            this.initSpecialField({'C0003T_Raggruppamento_Conferma__c':this.orderHeader.C0003T_Raggruppamento_Conferma__c})
        }
        if(this.orderHeader.AccountId != null && !this.accountId){
            console.log('setting account first time');
            this.accountId = this.orderHeader.AccountId;
        }
        if(!this.isPurchasingGroup){
            if(fieldMap.Account_of_Purchasing_Group__c){
                fieldMap.Account_of_Purchasing_Group__c.disabled=true;
            }
        }
        /*if(this.orderHeader.C0141_Shipment_Location__c != null){
            this.initLocation();
        }*/
        this.configuratorField=fieldMap;
        console.log('mappa campi:: '+JSON.stringify(this.configuratorField));
    }

    async handleGetCreditInformation() {

        //console.log('accountId =>   '+this.orderHeader.AccountId);
		console.log('OrderHeaderConfigurator.getCreditInformation::');
        console.log('SalesAgreementId => '+this.agreementid);
		/*let request = {
            salesAgreementId: this.agreementid
		};*/
        let request = {
            accountId: this.accountId
		};
		console.log('OrderHeaderConfigurator.getCreditInformation.params::'+JSON.stringify(request));
		let response = await getCreditInformation({request: request});
	
        console.log('OrderHeaderConfigurator.getCreditInformation.response:: => '+JSON.stringify(response));
        
        console.log('Order Header Credit Info => '+JSON.stringify(this.orderHeader));


        for (const [key, value] of Object.entries(response.result.AccountFieldMapping)) {
            try{
                console.log(`${key}: ${value}`);
                this.setValueOnRecord(`${key}`,response.result[`${value}`]);
                //this.orderHeader[`${key}`] = response.result[`${value}`]     
            }catch(e){
                console.log('eroreeee! + handleGetCreditInformation')
                this.showToast('Error!','An error occurred while updating credit information!','error');
            }
            
        }

        console.log('orderHeader => '+JSON.stringify(this.orderHeader));
        this.creditSectionSpinner=false;
        this.showToast('Success!','Credit Information updated successfully','success');
        //this.doInitOrder();


	}

    
    handleRefreshCredit(event){
        console.log('handleRefreshCredit');
        this.creditSectionSpinner=true;
        this.handleGetCreditInformation()
        
    }

    handleSpecialFieldChange(event){
        console.log('orderHeaderConfigurator.handleSpecialFieldChange::');
        let field=event?.detail?.fieldApiName;
        let value=event?.detail?.value;
        console.log('orderHeaderConfigurator.handleSpecialFieldChange::'+field);
        console.log('orderHeaderConfigurator.handleSpecialFieldChange::'+value);
        let temp=JSON.parse(JSON.stringify(this.orderHeader));
        temp[field]=value;
        this.orderHeader=temp;
        if(field == 'C0141_Shipment_Location__c'){
            this.deliveryAddress=value;
        }
        if(field == 'Shipment_Site__c'){
            this.locationId=value;
        }
        if(field == 'C0003T_Raggruppamento_Conferma__c'){
            this.setOrderGroupDefaults(value);
        }
           
        
    }

    _specialFieldValues={};

    @api get specialFieldValues(){
        return this._specialFieldValues;
    }

    specialFieldValueContainer = {}
    set specialFieldValues(value){
        console.log('setting special field values:: '+JSON.stringify(value))
        console.log('setting special field values-initial:: '+JSON.stringify(this.specialFieldValueContainer))
        let temp=JSON.parse(JSON.stringify(this.specialFieldValueContainer));
        let field=value?.field;
        let fieldValue=value?.value;
        temp[field]=fieldValue;
        console.log('speciaFieldValues--after::'+JSON.stringify(temp))
        this.specialFieldValueContainer = temp;
        //this._specialFieldValues=temp;
        //this.template.querySelector('c-configurator-special-field').values=temp;
        this.template.querySelectorAll('c-configurator-special-field').forEach(c => c.values = temp);
        console.log('setting special field values:: '+JSON.stringify(this.specialFieldValueContainer))
    }

    initSpecialField(value){
        console.log('orderHeaderConfigurator.initSpecialField:: ')
        console.log('orderHeaderConfigurator.initSpecialField--input:: '+JSON.stringify(value));
        let field=value?.field;
        let fieldValue=value?.value;
        if(value?.['Shipment_Site__c']){
            console.log('weeeeee');
            this.locationId=value?.['Shipment_Site__c'];
        }
        let specialChildren=this.template.querySelectorAll('c-configurator-special-field');
        specialChildren.forEach(el => {
            console.log('orderHeaderConfigurator.initSpecialField--special:: ');
            let childValues=JSON.parse(JSON.stringify(el.values));
            console.log('orderHeaderConfigurator.initSpecialField--childValues-before:: '+JSON.stringify(childValues));
            let merged={...childValues,...value}
            console.log('orderHeaderConfigurator.initSpecialField--childValues-after:: '+JSON.stringify(merged));
            el.values=merged;
        })
    }

    async initDeliveryAddress(locationId) {
        try {
            console.log('orderHeaderConfigurator.initDeliveryAddress:: ' + locationId);
            let locationWrapper = await getAssociatedLocationByLocationId({
                locationId: locationId
            });
            console.log('orderHeaderConfigurator.initDeliveryAddress:: ' + JSON.stringify(locationWrapper));
            if (locationWrapper) {
                console.log('locationWrapper existing')
                /*let childvalues=JSON.stringify(this.template.querySelector('c-configurator-special-field').values);
                console.log('orderHeaderConfigurator.initDeliveryAddress-child:: ' + JSON.stringify(childvalues));
                childvalues.C0141_Shipment_Location__c=locationWrapper?.associatedLocationId;
                console.log('orderHeaderConfigurator.initDeliveryAddress-child:: ' + JSON.stringify(childvalues));*/
                let associatedLocation=locationWrapper?.associtatedLocationId;
                /*this.template.querySelector('c-configurator-special-field').values={
                   C0141_Shipment_Location__c:associatedLocation
                }*/
                this.initSpecialField({
                    C0141_Shipment_Location__c:associatedLocation
                 })
                /*this.specialFieldValues = {
                    field:'C0141_Shipment_Location__c',
                    value:locationWrapper?.associatedLocationId
                }*/
            }
        } catch (error) {

        }
    }

    typeToIcon={
        'Analysis notes for Customer':'standard:indicator_performance_period',
        'Note for Shipper':'custom:custom98',
        'Note for Carrier':'custom:custom14',
        'Sales Office Internal Notes':'standard:custom_apps',
        'General notes for Customer':'standard:custom_apps',
        'Particular notes for Customer':'standard:procedure_detail'
    }

    reMapNotes(notes, type){
        let newNoteLits=[];
        const defaultNoteIcon='standard:note'
        notes.forEach(el => {
            let newNote={
                body:el?.Body,
                title:el?.Title,
                icon:this.typeToIcon?.[el.Title] != null ? this.typeToIcon?.[el.Title] : defaultNoteIcon,
                type:type,
                Id:el?.Id,
                uniqueId:this.generateUniqueId()
            }
            newNoteLits.push(newNote);
            console.log('remapping:: '+JSON.stringify(newNoteLits));
        })

        return newNoteLits;
    }

    @api
    async setUpdateValidShipmentSites(sites){
        console.log('orderHeaderConfigurator.setUpdateValidShipmentSites::')
        console.log('orderHeaderConfigurator.setUpdateValidShipmentSites-sites::'+JSON.stringify(sites));

        let payload={
            prods:sites,
            businessCountry:this.orderHeader?.Business_Country_Code__c
        }

        try {
            let validSites=await getValidShipmentSitesByProductsInvokable(payload);
            if(validSites && validSites.length > 0){
                console.log('orderHeaderConfigurator.setUpdateValidShipmentSites-sitesFound::'+JSON.stringify(validSites));
                this.validShipmentSites=validSites;
            }else{
                this.showToast('Warning!',NoShipmentSiteFound,'warning');
            }
        } catch (error) {
            console.error('orderHeaderConfigurator.setUpdateValidShipmentSites::\nAn error occurred while getting valid shipment sites\nerror:::'+JSON.stringify(error));
        }
        
    }

    @api
    setPaymentTriplet(triplet){
        console.log('orderHeaderConfigurator.setPaymentTriplet:: '+JSON.stringify(triplet));
        console.log('accountOfPurchasingGroup:: '+this.orderHeader.Account_of_Purchasing_Group__c );
        let triplets = this.orderHeader.Account_of_Purchasing_Group__c && this.orderHeader.Account_of_Purchasing_Group__c.length > 0 ? this.orderWrapper.paymentTripletsPG : this.orderWrapper.paymentTriplets;
        console.log('setPaymentTriplet-triplets:: '+JSON.stringify(triplets));
        let primary = triplets.primary;
        console.log('setPaymentTriplet-primary:: '+JSON.stringify(primary));
        let secondary = triplets.secondary;
        console.log('setPaymentTriplet-secibdart:: '+JSON.stringify(secondary));
        let tripletToUse = {};
        if (secondary.C0787_Codice_pagamento__c && triplet == 'secondary') {
            tripletToUse = secondary;
            console.log('orderLinesView.handlePaymentTriplets-secondary::'+JSON.stringify(tripletToUse));
          } else {
            tripletToUse = primary;
            console.log('orderLinesView.handlePaymentTriplets-primary::'+JSON.stringify(tripletToUse));
          }
        for(let key in tripletToUse){
            console.log('tripletKey: '+key+'\tvalue:'+tripletToUse[key])
            this.setValueOnRecord(key,tripletToUse[key]);
        }

        this.showToast('Success!',/*PaymentTripletUpdate*/'Payment Triplet Updated','success');
    }

    handleNoteDeleted(event){
        console.log('orderHeaderConfigurator.handleDeleteNote');
        let newList = event.detail;
        console.log('orderHeaderConfigurator.handleDeleteNote-list:: '+JSON.stringify(newList));
        this.noteList = newList;
    }

    generateUniqueId() {
        return Date.now().toString(36) + Math.floor(Math.pow(10, 12) + Math.random() * 9 * Math.pow(10, 12)).toString(36)
    }

    priceRuleTrackedField = ['Incoterm__c','Incoterm_Norm__c','Incoterm_variant__c'];

    async handleHeaderPriceRule() {
        let businessCountry = this.orderHeader?.Business_Country_Code__c;
        let incoterm = this.orderHeader?.Incoterm__c;
        let incotermNorm = this.orderHeader?.Incoterm_Norm__c;
        let incotermVariant = this.orderHeader?.Incoterm_variant__c;

        let payload = {
            businessCountry: businessCountry,
            incoterm: incoterm,
            incotermNorm: incotermNorm,
            incotermVariant: incotermVariant
        };
        console.log('handleHeaderPriceRule-payload:: '+JSON.stringify(payload));
        try {
            let result = await getHeaderPriceRuleOutput({
                searchInput: JSON.stringify(payload)
            });
            console.log('handleHeaderPriceRule-output:: '+JSON.stringify(result));
            if (result && result.targetField) {
                this.setValueOnRecord(result.targetField, result.value+"");
            } else if (!result.targetField) {
                this.setValueOnRecord('C0793T_Spese_di_trasporto_a_carico__c', '');
            }
            
        } catch (error) {
            console.error('An error occurred while recovering pricerule:: '+JSON.stringify(error))
        }


    }

    @api
    async getOrderGroupOptions(prods,shipSite){
        console.log('orderHeaderConfigurator.getOrderGroupOptions');
        console.log('orderHeaderConfigurator.getOrderGroupOptions-prods:: '+JSON.stringify(prods));

        console.log('orderHeaderConfigurator.getOrderGroupOptions-shipSite:: '+JSON.stringify(shipSite));
        let businessCountry = this.orderHeader.Business_Country_Code__c;

        let payload = {
            businessCountry: businessCountry,
            productCodes: prods,
            shipmentSite: shipSite
           
        };
        console.log('orderHeaderConfigurator.getOrderGroupOptions-payload:: '+JSON.stringify(payload));
        if(shipSite){
            let groupOptions = await getOrderGroupsByFilters({searchInput: JSON.stringify(payload)});
            if(groupOptions){
                console.log('orderHeaderConfigurator.getOrderGroupOptions-groupOptions:: '+JSON.stringify(groupOptions));
                
                let specialFields = this.template.querySelectorAll('c-configurator-special-field');
                if(specialFields){
                    specialFields.forEach(field => {
                        //console.log('orderHeaderConfigurator.getOrderGroupOptions-groupOptionssetting:: '+JSON.stringify(groupOptions));
                        field.options = groupOptions
                    });
                    if(groupOptions.length == 2){
                        console.log('orderHeaderConfigurator.getOrderGroupOptions:: size is 1');
                        let notNoneOption = groupOptions.filter(opt => !opt.label.includes('--None--'))[0];
                        console.log('orderHeaderConfigurator.getOrderGroupOptions-notNoneOption:: '+JSON.stringify(notNoneOption));
                        this.specialFieldValues = {field:'C0003T_Raggruppamento_Conferma__c',value:notNoneOption?.value}
                        this.setValueOnRecord('C0003T_Raggruppamento_Conferma__c',notNoneOption?.value);
                        await this.setOrderGroupDefaults(notNoneOption?.value);
                    }else{
                        console.warn('many options available');
                    }
                }else{
                    console.warn('no special field found!');
                }
            }
        }else{
            console.warn('No shipmentSiteSelected!');
            let specialFields = this.template.querySelectorAll('c-configurator-special-field');
                if(specialFields){
                    specialFields.forEach(field => field.options = {value:'',label:'--None--'});
                    this.specialFieldValues = {field:'C0003T_Raggruppamento_Conferma__c',value:''}
                    this.setValueOnRecord('C0003T_Raggruppamento_Conferma__c','');
        }
    }
        
    }

    async setOrderGroupDefaults(value){
        let searchInput={
            targetObject:'Order',
            orderGroup:value,
            businessCountry:this.orderHeader?.Business_Country_Code__c
        }
        console.log('handleFieldChange-searchInput:: '+JSON.stringify(searchInput));
        try {
            let defaultValues=await getDefaultValuesByFilters({input:JSON.stringify(searchInput)});
            console.log('orderHeaderConfigurator.defaultValues:: '+JSON.stringify(defaultValues));
            this.manageDefaultValues(defaultValues);
        } catch (error) {
            console.error('An error occurred while retrieve orderGroup default');
        }
    }

    
    
}