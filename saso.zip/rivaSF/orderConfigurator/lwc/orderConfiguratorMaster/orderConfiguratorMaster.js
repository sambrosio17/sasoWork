import {
	LightningElement,
	api,
	wire
} from "lwc";
import {
	getRecord
} from "lightning/uiRecordApi";
import currentUserId from '@salesforce/user/Id';
import NAME_FIELD from '@salesforce/schema/User.Name';
import ORDER_NAME from '@salesforce/schema/Order.OrderNumber'
import AddAttachmentModal from "c/addAttachmentModal";
import CreateLocationModal from "c/createLocationModal";
import {
	ShowToastEvent
} from 'lightning/platformShowToastEvent';
import linkAttachmentsToOrder from '@salesforce/apex/OrderConfiguratorController.linkAttachmentsToOrder'

import {
	NavigationMixin
} from 'lightning/navigation';
import {
	CurrentPageReference
} from 'lightning/navigation';
import getAgreementWithLines from "@salesforce/apex/OrderConfiguratorController.getAgreementWithLines";
import * as orderConfiguratorSingleton from "c/orderConfiguratorSingleton";
import getOverrides from '@salesforce/apex/CloneExistingOrderController.getOverrides'
import LightningConfirm from 'lightning/confirm';
import OrderConfirmationAlert from "@salesforce/label/c.OrderConfirmationAlert"
import OrderClosureAlert from "@salesforce/label/c.OrderClosureAlert"
import propagateOrderData from "@salesforce/apex/FidoWebservice.propagateOrderData"

export default class OrderConfiguratorMaster extends NavigationMixin(LightningElement) {
	@api recordId;
	@api objectApiName;
	@api showSpinner;

	@api
	agreementLines;

	@api
	agreementWrapper;

	@api
	locId;
	@api
	deliveryLocationId;
	@api
	isclone;

	salesAgreementId;

	selectedOrderId;

	//orderOverrides;

	dropdownClass;
	dropdownStatus;

	currentDate;
	currentTime;

	currentUsername;

	fileToSave;
	fileToDelete;

	_startTime;
	constructor() {
		super();
		window.addEventListener('beforeunload', (event) => {
			console.log('sto unloadando');
			// Cancel the event as stated by the standard.
			event.preventDefault();
			window.alert('wee bello non chiudere');
			// Chrome requires returnValue to be set.
			event.returnValue = 'sample value';
		});
	}

	@wire(CurrentPageReference)
	async getStateParameters(currentPageReference) {
		if (currentPageReference) {
			this.salesAgreementId = currentPageReference.state?.c__id;
			console.log('getStateParameters:: ' + this.salesAgreementId);
			this.selectedOrderId = currentPageReference.state?.c__orderid;
			this.isclone = this.selectedOrderId != null
			console.log('selectedOrderId:: ' + this.selectedOrderId);
			//this.setOrderOverrides();
		}
	}

	@wire(getRecord, {
		recordId: currentUserId,
		fields: [NAME_FIELD]
	})
	getUserInfo({
		data,
		error
	}) {
		if (data) {
			console.log('namefield: ' + NAME_FIELD)
			this.currentUsername = data.fields.Name.value;
		} else {
			this.currentUsername = 'error';
		}
	}


	async setOrderOverrides() {
		
		console.log('OrderConfiguratorMaster.setOrderOverrides::');
		let params = {
			orderId: this.selectedOrderId
		};
		console.log('OrderConfiguratorMaster.setOrderOverrides.params::'+JSON.stringify(params));
        let orderOverrides = await getOverrides({params: params});
        await console.log('orderOverrides => '+JSON.stringify(orderOverrides))
        await orderConfiguratorSingleton.setInstanceData(this.selectedOrderId);

		let instance = await orderConfiguratorSingleton.getInstanceData();
		await console.log('OrderConfiguratorMaster.orderConfiguratorSingleton.instance ::'+JSON.stringify(instance));
		
	}

	//@wire(CurrentPageReference)
	async connectedCallback(currentPageReference) {
		console.log('Hello World:: OrderConfiguratorMaster');
		this._startTime = new Date().getTime();
		this.showToast('Success!!','Start time: '+this._startTime,'success');
		/*if (currentPageReference) {
			this.selectedOrderId = currentPageReference.state?.c__orderid;
			if(this.selectedOrderId != null ){
				this.isclone = true;
				// Initialize Order Configurator Singleton
				console.log('OrderConfiguratorMaster.connectedCallback.selectedOrderId = '+this.selectedOrderId);
				let params = {
					orderId: this.selectedOrderId
				};
				
				console.log('OrderConfiguratorMaster.getOverrides.params::'+JSON.stringify(params));
				 
				let orderOverrides = await getOverrides({params: params});
				
				await orderConfiguratorSingleton.setInstanceData(orderOverrides);

				let instance = await orderConfiguratorSingleton.getInstanceData();
				console.log('OrderConfiguratorMaster.connectedCallback.instance ::'+JSON.stringify(instance));

			}else{
				//this.isclone = false;
			}
		}*/

		//initialize
		this.showSpinner = true;
		this.dropdownStatus = false;
		this.dropdownClass = 'slds-builder-header__nav-item slds-dropdown-trigger slds-dropdown-trigger_click slds-is-close'

		this.currentDate = new Date().toLocaleDateString();

		this.currentTime = new Date().getHours().toString().padStart(2, "0") + ':' + new Date().getMinutes().toString().padStart(2, "0");
		setInterval(() => {
			this.currentTime = new Date().getHours().toString().padStart(2, "0") + ':' + new Date().getMinutes().toString().padStart(2, "0");
		}, 1000)

		//this.agreementWrapper=await getAgreementWithLines({agreementId:this.salesAgreementId});

	}

	handleDropdown(event) {
		console.log('click dropdown:: ' + this.dropdownClass);
		console.log('click dropdown:: ' + this.dropdownStatus);
		let classToManage = this.dropdownStatus ? 'slds-is-open' : 'slds-is-close';
		this.template.querySelector('[data-id="dropdownSection"]').classList.remove(classToManage);
		this.dropdownStatus = !this.dropdownStatus;
		classToManage = this.dropdownStatus ? 'slds-is-open' : 'slds-is-close';
		this.template.querySelector('[data-id="dropdownSection"]').classList.add(classToManage);
		console.log('click dropdown after:: ' + this.dropdownClass);
		console.log('click dropdown after:: ' + this.dropdownStatus)
	}

	handleAttachFile(event) {
		console.log('handleAttachFile:: ');
		event.preventDefault();
		const result = AddAttachmentModal.open({
			size: 'small',
			uploadedFiles: this.fileToSave,
			removed: this.fileToDelete,
			onmodalsave: (e) => {
				e.stopPropagation();
				this.fileToSave = e.detail.toBeAdded;
				this.fileToDelete = e.detail.toBeRemove;
				if (this.recordId && this.recordId.length > 0) {
					this.linkAttachmentToOrder();
				}
				console.log('handleAttachFile-modalSave::' + JSON.stringify(e.detail))
				this.showToast('Success!', 'File(s) added succesfully!', 'success');
			}
		})
	}
	showToast(label, msg, type) {
		const event = new ShowToastEvent({
			title: label,
			message: msg,
			variant: type,
			mode: 'dismissable'
		});
		this.dispatchEvent(event);
	}

	async handleSave(event) {
		console.log('handling save QS: '+this.quickSave);
		event.preventDefault();
		this.showSpinner = true;
		let promptResult;
		let elapsed = new Date().getTime() - this._startTime;
		this.showToast('Success!!','Elapsed:: '+elapsed,'success');
		if(!this.quickSave){
			promptResult= await this.showConfirmationPrompt(OrderConfirmationAlert);
		}
		if(promptResult || this.quickSave){
			console.log('orderConfiguratorMaster.handleSave:: ');
			let lrc = this.template.querySelector('c-order-header-configurator').formData;
			console.log('orderConfiguratorMaster.handleSave-return:: ' + JSON.stringify(lrc));
			this.template.querySelector('c-order-header-configurator').handleSaveOrder(lrc);
			//this.quickSave = false;
		}else{
			this.showSpinner = false;
		}
		
	}

	handleChildLoad(event) {
		console.log('OrderConfiguratorMaster.handleChildLoad::');
		this.showSpinner = event.detail;
	}

	handleOrderSaved(event) {
		console.log('OrderConfiguratorMaster.handleOrderSaved::');
		if (event.detail == null) {
			this.showSpinner = false;
			return;
		}
		this.recordId = event.detail;
		console.log('OrderConfiguratorMaster.handleOrderSaved--record::' + this.recordId);
		if (this.recordId && this.recordId.length > 0) {
			this.showSpinner = false;
		}
	
		// Assuming these functions return promises
		const linkAttachmentPromise = this.linkAttachmentToOrder();
		const saveLinesPromise = this.saveLines(this.recordId);
		const saveNotesPromise = this.saveNotes(this.recordId);
		const deleteLinesPromise = this.deleteLines();
	
		Promise.all([linkAttachmentPromise, saveLinesPromise, saveNotesPromise,deleteLinesPromise])
			.then(() => {
				this.showToast('Success!', 'Order created successfully!', 'success');
				if (!this.quickSave) {
					this.navigateToRecord(this.recordId);
					this.sendOrderToERP(this.recordId);
				} else {
					this.showSpinner = false;
					this.quickSave = false;
				}
			})
			.catch(error => {
				console.error('Error in saving records:', error);
				this.showToast('Error!', 'Failed to create order records', 'error');
				this.showSpinner = false;
			});
	}	
	

	async linkAttachmentToOrder() {
		console.log('OrderConfiguratorMaster.linkAttachmentToOrder::');
		let response = await linkAttachmentsToOrder({
			attachs: JSON.stringify(this.fileToSave),
			removed: JSON.stringify(this.fileToDelete),
			orderId: this.recordId
		});
		this.fileToDelete = [];
		console.log('OrderConfiguratorMaster.linkAttachmentToOrder::' + response);
		return response;
	}

	async saveLines(recordId) {
		let lineCmp = this.template.querySelector('c-order-lines-view').saveLines(recordId);
		return lineCmp;
	}

	async saveNotes(recordId) {
		let noteCmp = this.template.querySelector('c-order-header-configurator').saveChildNotes(recordId);
		return noteCmp;
	}

	//03-09-24 - saambrosio@deloitte.it - START:: added method to delete lines in edit mode
	async deleteLines(){
		let lineCmp = this.template.querySelector('c-order-lines-view').doDeleteLines();
		return lineCmp
	}
	//03-09-24 - saambrosio@deloitte.it - END:: added method to delete lines in edit mode

	handleInitOrder(event) {
		console.log('orderConfiguratorMaster.handleInitOrder::' + JSON.stringify(event.detail))
		this.agreementLines = JSON.stringify(event.detail);
		/*if(event.detail!=null){
			this.agreementLines=event.detail;
			console.log('orderConfiguratorMaster.handleInitOrder::'+JSON.stringify(this.agreementLines));
		}*/
	}

	async handleLocationChange(event) {
		console.log('orderConfiguratorMaster.handlelocationChange::' + JSON.stringify(event.detail))
		this.locId = event.detail;
		console.log('orderConfiguratorMaster.handlelocationChange--::' + JSON.stringify(this.locId));
		await this.prepareOrderGroupOptions();
	}

	async prepareOrderGroupOptions() {
		console.log('orderConfiguratorMaster.prepareOrderGroupOptions::');

		let orderLinesView = this.template.querySelector('c-order-lines-view');

		if (orderLinesView) {
			let lines = orderLinesView.getLines();
			let lineCodes = [];
			lines.forEach(prod => {
				lineCodes.push(prod.Product_Code__c);
			})
			let orderHeaderConfigurator = this.template.querySelector('c-order-header-configurator');
			if (orderHeaderConfigurator) {
				orderHeaderConfigurator.getOrderGroupOptions(lineCodes,this.locId);
			}
		}


	}

	navigateToRecord(recordId) {
		this[NavigationMixin.Navigate]({
			type: "standard__recordPage",
			attributes: {
				recordId: recordId,
				actionName: "view",
			},
		});
	}

	handleCreateLocation(event){
		event.preventDefault();
		let accountId = this.template.querySelector('c-order-header-configurator').accountId;
		console.log('orderConfiguratorMaster.handleCreateLocation:: '+accountId);
		CreateLocationModal.open({
			label:'Create Location',
			inputVariables:[{
				name:'recordId',
				type:'String',
				value:accountId
			}],
			onlocationcreated: (e) => {
				e.stopPropagation();
				console.log('locationCreated:: '+JSON.stringify(e.detail));
				this.template.querySelector('c-order-header-configurator').deliveryAddress=e.detail?.location;
				this.template.querySelector('c-order-header-configurator').specialFieldValues={
					field:'C0141_Shipment_Location__c',
					value:e.detail?.associatedLocation
				}
			}
		})
	}

	handleDeliveryChange(event){
		console.log('orderConfiguratorMaster.handleDeliveryChange:: '+JSON.stringify(event.detail));
		this.deliveryLocationId=event.detail;
		console.log('orderConfiguratorMaster.handleDeliveryChange-post:: '+this.deliveryLocationId);
	}

	async showConfirmationPrompt(msg){
		return await LightningConfirm.open({
            message: msg,
            theme: 'warning',
            //theme: 'info',
            //label: 'Warning!', //this is optional
            //cancelLabel: 'No', //this is optional
            //confirmLabel: 'Yes' //this is optional
            //theme defaults to "default"
            label: 'Warning!!', // this is the header text
        });
	}

	async handleClose(event){
		console.log('handling close');
		let result=await this.showConfirmationPrompt(OrderClosureAlert);
		if(result){
			this.navigateToRecord(this.salesAgreementId)
		}else{
			this.showSpinner=false;
		}
			
	}

	handleMeasureChange(event){
		console.log('orderConfiguratorMaster.handleMeasureChanged:: '+JSON.stringify(event.detail));
		let orderLines=this.template.querySelector('c-order-lines-view');
		if(orderLines){
			orderLines.orderUnitOfmeasure=event.detail;
		}
	}

	quickSave;
	async handleQuickSave(event){
		this.quickSave=true;
		this.handleSave(event);
	
	}

	handleLineRemoved(event){
		console.log('handleLineRemoved::')
		console.log('handleLineRemoved-detail::'+JSON.stringify(event.detail));
		let lines=event.detail?.lines;
		let keys=Object.keys(lines);

		let orderHeaderConfigurator = this.template.querySelector('c-order-header-configurator');
		if(orderHeaderConfigurator){
			orderHeaderConfigurator.setUpdateValidShipmentSites(keys);
			this.prepareOrderGroupOptions();
		}
	}

	handleLineAdded(event){
		console.log('orderCOnfiguratorMaster.handleLineAdded::');
		let orderHeaderConfigurator = this.template.querySelector('c-order-header-configurator');
		if(orderHeaderConfigurator){
			this.prepareOrderGroupOptions();
		}
	}

	async sendOrderToERP(orderId){
		console.log('orderConfiguratorMaster.sendOrderToERP:: '+orderId);
		try {
			let requestBody={
				orderId:orderId
			}
			let resp = await propagateOrderData({request:requestBody});
			console.log('sendOrderToERP.response:: '+JSON.stringify(resp));
		} catch (error) {
			console.error('An error occurred while sending order to ERP. Order Id: '+orderId);
		}

	}

	handleTripletChange(event){
		console.log('orderConfiguratorMaster.handleTripletChange:: '+JSON.stringify(event.detail));
		let triplet = event.detail?.detail?.triplet;
		let orderHeaderConfigurator = this.template.querySelector('c-order-header-configurator');
		if(orderHeaderConfigurator && triplet){
			console.log('orderConfiguratorMaster.settingTriplet:: ');
			orderHeaderConfigurator.setPaymentTriplet(triplet);
		}
	}
	
	disconnectedCallback(){
		console.log('Master is disconnecting');
	}

	managedProductWihLigtingBelts=['85'];
	async handlePurchasingGroupSet(event) {
		console.log(
			'orderConfiguratorMaster.handlePurchasingGroupSet:: ' + JSON.stringify(event.detail)
		);
		let isPurchasingGroup = event.detail ?.isPurchasingGroup;
		let orderHeaderConfigurator = this.template.querySelector('c-order-header-configurator');
		let orderLinesView = this.template.querySelector('c-order-lines-view');
		if (orderLinesView) {
			let lines = orderLinesView.getLines();
			let filteredLines = lines.filter(line => this.managedProductWihLigtingBelts.includes(line.Product_Code__c));
			console.log(
				'orderConfiguratorMaster.handlePurchasingGroupSet:: ' + JSON.stringify(filteredLines)
			);
			if (filteredLines.length > 0) {
				if (orderHeaderConfigurator) {
					await orderHeaderConfigurator.setPaymentTriplet('secondary');
				}
			} else {
				if (orderHeaderConfigurator) {
					await orderHeaderConfigurator.setPaymentTriplet('primary');
				}
			}
			console.log(
				'orderConfiguratorMaster.handlePurchasingGroupSet:: ' + JSON.stringify(lines)
			);
		}
	}
}