import { LightningElement, api, wire } from "lwc";
import getConfiguratorFields from "@salesforce/apex/OrderConfiguratorController.getConfiguratorFields";
import AddProductModal from "c/addProductModal";
import getAgreementWithLines from "@salesforce/apex/OrderConfiguratorController.getAgreementWithLines";
import createOrderLines from "@salesforce/apex/OrderConfiguratorController.createOrderLines"
import initOrder from "@salesforce/apex/OrderConfiguratorController.initOrder"
import * as orderConfiguratorSingleton from "c/orderConfiguratorSingleton";
import getPricebookEntryByProductCodeAndPricebookId from"@salesforce/apex/OrderConfiguratorController.getPricebookEntryByProductCodeAndPricebookId";
import getOverrides from "@salesforce/apex/CloneExistingOrderController.getOverrides";
import doDeleteOrderLines from "@salesforce/apex/OrderConfiguratorController.doDeleteOrderLines";
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
export default class OrderLinesView extends LightningElement {
    @api
    columns /*= [
        {
          label: "Product",
          fieldName: "Name",
          hideDefaultActions: true,
          wrapText: true
        },
        {
          label: "List Price",
          fieldName: "ListPrice",
          type: "currency",
          editable: false,
          hideDefaultActions: true
        },
        {
          label: "Initial Total Quantity",
          fieldName: "InitialPlannedQuantity",
          type: "number",
          editable: true,
          hideDefaultActions: true,
          cellAttributes: {
            required: true
          }
        },
        {
          label: "Sales Price",
          fieldName: "SalesPrice",
          type: "currency",
          editable: true,
          hideDefaultActions: true
        },
        {
          label: "Discount Percentage",
          fieldName: "DiscountPercentage",
          type: "number",
          editable: true,
          hideDefaultActions: true
        },
        {
          label: "Planned Amount",
          fieldName: "InitialPlannedAmount",
          type: "currency",
          editable: true,
          hideDefaultActions: true
        }
      ];*/
      @api
      lines = []/* = [{
        uniqueId:Date.now().toString(36) + Math.floor(Math.pow(10, 12) + Math.random() * 9*Math.pow(10, 12)).toString(36),
        OrderItemNumber:'OL-0001',
        Product2Id:'Vergelle',
        Quantity:200,
        C06256_Qnt_ordinata_unita_di_misura__c:200,
        T0002_Misura_1__c:'Ton',
        C0121_Prezzo__c:17000,
        C0122_Prezzo_Extra__c:1200,
        C0120_Tipologia_Prezzo__c:'Base + Extra',
        TotalPrice:18200
      }];*/

      @api getLines(){
        return this.lines;
      }
      
      @api
      fieldsList;
      @api
      error;

      @api
      finalTotal=0;

      @api
      agreement

      @api
      pricebookId;
      @api isClone;
      @api sourceOrder;

      /*@api
      orderUnitOfmeasure;*/

      _orderUnitOfmeasure;

      isSaving;
      @api get orderUnitOfmeasure(){
        return this._orderUnitOfmeasure;
      }

      set orderUnitOfmeasure(value){
        this._orderUnitOfmeasure=value;
        //this.recalculateBasedOnUnitMeasureChange(value.oldValue,value.newValue)
      }

      recalculateBasedOnUnitMeasureChange(oldValue, newValue) {
        if(this.isSaving){
          return;
        }
        let qtyConversionFactor;
        let priceConversionFactor;
        if (oldValue == 'TN' && newValue == 'KG') {
          qtyConversionFactor = 10;
          priceConversionFactor = 0.1;
        }
        if (oldValue == 'KG' && newValue == 'TN') {
          qtyConversionFactor = 0.1;
          priceConversionFactor = 10;
        }
        if(oldValue==newValue){
          qtyConversionFactor=1;
          priceConversionFactor=1;
        }
        let tempLines=JSON.parse(JSON.stringify(this.lines));
        tempLines.forEach(el => {
          console.log('recalculatingUM:: '+el.C06256_Qnt_ordinata_unita_di_misura__c )
          el.C06256_Qnt_ordinata_unita_di_misura__c = el.C06256_Qnt_ordinata_unita_di_misura__c*qtyConversionFactor;
          /*let convQTY=this.doConvertToUnitOfMeasure(newValue,el.C06256_Qnt_ordinata_unita_di_misura__c);
          console.log('recalculating::: '+convQTY);
          el.Quantity=convQTY;*/
          el.C0121_Prezzo__c = el.C0121_Prezzo__c*priceConversionFactor;
          if(el.C0122_Prezzo_Extra__c){
            el.C0122_Prezzo_Extra__c = C0122_Prezzo_Extra__c *priceConversionFactor;
          }
        })

        this.lines=tempLines;
      }

      doConvertToUnitOfMeasure(unitOfMeasure,value){
        console.log('orderLinesView.doConvertToUnitOfMeasure:: ')
        console.log('orderLinesView.doConvertToUnitOfMeasure-UOM:: '+unitOfMeasure)
        console.log('orderLinesView.doConvertToUnitOfMeasure-value:: '+value)
        if(unitOfMeasure=='TN'){
            return value;
        }
        if(unitOfMeasure=='KG'){
            return value/1000;
        }/*if(unitOfMeasure=='NR' && this.productRecord?.['WeightInKGOfUnit__c']){
            return value*parseFloat(this.productRecord?.['WeightInKGOfUnit__c'] || 0)/1000;
        }*/
        return value;
    }

      managedProductWihLigtingBelts=['85'];

      actions=[
        {
            type:'button-icon',
            fixedWidth:20,
            typeAttributes:{
                title:'Edit Line',
                name:'edit_line',
                iconName:'utility:edit',
                iconClass:'slds-icon_x-small',
                variant:'bare'
            }
        },
        {
            type:'button-icon',
            fixedWidth:20,
            typeAttributes:{
                title:'Clone Line',
                name:'clone_line',
                iconName:'utility:copy',
                iconClass:'slds-icon_x-small',
                variant:'bare'
            }
        },
        {
            type:'button-icon',
            fixedWidth:20,
            typeAttributes:{
                title:'Delete Line',
                name:'delete_line',
                iconName:'utility:delete',
                iconClass:'slds-icon_x-small slds-icon-text-error',
                variant:'bare'
            }
        },
      ]

      @api
      location;
      @api
      deliverylocid;

      @wire(getConfiguratorFields,{objectName:'OrderItem',fieldSetName:'OrderLineView'})
      getFields(data,error){
        if(data){
            this.fieldsList=data.data;
            console.log('orderLinesView.getConfiguratorFields::'+JSON.stringify(this.fieldsList));
            if(this.fieldsList)
                this.mapFieldsToColumn(this.fieldsList);
        }else{
            this.error=error;
        }
      }

      connectedCallback(){
        console.log('orderLinesView:: '+this.agreement);
        console.log('orderLinesView.isClone:: '+this.isClone);
        console.log('orderLinesView.sourceClone:: '+this.sourceOrder);
        this.doInitLines();
        //this.initLines()
    
        
      }

      renderedCallback(){
        console.log('orderLinesView-renderd:: '+JSON.stringify(this.agreement));
      }

      mapFieldsToColumn(data){
        console.log('orderLinesView.mapFieldsToColumn:: '+JSON.stringify(data));
        let columns=[];
        data.forEach(f => {
            console.log('orderLinesView.mapFieldsToColumn:: '+JSON.stringify(f));
            let single={};
            single.label=f.fieldLabel;
            single.fieldName=f.fieldApiName;
            single.type=f.fieldType.toLowerCase();
            if(single.type === 'percent'){
                single.type = 'number';
            }
            single.hideDefaultActions=true;
            columns.push(single);
        })
        columns.push(...this.actions);
        this.columns=columns;
        console.log('orderLinesView.mapFieldsToColumn:: '+JSON.stringify(this.columns));
      }

      handleRowAction(event){
        console.log('orderLinesView.handleRowAction:: ');
        const action = event.detail.action.name;
        const row = event.detail.row;
        const rowId = row.uniqueId;
        console.log('orderLinesView.handleRowAction-action:: '+JSON.stringify(action));
        console.log('orderLinesView.handleRowAction-row:: '+JSON.stringify(row));
        switch(action){
            case 'edit_line': this.handleEdit(row,rowId); break;
            case 'delete_line':this.handleDelete(row,rowId); break;
            case 'clone_line':this.handleClone(row,rowId); break;
        }
        this.calculateFinalTotal();
        
      }

      //03-09-24 - saambrosio@deloitte.it - START:: added method to delete lines in edit mode
      _deletedLines = [];

      @api get deletedLines(){
        return this._deletedLines;
      }

      set deletedLines(value){
        this._deletedLines = value;
      }

      @api async doDeleteLines(){
        try {
          console.log('orderLinesView.doDeleteLines:: '+JSON.stringify(this.deletedLines));
          if(this.deletedLines.length > 0){
            console.log('orderLinesView.doDeleteLines:: lenght > 0 ');
            let serialized = JSON.stringify(this.deletedLines);
            //let deleteOrderLines = await deleteOrderLines({orderLines: serialized});
            let deleteLinesResponse = await doDeleteOrderLines({orderLines:serialized});
            this.deletedLines = [];
          }
          
        } catch (error) {
            console.error('An error occured while deleting lines:: '+JSON.stringify(error));
          
        }
      }

      //03-09-24 - saambrosio@deloitte.it - END:: added method to delete lines in edit mode
      handleDelete(row,rowId){
        console.log('orderLinesView.handleDelete:: ');
        let handleLigtingBelts=false
        this.lines.forEach(el => {
          if(el.uniqueId === rowId){
            handleLigtingBelts=this.managedProductWihLigtingBelts.includes(el.Product_Code__c);

            //03-09-24 - saambrosio@deloitte.it - START:: added method to delete lines in edit mode
            if(el.Id){
              console.log('orderLinesView.handleDelete-delete existing line:: '+JSON.stringify(el));
              let tempDeletedLines = JSON.parse(JSON.stringify(this.deletedLines));
              tempDeletedLines.push({Id:el.Id});
              this.deletedLines = tempDeletedLines;
              console.log('orderLinesView.handleDelete-deletedLinesId'+JSON.stringify(this.deletedLines));
            }
            //03-09-24 - saambrosio@deloitte.it - END:: added method to delete lines in edit mode
          }
        });
        let filtered=this.lines.filter(el => el.uniqueId!=rowId);
        /*let initialValue=0;
        let totalPriceTotal=filtered.reduce((acc, el)=>acc+el.TotalPrice,initialValue);
        filtered.push({TotalPrice:totalPriceTotal});*/
        this.lines=filtered;
        console.log('handleDelete-finish');
        if(handleLigtingBelts){
          this.handleLigtingBeltsOnList();
          let meshes = filtered.filter(el => el.Product_Code__c == '85');
          if(meshes.length == 0){
            this.handlePaymentTriplets('primary');
          }
        }
        this.dispatchLineRemovedEvent();
        /*if(getRow.length > 0 && this.managedProductWihLigtingBelts.includes(getRow[0]?.Product_Code__c))
            this.handleLigtingBeltsOnList()*/
      }

      handleClone(row,rowId){
        console.log('orderLinesView.handleClone:: ');
        let tempData=JSON.parse(JSON.stringify(this.lines));
        row.uniqueId=Date.now().toString(36) + Math.floor(Math.pow(10, 12) + Math.random() * 9*Math.pow(10, 12)).toString(36);
        //13-11-2024 - saambrosio@deloitte.it - START:: fix saved line clone
        delete row.Id;
        delete row.OrderItemNumber;
        //13-11-2024 - saambrosio@deloitte.it - END:::: fox saved line clone
        tempData.push(row);
        /*let initialValue=0;
        let totalPriceTotal=tempData.reduce((acc, el)=>acc+el.TotalPrice,initialValue);
        tempData.push({TotalPrice:totalPriceTotal});*/
        this.lines=tempData;
        if(this.managedProductWihLigtingBelts.includes(row?.Product_Code__c))
          this.handleLigtingBeltsOnList();
      }

      handleEdit(row,rowId){
        console.log('orderLinesView.handleEdit:: '+JSON.stringify(row));
        console.log('orderLinesView.handleEdit--loc:: '+this.location);
        console.log('orderLinesView.handleEdit--deliveryLoc:: '+this.deliverylocid);
        console.log('orderLinesView.handleEdit-bc:: '+this.orderWrapper?.orderHeader?.Business_Country__c)
        console.log('orderLinesView.handleEdit-priceMeasure:: '+this.orderUnitOfmeasure.priceMeasure)
        AddProductModal.open({
          size:'large',
          label:'Edit Lines',
          locationId:this.location,
          deliveryLocationId:this.deliverylocid,
          businessCountry:this.orderWrapper?.orderHeader?.Business_Country__c,
          orderUnitOfMeasure:this.orderUnitOfmeasure.newValue,
            //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
            priceUnitOfMeasure:this.orderUnitOfmeasure.priceMeasure,
            //29-10-2024 - saambrosio@deloitte.it - END:: Managing different unit of measure for BEL and DEU
          editProduct:row,
          orderWrapper:this.orderWrapper?.productLimitations,
          isTrader:this.orderWrapper?.isTrader,
          oneditrecord:async (e) =>{
            e.stopPropagation();
              console.log('onaddrecordn-edit: '+JSON.stringify(e.detail));
              this.handleEditRecord(e.detail)
              if(this.managedProductWihLigtingBelts.includes(e.detail?.Product_Code__c))
                await this.handleLigtingBeltsOnList();
          }
      })
      }

      generateUniqueId(){
        return Date.now().toString(36) + Math.floor(Math.pow(10, 12) + Math.random() * 9*Math.pow(10, 12)).toString(36)
      }

      //04-09-24 - saambrosio@deloitte.it - START:: adding total for weight
      @api finalWeight=0;
      //04-09-24 - saambrosio@deloitte.it - END:: adding total for weight
      calculateFinalTotal(){
        console.log('orderLinesView.calculateFinalTotal:: ')
        let initialValue=0;
        this.finalTotal=this.lines.reduce((acc, el)=>acc+parseFloat(el.TotalPrice || 0),initialValue);
        //04-09-24 - saambrosio@deloitte.it - START:: adding total for weight
        this.finalWeight=this.lines.reduce((acc,el)=>acc+parseFloat(el.Product_Code__c === 'EL' ? 0 : el.Quantity || 0),initialValue);
        console.log('orderLinesView.calculateFinalTotal-totalWeight:: '+this.finalWeight);
        //04-09-24 - saambrosio@deloitte.it - END:: adding total for weight
        console.log('orderLinesView.calculateFinalTotal-total:: '+this.finalTotal);
      }
      

      handleAddProducts(event){
        console.log('orderLinesView.handleAddProducts:: ');
        console.log('orderLinesView.handleAddProducts-loc:: '+this.location);
        console.log('orderLinesView.handleAddProducts--deliveryLoc:: '+this.deliverylocid);
        console.log('orderLinesView.handleAddProducts-bc:: '+this.orderWrapper?.orderHeader?.Business_Country__c);
        console.log('orderLinesView.handleAddProducts-UM:: '+JSON.stringify(this.orderUnitOfmeasure));
        if(!this.location){
            this.showToast('Warning!','Select Shipment Site before adding products','warning');
            return;
        }
        if(!this.orderUnitOfmeasure.newValue){
          this.showToast('Warning!','Select Order Unit of Measure before adding products','warning');
          return;
      }
        AddProductModal.open({
            size:'large',
            label:'Add Products',
            pricebookId:this.pricebookId,
            locationId:this.location,
            deliveryLocationId:this.deliverylocid,
            businessCountry:this.orderWrapper?.orderHeader?.Business_Country__c,
            orderUnitOfMeasure:this.orderUnitOfmeasure.newValue,
            //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
            priceUnitOfMeasure:this.orderUnitOfmeasure.priceMeasure,
            //29-10-2024 - saambrosio@deloitte.it - END:: Managing different unit of measure for BEL and DEU
            viewMode:'ADD',
            orderWrapper:this.orderWrapper?.productLimitations,
            isTrader:this.orderWrapper?.isTrader,
            onaddrecord: async (e) =>{
              e.stopPropagation();
              console.log('onaddrecordn: '+JSON.stringify(e.detail));
              this.handleAddRecord(e.detail);
              if(this.managedProductWihLigtingBelts.includes(e.detail?.Product_Code__c)){
                await this.handleLigtingBeltsOnList();
                
              }
                
            }
        })
      }

      async initLines(){
        console.log('orderLinesView.initLines::');
        const wrapper=await getAgreementWithLines({agreementId:this.agreement});
        if(wrapper){
						this.pricebookId=wrapper?.agreement?.PricebookId;
						if(wrapper.isTrader && this.pricebookId===undefined){
							  this.showToast('Warning!','Current Trader has no active Pricebook','warning');
								return;
						}
						const lines=wrapper?.lines;
						this.pricebookId=wrapper?.agreement?.PricebookId;
						let orderLines=[];
						console.log('orderLinesView.initLines-lines::'+JSON.stringify(lines));
						lines.forEach(line => {
								let single={};
								single.Product_Code__c=line.Product?.ProductCode;
								single.Product_Name__c=line.Name;
								single.Quantity=line.InitialPlannedQuantity;
								//single.T0002_Misura_1__c=line.PricebookEntry?.Unit_of_Measure__c;
								single.C06256_Qnt_ordinata_unita_di_misura__c=line.InitialPlannedQuantity;;
								single.Pricing_Type__c=line.PricebookEntry?.Pricing_Type__c;
								single.C0121_Prezzo__c=line.SalesPrice;
								single.UnitPrice=line.SalesPrice;
								single.Discount__c=line.DiscountPercentage;
								single.TotalPrice=line.TotalPlannedAmount;
								single.uniqueId=this.generateUniqueId();
								single.PricebookEntryId=line.PricebookEntryId;
								single.Product2Id=line.ProductId;
								single.T0030_Categoria_Prodotto__c='First Choice';
								single.T0213_Toll_Lunghezza_fissa_mm__c=100;
								single.C0950_UM_per_Tolleranza_Saldo_Posizione__c='K';
								single.C0951_UM_per_Tolleranza_Saldo_Posizione__c='%';
								single.Quality__c='571';
								single.T0065_Formato__c=line.Product?.ProductCode  == '90'?'NER - NERVATO':'';
								orderLines.push(single);
						})
						this.lines=orderLines;
						this.calculateFinalTotal();
        }
      }

      showToast(label, msg, type) {
        const event = new ShowToastEvent({
            title: label,
            message: msg,
            variant: type,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }

    dispatchLineRemovedEvent(){
      console.log('dispatchLineRemovedEvent:::');
      let eventName='lineremoved';
      let detail={lines:{}};
      let tempLines=JSON.parse(JSON.stringify(this.lines));
      tempLines.forEach(line => {
        console.log('dispatchLineRemovedEvent-line:: '+JSON.stringify(line))
         detail.lines[line.Product_Code__c]=line.Product_Code__c;
      })
      console.log('dispatchLineRemovedEvent:::' +JSON.stringify(detail));
      this.createAndDispatchEvent(eventName,detail);
    }

    dispatchLineAddedEvent(){
      console.log('dispatchLineAddedEvent');
      this.createAndDispatchEvent('lineadded',{});
    }

    createAndDispatchEvent(eventName,detail){
      let event=new CustomEvent(eventName,{detail:detail});
      this.dispatchEvent(event);
    }

    handleAddRecord(rec){
      console.log('OrderLinesView.handleAddRecord:: '+JSON.stringify(rec));
      let tempLines=JSON.parse(JSON.stringify(this.lines));
      tempLines.push(rec);
      this.lines=tempLines;
      this.calculateFinalTotal();
      this.checkPaymentTriplet();
      this.dispatchLineAddedEvent();
    }

    checkPaymentTriplet(){
      let filtered = this.lines.filter(p => this.managedProductWihLigtingBelts.includes(p.Product_Code__c));
      if(filtered.length > 0){
        this.handlePaymentTriplets('secondary')
      }else{
        this.handlePaymentTriplets('primary');
      }
    }

    async handleLigtingBelts(rec){
      try {
        console.log('orderLinesView.handleLigtingBelts::')
        let productCode=rec?.Product_Code__c;
        let ligtingBeltsNeeded=rec?.Ligting_Belts_Needed__c;
        let pricebookId=this.orderWrapper?.orderHeader?.Pricebook2Id;
        let businessCountry=this.orderWrapper?.orderHeader?.Business_Country__c;
        console.log('orderLinesView.handleLigtingBelts.ProductCode::'+productCode);
        console.log('orderLinesView.handleLigtingBelts.ligtingBeltsNeeded::'+ligtingBeltsNeeded);
        console.log('orderLinesView.handleLigtingBelts.pricebookId::'+pricebookId);
        let existingELs=JSON.parse(JSON.stringify(this.lines)).filter(el => el.Product_Code__c =='EL');
        console.log('orderLinesView.handleLigtingBelts.existingEL::'+JSON.stringify(existingELs));
        if(this.managedProductWihLigtingBelts.includes(productCode) && ligtingBeltsNeeded){
            if(existingELs.length > 0){
                let single=existingELs[0];
                single.Quantity=parseInt(single?.Quantity)+parseInt(rec?.['T0401_Nr_Colli__c'])*4;
                this.handleEditRecord(single);
            }else{
              let pricebookEntry= await getPricebookEntryByProductCodeAndPricebookId({productCode:'EL',pricebookId:pricebookId});
              console.log('orderLinesView.handleLigtingBelts.pricebookEntry::'+JSON.stringify(pricebookEntry))
              if(pricebookEntry){
                let single={};
                single.Product_Code__c=pricebookEntry?.ProductCode;
                single.Product_Name__c=pricebookEntry?.Name;
                single.Quantity=parseInt(rec?.['T0401_Nr_Colli__c'])*4;
                single.UnitPrice=pricebookEntry?.UnitPrice;
                single.Product2Id=pricebookEntry?.Product2Id;
                single.C0121_Prezzo__c=pricebookEntry?.UnitPrice;
                single.Business_Country__c=businessCountry;
                single.PricebookEntryId=pricebookEntry.Id;
                single.TotalPrice=parseInt(rec?.['T0401_Nr_Colli__c'])*4*parseFloat(pricebookEntry?.UnitPrice);
                single.uniqueId=this.generateUniqueId();
                single.Delivery_Period_Format__c=
                this.handleAddRecord(single);
              }
            }
        }
      } catch (error) {
          console.log('error occurred while handlingbelts::'+JSON.stringify(error));
      }
    }

    async handleLigtingBeltsOnList() {
      try {
        let currentLines = JSON.parse(JSON.stringify(this.lines));
        let linesWithLigtingBelts = currentLines.filter(el => this.managedProductWihLigtingBelts.includes(el?.Product_Code__c) && el?.Ligting_Belts_Needed__c);
        let existingELs = currentLines.filter(el => el.Product_Code__c == 'EL');
        console.log('orderLinesView.handleLigtingBeltsOnList-linesWithLigtingBelts:: '+JSON.stringify(linesWithLigtingBelts));
        if (linesWithLigtingBelts.length > 0) {
          let totalColli = linesWithLigtingBelts.reduce((acc, curr) => parseFloat(acc) + parseFloat(curr?.T0401_Nr_Colli__c || 0), 0);
          let pricebookId = this.orderWrapper?.orderHeader?.Pricebook2Id;
          let businessCountry = this.orderWrapper?.orderHeader?.Business_Country__c;
          let sortedList = linesWithLigtingBelts.sort((a, b) => {
            return new Date(a?.Delivery_Period__c) - new Date(b?.Delivery_Period__c);
          })
          let firstElement = linesWithLigtingBelts?.[0];
          let deliveryFormat = firstElement?.Delivery_Period_Format__c;
          let deliveryDate = firstElement?.Delivery_Period__c;
          let deliveryDateConverted = firstElement?.C0711_Consegna__c;
          console.log('sortedList:: '+JSON.stringify(sortedList));
          console.log('deliveryFormat:: '+deliveryFormat);
          console.log('deliveryDate:: '+deliveryDate);
          console.log('deliverDateConverted:: '+deliveryDateConverted);
          if (existingELs.length > 0) {
            let single = existingELs[0];
            single.Quantity = parseInt(totalColli)*4;
            single.C06256_Qnt_ordinata_unita_di_misura__c = parseInt(totalColli)*4;
            single.TotalPrice=single?.Quantity*single?.UnitPrice;
            this.handleEditRecord(single);
          } else {
            let pricebookEntry = await getPricebookEntryByProductCodeAndPricebookId({
              productCode: 'EL',
              pricebookId: pricebookId
            });
            console.log('orderLinesView.handleLigtingBelts.pricebookEntry::' + JSON.stringify(pricebookEntry))
            if (pricebookEntry) {
              let single = {};
              single.Product_Code__c = pricebookEntry?.ProductCode;
              single.Product_Name__c = pricebookEntry?.Name;
              single.Quantity = parseInt(totalColli)*4;
              single.C06256_Qnt_ordinata_unita_di_misura__c = parseInt(totalColli)*4;
              single.UnitPrice = pricebookEntry?.UnitPrice;
              single.Product2Id = pricebookEntry?.Product2Id;
              single.C0121_Prezzo__c = pricebookEntry?.UnitPrice;
              single.Business_Country__c = businessCountry;
              single.PricebookEntryId = pricebookEntry.Id;
              single.TotalPrice = parseInt(totalColli)*4* parseFloat(pricebookEntry?.UnitPrice);
              single.uniqueId = this.generateUniqueId();
              single.Delivery_Period_Format__c = deliveryFormat;
              single.Delivery_Period__c=deliveryDate;
              single.C0711_Consegna__c = deliveryDateConverted;
              single.Pricing_Type__c = 'Effettivo';
              this.handleAddRecord(single);
            }
          }
        }else{
          if(existingELs.length > 0){
            let single = existingELs[0];
            console.log('orderLinesView.handleLigtingBeltsOnList.single::'+JSON.stringify(single));
            this.handleDelete(null,single?.uniqueId);
          }
        }
      } catch (error) {
        console.log('orderLinesView.handleLigtingBeltsOnList--error:: ' + JSON.stringify(error))
      }
    }

    handleEditRecord(rec){
      console.log('OrderLinesView.handleEditRecord:: '+JSON.stringify(rec));
      let tempLines=JSON.parse(JSON.stringify(this.lines));
      for(let i=0; i<tempLines.length; i++){
        console.log('tempUnique: '+tempLines[i].uniqueId)
        console.log('recUnique: '+rec.uniqueId)
        if(tempLines[i].uniqueId == rec.uniqueId){
          console.log('found')
          tempLines[i]=rec;
          break;
        }
      }
      this.lines=tempLines;
      this.calculateFinalTotal();
    }

    @api
    async saveLines(recordId){
      this.isSaving=true;
      console.log('orderLinesView.saveLines::');
      let preparedList=JSON.parse(JSON.stringify(this.lines));
      preparedList.forEach(el => {
        el.OrderId=recordId;
        delete el.uniqueId;
      })
      console.log('removedPropertyies: '+JSON.stringify(preparedList));
      let saveResponse=await createOrderLines({orderLines:JSON.stringify(preparedList)});
      console.log('orderLinesView.saveLines-response:: '+saveResponse);
    }

    

    //refactored code

    orderWrapper;
    

    async waitForOverrides() {
      return new Promise((resolve) => {
          const checkOverrides = () => {
              let instance = orderConfiguratorSingleton.getInstanceData();
              if (instance && instance.orderOverrides) {
                  resolve(instance.orderOverrides);
              } else {
                  setTimeout(checkOverrides, 100);
              }
          };
          checkOverrides();
      });
  }

    async doInitLines(){
        console.log('orderLinesView.doInitLines:: '+this.agreement);
    
        let orderWrapper=null;
        try {
          if (this.isClone && this.sourceOrder) {
            console.log('orderLinesView.doInitLines:: CLONE');
            let response = await getOverrides({
              params: {
                orderId: this.sourceOrder,
                salesAgreementId: this.agreement
              }
            });
            if (response) {
              orderWrapper = response.wrapper;
            }
          } else {
            orderWrapper = await initOrder({
              recordId: this.agreement
            });
            console.log('orderLinesView.doInitLines:: NEW/EDIT');
          }

        } catch (e) {
          console.log('initOrder server error!');
        }
        console.log('orderLinesView.doInitLines--wrapp:: '+JSON.stringify(orderWrapper));
        if(orderWrapper){
          try{
            let linesUpdated=[]
            let hasMesh = false;
            orderWrapper.orderLines.forEach(el => {
              let single=JSON.parse(JSON.stringify(el))
              console.log('single:: '+JSON.stringify(single))
              single.uniqueId=this.generateUniqueId();
              single.TotalPrice=this.calculateLineTotal(el?.Quantity,el?.C0121_Prezzo__c,el?.C0122_Prezzo_Extra__c,el?.Discount__c)
              single.Delivery_Period_Format__c = el.Delivery_Period_Format__c ?? 'G';
              console.log('singleUP:: '+JSON.stringify(single))
              linesUpdated.push(single);
              if(single.Product_Code__c == '85'){
                hasMesh = true;
              }
            })
            console.log('linesUpdate:: '+JSON.stringify(linesUpdated))
            //orderWrapper.orderLines=linesUpdated;
            //this.orderWrapper=orderWrapper;
            this.pricebookId=orderWrapper?.orderHeader?.Pricebook2Id;
            this.lines=linesUpdated;
            this.orderWrapper=orderWrapper;
            console.log('orderLinesView.doInitLines--wrappLines:: '+JSON.stringify(this.lines));
            this.calculateFinalTotal();
            if(hasMesh && !this.orderWrapper.Id){
              this.handlePaymentTriplets('secondary');
            }
          }catch(e){
            console.log('orderWrapper error! ')
          }

        }
  
        /*let instance = orderConfiguratorSingleton.getInstanceData();


        console.log('clone.instance => '+JSON.stringify(instance));*/

        /*let orderOverrides = await this.waitForOverrides();

        console.log('pask.orderOverrides'+JSON.stringify(orderOverrides));

        if(orderOverrides){
          try{
            let linesUpdated=[]
            orderOverrides.orderItemsOverrides.forEach(el => {
              let single=JSON.parse(JSON.stringify(el))
              console.log('clone.single:: '+JSON.stringify(single))
              single.uniqueId=this.generateUniqueId();
              console.log('clone.singleUP:: '+JSON.stringify(single))
              linesUpdated.push(single);
            })
            console.log('clone.linesUpdate:: '+JSON.stringify(linesUpdated))
            //orderWrapper.orderLines=linesUpdated;
            //this.orderWrapper=orderWrapper;
            //this.pricebookId=orderWrapper?.orderHeader?.Pricebook2Id;
            this.lines=linesUpdated;
            console.log('clone.orderLinesView.doInitLines--wrappLines:: '+JSON.stringify(this.lines));
            this.calculateFinalTotal();
          }catch(e){
            console.log('errore override lines! => '+e.message);
          }

        }*/
    }

    calculateLineTotal(qty,price,extra,discount){
      let priceTotal = parseFloat(price) + parseFloat(extra);
      let discountAmount = priceTotal * parseFloat(discount)/100;
      let discountedAmount = priceTotal - discountAmount;

      return discountedAmount * parseFloat(qty);
    }

    handlePaymentTriplets(toUse) {
      console.log('orderLinesView.handlePaymentTriplets:: ');
      /*let triplets = this.orderWrapper?.paymentTriplets;
      let primaryTriplet = triplets?.primary;
      console.log('orderLinesView.handlePaymentTriplets-primary:: '+JSON.stringify(primaryTriplet));
      let secondaryTriplet = triplets?.secondary;
      console.log('orderLinesView.handlePaymentTriplets-secondary:: '+JSON.stringify(secondaryTriplet));

      let tripletToUse = {};

      if (secondaryTriplet.C0787_Codice_pagamento__c && toUse == 'secondary') {
        tripletToUse = secondaryTriplet;
        console.log('orderLinesView.handlePaymentTriplets-secondary::');
      } else {
        tripletToUse = primaryTriplet;
        console.log('orderLinesView.handlePaymentTriplets-primary::');
      }*/

      this.createAndDispatchEvent('tripletchange', {
        detail: {
          triplet: toUse
        }
      });
    }
    
}