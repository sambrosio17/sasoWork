import { LightningElement, api } from "lwc";
import LightningModal from 'lightning/modal';
export default class CreateLocationModal extends LightningModal {

    @api recordId;

    _inputVariables;

    @api
    get inputVariables() {
        return this._inputVariables;
    }

    set inputVariables(value){
        this._inputVariables=value;
    }

    connectedCallback(){
        console.log('CreateLocationModal::'+JSON.stringify(this.inputVariables));
    }

    handleStatusChange(event) {
        console.log('CreateLocationModal.handleStatusChange:: ');
        if (event.detail.status === "FINISHED") {
            const outputVariables = event.detail.outputVariables;
            console.log('variables:: '+JSON.stringify(outputVariables));
            if(outputVariables.length > 0){
                let locationId = outputVariables.filter(
                    variable => variable.name === 'createdLocationId'
                )[0].value;
                let associatedLocationId = outputVariables.filter(
                    variable => variable.name === 'associatedLocationId'
                )[0].value
                let event = new CustomEvent('locationcreated',{detail:{
                    location:locationId,
                    associatedLocation:associatedLocationId
                }});
                this.dispatchEvent(event);
                this.close();
                console.log('CreateLocationModal.handleStatusChange:: '+JSON.stringify( event.detail.outputVariables));
            }
            
            
        }
    }

}