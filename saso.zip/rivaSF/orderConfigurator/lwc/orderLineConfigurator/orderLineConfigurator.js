import {
    LightningElement,
    api,
    wire
} from "lwc";
import getPriceRuleOutput from "@salesforce/apex/OrderConfiguratorController.getPriceRuleOutput"
import getMeshTypes from "@salesforce/apex/OrderConfiguratorController.getMeshTypes"
import getAllConfiguratorFields from "@salesforce/apex/OrderConfiguratorController.getAllConfiguratorFields";
import getQualitiesByCountryAndProduct from "@salesforce/apex/OrderConfiguratorController.getQualitiesByCountryAndProduct";
import getDefaultValuesByFilters from "@salesforce/apex/OrderConfiguratorController.getDefaultValuesByFilters"
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
import C0696_0 from "@salesforce/label/c.C0696_0"
import C0696_6 from "@salesforce/label/c.C0696_6"
import C0696_7 from "@salesforce/label/c.C0696_7"
import OrderedQtyShouldBeMultiple from "@salesforce/label/c.OrderedQtyShouldBeMultiple"
import DeliveryPeriodPastDate from "@salesforce/label/c.DeliveryPeriodPastDate"
import QuantityExceeded from "@salesforce/label/c.QuantityExceeded"
import PriceDifferent from "@salesforce/label/c.PriceDifferent"
import ExtraPriceSuccessMessage from "@salesforce/label/c.ExtraPriceSuccessMessage"
import MeshTypeAppliedSuccessMessage from "@salesforce/label/c.MeshTypeAppliedSuccessMessage"
import ProductNotOffered from "@salesforce/label/c.ProductNotOffered";
import FixedLengthInMM from "@salesforce/label/c.FixedLengthInMM"
import getMeshPriceRuleOutput from "@salesforce/apex/OrderConfiguratorController.getMeshPriceRuleOutput";
import BasePriceError from "@salesforce/label/c.BasePriceError"
import ContentType from "@salesforce/schema/Attachment.ContentType";
export default class OrderLineConfigurator extends LightningElement {

    _selectedproduct;

    @api isTrader;
    @api
    get selectedproduct() {
        return this._selectedProduct;
    }
    set selectedproduct(value) {
        this._selectedProduct = value;
    }

    priceRuleTrackedField = ['T0002_Misura_1__c', 'T0171_Lunghezza_fissa_in_mm__c', 'T0400_Peso_Bobin_Tonn__c', 'Quality__c', 'Misura_2__c','Pricing_Type__c'];
    meshDependentField = ['MeshCode__c','UnitsPerPackage__c','WeightInKGOfUnit__c','Quality__c'];

    manageableOrderLineStatus={
        '0':C0696_0,
        "6":C0696_6,
        "7":C0696_7
    }
    
    fieldDependenciesMap = {
        "C0952_Toll_Saldo_Posizione__c": {
            label: 'Toll. Saldo Posizione (-)',
            fields: [{
                apiname: 'C0950_UM_per_Tolleranza_Saldo_Posizione__c',
                label: 'U.M per Tolleranza (-) Saldo Posizione'
            }]
        },
        "C0953_Toll_Saldo_Posizione__c": {
            label: 'Toll. Saldo Posizione (+)',
            fields: [{
                apiname: 'C0951_UM_per_Tolleranza_Saldo_Posizione__c',
                label: 'U.M per Tolleranza (+) Saldo Posizione'
            }]
        }
    }

    @api
    editproduct;

    @api
    firstSection=[]
    @api
    secondSection=[]
    @api
    thirdSection=[]
    @api
    fourthSection=[]
    @api
    fifthSection=[]
    @api
    firstSectionTitle;
    @api
    secondSectionTitle;
    @api
    thirdSectionTitle;
    @api
    fourthTitle;
    @api
    fifthSectionTitle;
    //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
    @api
    orderUnitOfMeasure; //this is quantity UM
    @api
    priceUnitOfMeasure; //this is price UM
    //29-10-2024 - saambrosio@deloitte.it - END:: Managing different unit of measure for BEL and DEU
    configuratorFields;
    @api
    orderWrapper;
    _productRecord;

    @api
    get productRecord() {
        return this._productRecord;
    }

    set productRecord(value) {
        this._productRecord = value;
    }

    @api
    locationid
    @api
    deliveryid
    @api
    businesscountry;

    _productCode;
    _country;

    @api get productCode(){
        console.log('get prodcode');
        return this._productCode;
    }

    set productCode(value){
        console.log('set prodcode');
        this._productCode=value;
    }

    @api get country(){
        console.log('get country');
        return this._country;
    }

    set country(value){
        console.log('set country');
        this._country=value;
    }

    _specialFieldValue;

    @api get specialFieldValue(){
        return this._specialFieldValue;
    }

    set specialFieldValue(value){
        this._specialFieldValue=value;
    }

    @api showAdditionalSection;

    async connectedCallback() {
        this.selectedproduct = this.selectedproduct[0];
        console.log('orderLineConfigurator-selected::' + JSON.stringify(this.selectedproduct))
        console.log('orderLineConfigurator-edit::' + JSON.stringify(this.editproduct))
        console.log('orderLineConfigurator--wrapperCC:: '+JSON.stringify(this.orderWrapper))
        console.log('orderLIneConfigurator-isTrader:: '+this.isTrader);
        console.log('orderLIneConfigurator-OrderUnitOfMeasure:: '+this.orderUnitOfMeasure);
        console.log('orderLIneConfigurator-PriceUnitOfMeasure:: '+this.priceUnitOfMeasure);
    }

    async renderedCallback() {
        console.log('orderLineConfigurator-rendered::')
        console.log('orderLineConfigurator-loc::' + this.locationid)
        console.log('orderLineConfigurator-delivery::' + this.deliveryid)
        console.log('orderLineConfigurator-bc::' + this.businesscountry);
        console.log('orderLineConfigurator--rend::' + JSON.stringify(this.editproduct))
        console.log('orderLineConfigurator--unitofmeasure::' + this.orderUnitOfMeasure);
        console.log('orderLineConfigurator--wrapper:: '+JSON.stringify(this.orderWrapper))
        console.log('orderLIneConfigurator-OrderUnitOfMeasure:: '+this.orderUnitOfMeasure);
        console.log('orderLIneConfigurator-PriceUnitOfMeasure:: '+this.priceUnitOfMeasure);
        this.country=this.businesscountry;
        if (this.selectedproduct) {
            //newprod
            this.initProductForm();
        } else {
            console.log('init edit product');
            this.initEditProduct();
        }
        if(!this.options && this.businesscountry && this.productCode){
            await this.getAvailableQualities();
        }
        console.log('orderLineConfigurator.rendered-prod:: ' + JSON.stringify(this.productRecord))
        console.log('orderLineConfigurator.rendered-confMap:: ' + JSON.stringify(this.configuratorFields))
        console.log('orderLineConfigurator.rendered-options:: ' + JSON.stringify(this.options));

    }

    firstSectionName='xCODE_productinformation';
    secondSectionName='xCODE_priceinformation';
    thirdSectionName='xCODE_additionalinformation';
    fourthSectionName='xCODE_tolleranceinformation';
    fifthSectionName='xCODE_technicalinformation'

    managedProducts=['10','20','40','60','70','80','81','85','87','90','91','92','93','94','95','EL','W7'];
    managedProductWihColli=['85'];

    @wire(getAllConfiguratorFields, {
        objectName: 'OrderItem'
    })
    getFormFields(data, error) {
        if (data) {
            console.log('orderLineConfigurator.getFormFields::' + JSON.stringify(data));
            let currentProd=this.selectedproduct?.[0]==null ? this.selectedproduct : this.selectedproduct[0];
            currentProd=currentProd == null ? this.editproduct : currentProd;
            let selectedProductCode = currentProd?.ProductCode == null ? currentProd?.Product_Code__c : currentProd?.ProductCode ;
            console.log('orderLineConfigurator-selectedProd::' + JSON.stringify(currentProd))
            if(this.managedProducts.includes(selectedProductCode)){
                console.log('orderLineConfigurator-firstSectionName::'+this.firstSectionName)
                this.firstSection = data?.data?.[this.firstSectionName.replace('CODE',selectedProductCode).toLowerCase()];
                this.secondSection = data?.data?.[this.secondSectionName.replace('CODE',selectedProductCode).toLowerCase()];
                this.thirdSection = data?.data?.[this.thirdSectionName.replace('CODE',selectedProductCode).toLowerCase()];
                this.fourthSection = data?.data?.[this.fourthSectionName.replace('CODE',selectedProductCode).toLowerCase()];
                this.fifthSection = data?.data?.[this.fifthSectionName.replace('CODE',selectedProductCode).toLowerCase()];
                this.firstSectionTitle = 'Product Information';
                this.secondSectionTitle = 'Pricing Information';
                this.thirdSectionTitle = 'Additional Information';
                this.fourthSectionTitle = 'Tollerance Information';
                if(this.fifthSection){
                    this.fifthSectionTitle = 'Technical Information';
                    this.showAdditionalSection = true;
                }
            }else{
                this.firstSection = data?.data?.x90_productinformation;
                this.secondSection = data?.data?.x90_priceinformation;
                this.thirdSection = data?.data?.x90_additionalinformation;
                this.fourthSection = data?.data?.x90_tolleranceinformation;
                this.firstSectionTitle = 'Product Information';
                this.secondSectionTitle = 'Pricing Information';
                this.thirdSectionTitle = 'Additional Information';
                this.fourthSectionTitle = 'Tollerance Information';
            }
        } else {
            console.log('orderLineConfigurator.getFormFields-ERROR::' + JSON.stringify(error));
        }
    }

    async initProductForm() {

        console.log('orderLineConfigurator.initProductForm::');
        let allFields = this.template.querySelectorAll('lightning-input-field');
        let record = {}
        let fieldMap = {};
        let searchInput={
            targetObject:'OrderItem',
            productCode:this.selectedproduct?.ProductCode
        }
        let defaultMap=await getDefaultValuesByFilters({input:JSON.stringify(searchInput)});
        allFields.forEach(el => {
            let fieldApi = el?.dataset?.apiname;
            console.log('orderLineConfigurator.initProductForm-field::' + fieldApi);
            switch (fieldApi) {
                case 'Product_Code__c':
                    el.value = this.selectedproduct?.ProductCode;
                    record[fieldApi] = this.selectedproduct?.ProductCode;
                    this.productCode = this.selectedproduct?.ProductCode;
                    break;
                case 'Product_Name__c':
                    el.value = this.selectedproduct?.Product_Name__c;
                    record[fieldApi] = this.selectedproduct?.Product_Name__c;
                    break;
                case 'C0121_Prezzo__c':
                    if(this.isTrader){
                        el.value = this.selectedproduct?.UnitPrice;
                        record[fieldApi] = this.selectedproduct?.UnitPrice;
                    }
                    break;
                case 'Discount__c':
                    el.value = this.selectedproduct?.Discount__c;
                    record[fieldApi] = this.selectedproduct?.Discount__c;
                    break;
                case 'Pricing_Type__c':
                    el.value = this.selectedproduct?.Pricing_Type__c;
                    record[fieldApi] = this.selectedproduct?.Pricing_Type__c;
                    break;
                // case 'T0065_Formato__c':el.value=this.selectedproduct?.ProductCode == '90'?'NER - NERVATO':''; record[fieldApi]=this.selectedproduct?.ProductCode == '90'?'NER - NERVATO':'';break;
                /*case 'T0065_Formato__c':
                    el.value = el.value=this.selectedproduct?.ProductCode == '90'?'NER - NERVATO':''; record[fieldApi]=this.selectedproduct?.ProductCode == '90'?'NER - NERVATO':'';break;
                */
                case 'T0213_Toll_Lunghezza_fissa_mm__c':
                    el.value = 100;
                    record[fieldApi]=100;
                    break;
                case 'C0950_UM_per_Tolleranza_Saldo_Posizione__c':
                    el.value = "K";
                    record[fieldApi]='K';
                    break;
                case 'C0951_UM_per_Tolleranza_Saldo_Posizione__c':
                    el.value = "%";
                    record[fieldApi]='%'
                    break;
                case 'Quality__c':
                    el.value = '571';
                    record[fieldApi]='571'
                    break;
                case 'Business_Country__c':
                    el.value=this.businesscountry;
                    record[fieldApi]=this.businesscountry;
                    break;
                case 'Delivery_Period_Format__c':
                    el.value = 'G';
                    record[fieldApi] = 'G';
                    break;
                default: let value=defaultMap?.[fieldApi];
                         el.value=value;
                         record[fieldApi]=value;
            }
            fieldMap[fieldApi] = el;
        })
        this.configuratorFields = fieldMap;
        record.Product2Id = this.selectedproduct.Product2Id;
        record.PricebookEntryId = this.selectedproduct.Id;
        record.uniqueId = this.generateUniqueId();
        this.productRecord = record;
    }

    initEditProduct() {
        this.productRecord = this.editproduct;
        this.productCode = this.editproduct?.Product_Code__c;
        let allFields = this.template.querySelectorAll('lightning-input-field');
        let fieldMap = {};
        allFields.forEach(el => {
            let fieldApi = el?.dataset?.apiname;
            el.value = this.productRecord[fieldApi];
            fieldMap[fieldApi] = el;
        })
        this.setValueOnSpecialField(this.productRecord?.['Quality__c']);
        this.configuratorFields = fieldMap;
        this.doCalculateLineTotal();
    }

    generateUniqueId() {
        return Date.now().toString(36) + Math.floor(Math.pow(10, 12) + Math.random() * 9 * Math.pow(10, 12)).toString(36)
    }

    async handleFieldChange(event) {
        console.log('field change-line' + JSON.stringify(event.target.value));
        console.log('field change-linedetail' + JSON.stringify(event.detail.value));
        console.log('field change-line' + JSON.stringify(event.target.dataset));
        console.log('field change-line' + JSON.stringify(this.productRecord));

        let temp = JSON.parse(JSON.stringify(this.productRecord));
        let apiname = event.target.dataset.apiname;
        let value=event.target.value
        let label=event.target.dataset.label;

        if(apiname == 'C0696_STATO_DI_AVANZAMENTO__c' && !this.manageableOrderLineStatus[value]){
            let availableValues=Object.values(this.manageableOrderLineStatus).join(', ');
            this.showToast('Error!','Only following values are selectable for '+label+': '+availableValues,'error');
            this.setValueOnRecord(apiname,this.productRecord[apiname]);
            console.log('changed stato di avanzamento');
            return;
        }
        temp[apiname] = event.target.value;
        /* 03-07: update gestione unità di misura
        if (event.target.dataset.apiname == 'Quantity') {
            console.log('set quantity::');
            temp['C06256_Qnt_ordinata_unita_di_misura__c'] = event.target.value;
            if(this.managedProductWihColli.includes(temp?.Product_Code__c)){
                this.calculateAndSetColli(event.target.value,temp?.['UnitsPerPackage__c'],temp?.['WeightInKGOfUnit__c']);
            }
                

        }*/
        //03-07:update gestione unità di misura - START
        if(apiname == 'C06256_Qnt_ordinata_unita_di_misura__c'){
            console.log('converting');
            let convertedQuantity=this.doConvertToUnitOfMeasure(this.orderUnitOfMeasure,parseFloat(value));
            console.log('converted:: '+convertedQuantity);
            temp['Quantity']=convertedQuantity;
            this.setValueOnRecordWithoutFocus('Quantity',convertedQuantity);
        }
        //03-07:update gestione unità di misura - END
        if(apiname == 'C0121_Prezzo__c'){
            this.setValueOnRecordWithoutFocus(apiname,event.target.value || 0);
        }
        this.productRecord = temp;
        /*temp.UnitPrice = (parseFloat(temp['C0121_Prezzo__c']) + parseFloat(temp['C0122_Prezzo_Extra__c']? temp['C0122_Prezzo_Extra__c'] : 0));
        temp.TotalPrice = (parseFloat(temp['C0121_Prezzo__c']) + parseFloat(temp['C0122_Prezzo_Extra__c']? temp['C0122_Prezzo_Extra__c'] : 0)) * parseFloat(temp['Quantity']);
        
        this.setValueOnRecord('TotalPrice',temp.TotalPrice);*/
        //17-07: GESTIONE CONSEGNA - START
        if(apiname == 'Delivery_Period__c'){
            console.log('handling delivery period change::');
            
            let masterField = this.productRecord?.Delivery_Period_Format__c || 'G';
            let slaveField = this.configuratorFields?.['C0711_Consegna__c'];
            console.log('deliveryPeriodFormat:: '+masterField);
            console.log('deliveryPeriod:: '+value);
            let formattedDate = this.calculateFormatedDate(masterField,value);
            if(slaveField){
                this.setValueOnRecordWithoutFocus('C0711_Consegna__c',formattedDate);
            }
            await this.doValidate(apiname);

        }
        if(apiname == 'Delivery_Period_Format__c'){
            let masterField = this.productRecord?.['Delivery_Period__c'];
            let slaveField = this.configuratorFields?.['C0711_Consegna__c'];
            let formattedDate = '';
            if(masterField)
                formattedDate = this.calculateFormatedDate(value,masterField);
            if(slaveField && masterField){
                this.setValueOnRecordWithoutFocus('C0711_Consegna__c',formattedDate);
            }
        }
        if(apiname=='Mesh_Type__c'){
            console.log('changed Mesh_Type__c');
            await this.handleMeshType();
            if(this.productRecord?.Quality__c){
                await this.handleMeshPriceRule();
            }
        }
        if (this.priceRuleTrackedField.includes(apiname)) {
            console.log('trackedfield is changed:: ' + apiname);
            await this.handlePriceRule();
        }
        //09-09-2024 - saambrosio@deloitte.it - START:: added support for measure 1 description
        if(apiname === 'T0002_Misura_1__c'){
            this.setValueOnRecord('Measure_1_Description__c',value);
        }
        //09-09-2024 - saambrosio@deloitte.it - END:: added support for measure 1 description
        if(apiname=='UnitsPerPackage__c'){
            if(this.managedProductWihColli.includes(temp?.Product_Code__c))
                this.calculateAndSetColli(temp?.['C06256_Qnt_ordinata_unita_di_misura__c'],event.target.value,temp?.[WeightInKGOfUnit__c]);
        }
        if(this.managedProductWihColli.includes(temp?.Product_Code__c))
            this.calculateAndSetColli(temp?.['C06256_Qnt_ordinata_unita_di_misura__c'],temp?.['UnitsPerPackage__c'],temp?.['WeightInKGOfUnit__c']);
        await this.doCalculateLineTotal();
    }

    calculateFormatedDate(format,date){
        let formattedDate='';
        console.log('calculateFormattedDate:: ')
        console.log('calculateFormattedDateff:: '+format)
        console.log('calculateFormattedDate-d:: '+date)
        switch (format) {
            case 'S':
                let orderDate = new Date(date);
                formattedDate="00"+orderDate.getFullYear();
                let weeknumber='';
                const januaryFirst = new Date(orderDate.getFullYear(), 0, 1);
                const daysToNextMonday = (januaryFirst.getDay() === 1) ? 0 : (7 - januaryFirst.getDay()) % 7;
                const nextMonday = new Date(orderDate.getFullYear(), 0, januaryFirst.getDate() + daysToNextMonday);
                weeknumber = (orderDate < nextMonday) ? 52 : 
                (orderDate > nextMonday ? Math.ceil(
                (orderDate - nextMonday) / (24 * 3600 * 1000) / 7) : 1);
                formattedDate+=weeknumber;
                break;
            case 'M':
                let splitted=date.split("-");
                if(splitted.length > 0){
                    formattedDate="00"+splitted?.[0]+splitted?.[1];
                }
                break;
            default:
                formattedDate=date.replaceAll("-","");
                break;
        }
        console.log('calculateFormattedDate-res:: '+formattedDate);
        return formattedDate;
    }


    //conversione Quantity e UnitPrice
    doConvertToUnitOfMeasure(unitOfMeasure,value){
        console.log('orderLineConfigurator.doConvertToUnitOfMeasure:: ')
        console.log('orderLineConfigurator.doConvertToUnitOfMeasure-UOM:: '+unitOfMeasure)
        console.log('orderLineConfigurator.doConvertToUnitOfMeasure-value:: '+value)
        if(unitOfMeasure=='TN'){
            return value;
        }
        if(unitOfMeasure=='KG'){
            return value/1000;
        }if(unitOfMeasure=='NR' && this.productRecord?.['WeightInKGOfUnit__c']){
            return value*parseFloat(this.productRecord?.['WeightInKGOfUnit__c'] || 0)/1000;
        }
        return Math.ceil(value*100)/100;
    }

    //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
    doConvertToUnitPrice(unitOfMeasure,value,priceUnitOfMeasure){
        console.log('orderLineConfigurator.doConvertToUnitPrice:: ')
        console.log('orderLineConfigurator.doConvertToUnitPrice-QTYUOM:: '+unitOfMeasure)
        console.log('orderLineConfigurator.doConvertToUnitPrice-priceUOM:: '+priceUnitOfMeasure)
        console.log('orderLineConfigurator.doConvertToUnitPrice-value:: '+value)
        if(unitOfMeasure=='TN' && priceUnitOfMeasure == unitOfMeasure){
            return value;
        }
        if(unitOfMeasure=='KG'&& priceUnitOfMeasure == unitOfMeasure){
            return value*1000;
        }
        if(unitOfMeasure=='NR' && this.productRecord?.['WeightInKGOfUnit__c'] && priceUnitOfMeasure == unitOfMeasure){
            return value/parseFloat(this.productRecord?.['WeightInKGOfUnit__c'] || 0)*1000;
        }
        return value;
    }
    //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU


    doCalculateLineTotal(){
        console.log('orderLineConfigurator.doCalculateLineTotal:::')
        //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
        let qtyField=this.priceUnitOfMeasure == this.orderUnitOfMeasure ? 'C06256_Qnt_ordinata_unita_di_misura__c' : 'Quantity';
        //29-10-2024 - saambrosio@deloitte.it - END:: Managing different unit of measure for BEL and DEU
        let price=parseFloat(this.productRecord?.['C0121_Prezzo__c']);
        let extraPrice=Math.ceil(parseFloat(this.productRecord?.['C0122_Prezzo_Extra__c']) * 100)/100 || 0;
        let quantity=parseFloat(this.productRecord?.[qtyField]) || 0;
        let discount=parseFloat(this.productRecord?.['Discount__c']) || 0;
        console.log('orderLineConfigurator.doCalculateLineTotal.price:: '+price);
        console.log('orderLineConfigurator.doCalculateLineTotal.extraPrice:: '+extraPrice);
        console.log('orderLineConfigurator.doCalculateLineTotal.quantity:: '+quantity);
        console.log('orderLineConfigurator.doCalculateLineTotal.discount:: '+discount);

        let fullExtraPrice=price+extraPrice;
        let discounted=fullExtraPrice*discount/100;

        let unitPrice=fullExtraPrice-discounted;
        let totalPrice=unitPrice*quantity;

        console.log('orderLineConfigurator.doCalculateLineTotal.unitPrice:: '+unitPrice);
        console.log('orderLineConfigurator.doCalculateLineTotal.totalPrice:: '+totalPrice);

        //29-10-2024 - saambrosio@deloitte.it - START:: Managing different unit of measure for BEL and DEU
        let convertedUnitPrice=this.doConvertToUnitPrice(this.orderUnitOfMeasure,unitPrice,this.priceUnitOfMeasure);
        //29-10-2024 - saambrosio@deloitte.it - END:: Managing different unit of measure for BEL and DEU
        console.log('orderLineConfigurator.doCalculateLineTotal.convertedUnitPrice:: '+convertedUnitPrice);
        this.setValueOnRecordWithoutFocus('Final_Price__c',unitPrice);
        this.setValueOnRecordWithoutFocus('UnitPrice',convertedUnitPrice);
        this.setValueOnRecordWithoutFocus('TotalPrice',totalPrice);
    }


    async handleSpecialFieldChange(event){
        console.log('orderLineConfigurator.handleSpecialFieldChange:: ')
        console.log('orderLineConfigurator.handleSpecialFieldChange:: '+JSON.stringify(event.detail));
        let field=event?.detail?.fieldApiName;
        let value=event?.detail?.value;
        this.setValueOnRecord(field,value);
        if(field == 'Quality__c'){
            console.log('handleSpecialFieldChange:: '+field)
            await this.handlePriceRule();
            if(this.productRecord['Mesh_Type__c']){
                await this.handleMeshPriceRule();
            }
            //saambrosio@deloitte.it - 25/09/2024 -- START:: added support for alternative price for quality 998 for meshes
            if(value.includes('ALT') && this.productRecord.Product_Code__c == '85'){
                await this.setValueOnRecord(field,value.slice(0,3));
            }
            //saambrosio@deloitte.it - 25/09/2024 -- END:: added support for alternative price for quality 998 for meshes
        }
    }

    calculateAndSetColli(quantity,unitsperpackage,weight){
        let ncolli=0;
        let convertedQuantity=0;
        if(this.orderUnitOfMeasure=='NR'){
            convertedQuantity=parseFloat(quantity)
        }
        if(this.orderUnitOfMeasure=='KG'){
            convertedQuantity=Math.floor(parseFloat(quantity)/parseFloat(weight));
        }
        if(this.orderUnitOfMeasure=='TN'){
            convertedQuantity=Math.floor(parseFloat(quantity)*1000/parseFloat(weight));
        }

        ncolli=convertedQuantity/parseFloat(unitsperpackage);
        
        this.setValueOnRecordWithoutFocus('T0401_Nr_Colli__c',Math.ceil(ncolli));
    }

    async handlePriceRule() {
        console.log('orderLineConfigurator.handlePriceRule:: '+JSON.stringify(this.productRecord));
        //08-10-2024 - saambrosio@deloitte.it - START:: handling price rule for triangulation
        let shipmentSite = /*this.businesscountry == 'FRA' ? null :*/ this.locationid;
        //08-10-2024 - saambrosio@deloitte.it - END:: handling price rule for triangulation
        let deliveryCountry = this.businesscountry == 'SPA' ? this.deliveryid : null;
        let coilWeight = this.productRecord.Product_Code__c == '92' ? this.productRecord?.T0400_Peso_Bobin_Tonn__c : null;
        let measure2 = this.businesscountry == 'SPA' ? this.productRecord?.Misura_2__c : null
        let input = {
            productCode: this.productRecord.Product_Code__c,
            pricingType: this.productRecord.Pricing_Type__c,
            businessCountry: this.businesscountry,
            shipmentSite: shipmentSite,
            deliveryCountry: deliveryCountry,
            coilWeight: parseFloat(coilWeight),
            fixedLength: parseFloat(this.productRecord.T0171_Lunghezza_fissa_in_mm__c),
            measure1: this.productRecord.T0002_Misura_1__c,
            quality: this.productRecord.Quality__c,
            measure2: measure2
        }
        try {
            console.log('input: '+JSON.stringify(input));
            let priceRuleOutput = await getPriceRuleOutput({
                searchInput: JSON.stringify(input)
            });
            if (priceRuleOutput?.targetField) {
                console.log('orderLineConfigurator.handlePriceRule:: ' + JSON.stringify(priceRuleOutput));
                if(!Object.keys(priceRuleOutput).length){
                    return;
                }
                let targetField=priceRuleOutput.targetField != null ? priceRuleOutput.targetField : 'C0122_Prezzo_Extra__c' ;
                let value=parseFloat(priceRuleOutput?.value != null ? priceRuleOutput?.value : 0)  ;
                value=this.orderUnitOfMeasure == 'KG' ? value/1000 : value;
                this.setValueOnRecord(targetField,value);
                this.showToast('Success!',ExtraPriceSuccessMessage,'success');
            }else{
                this.blankOutFields(['C0122_Prezzo_Extra__c']);
            }
        } catch (error) {
            console.log('error occurred:: ' + JSON.stringify(error))
        }

    }

    async handleMeshPriceRule(){
        console.log('orderLineConfigurator.handleMeshPriceRule:: ');

        let payload = {
            measure1: this.productRecord?.MeshCode__c,
            businessCountry: this.businesscountry,
            productCode: this.productRecord.Product_Code__c,
            quality: this.productRecord.Quality__c
        };
        console.log('orderLineConfigurator.handleMeshPriceRule-payload:: '+JSON.stringify(payload));

        try {

            let response = await getMeshPriceRuleOutput({searchInput: JSON.stringify(payload)});

            console.log('orderLineConfigurator.handleMeshPriceRule-response:: '+JSON.stringify(response));

            if(response && response?.targetField){
                let targetField = response.targetField;
                let value = parseFloat(response.value);
                this.setValueOnRecordWithoutFocus(targetField,value);
            }else{
                this.blankOutFields(['C0121_Prezzo__c']);
            }
            await this.doCalculateLineTotal();
        } catch (error) {
            console.error('An error occured on handleMeshPriceRule:: '+JSON.stringify(error));
        }

    }

    async handleMeshType(){
        try {
            console.log('orderLineConfigurator.handleMeshType:: ');
            let bc=this.businesscountry;
            let typeName=this.productRecord?.['Mesh_Type__c'];
            let locId=bc === 'DEU' ? this.locationid : null;
            //String businessCountry, String locationCode, String meshCode
            let fieldToBlank = JSON.parse(JSON.stringify(this.meshDependentField));
            fieldToBlank.push('C0121_Prezzo__c');
            this.blankOutFields(fieldToBlank);
            let result=await getMeshTypes({
                businessCountry:bc,
                meshCode:typeName,
                locationCode:locId
            });
            if(result && !result.error.isError){
                let meshType=result.meshtypes?.[0];
                if(meshType){
                    for(let prop in meshType ){
                        if(prop == 'Id')
                            continue;
                        if(prop == 'Quality__c'){
                            console.log('orderLineConfigurator.handleMeshType:: '+prop+' is a list of values::'+JSON.stringify(meshType[prop]));
                            let values=meshType[prop];
                            if(values.includes(';')){
                                //09-09-2024 - saambrosio@deloitte.it - START:: added support quality description
                                continue;
                                //09-09-2024 - saambrosio@deloitte.it - END:: added support for measure 1 description
                                let options=[]
                                values.split(";").forEach(el => options.push({label:el,value:el}));
                                this.template.querySelector('c-configurator-special-field').options=options;
                                this.template.querySelector('c-configurator-special-field').value=' ';
                                //this.options = options;
                            }else{
                                console.log('setting value');
                                this.template.querySelector('c-configurator-special-field').value=values;
                                //this.specialFieldValue = values;
                            }
                            
                        }
                        if(prop == 'MeshCode__c'){
                            this.setValueOnRecord('T0002_Misura_1__c',meshType[prop]);
                        }
                        //09-09-2024 - saambrosio@deloitte.it - START:: added support for measure 1 description
                        if(prop == 'MeshType__c'){
                            this.setValueOnRecord('Measure_1_Description__c',meshType[prop]);
                        }
                        //09-09-2024 - saambrosio@deloitte.it - END:: added support for measure 1 description
                        /*if(prop == 'C0121_Prezzo__c' && !meshType[prop]){
                            continue;
                        }*/
                        /*if(prop == 'C0121_Prezzo__c'){
                            this.setValueOnRecordWithoutFocus(prop,'');
                        }*/
                       
                        this.setValueOnRecord(prop,meshType[prop]);
                    }
                    this.showToast('Success!',MeshTypeAppliedSuccessMessage.replace('{0}',typeName),'success');
                    this.calculateAndSetColli(this.productRecord?.['Quantity'],this.productRecord?.['UnitsPerPackage__c'],this.productRecord?.['WeightInKGOfUnit__c']);
                }
            }
            console.log('orderLineConfigurator.handleMeshType--result:: '+JSON.stringify(result));
        } catch (error) {
            console.log('error occurred while handling mesh type:: '+JSON.stringify(error));
        }
    }

    blankOutFields(listOfFields){
        try {
            listOfFields.forEach(f => {
                let confField=this.configuratorFields?.[f];
                if(confField)
                    confField.value=null
                if(f=='Quality__c'){
                    this.specialFieldValue==null;
                }
            })
        } catch (error) {
            console.log('error while blanking out');
        }
    }

    setValueOnRecord(field,value){
        console.log('setValueOnRecord::')
        console.log('setValueOnRecord-field::'+field)
        console.log('setValueOnRecord-value::'+value);
        let temp=JSON.parse(JSON.stringify(this.productRecord));
        console.log('setValueOnRecord-prod::'+JSON.stringify(this.productRecord));
        temp[field]=value;
        this.productRecord=temp;
        if(value && this.configuratorFields[field]){
            this.configuratorFields[field].value=value;
            console.log('setValueOnRecord-value::'+JSON.stringify(this.configuratorFields[field].value));
            //this.configuratorFields[field].focus();
        }  
    }

    setValueOnRecordWithoutFocus(field,value){
        console.log('setValueOnRecordWithoutFocus::')
        console.log('setValueOnRecordWithoutFocus-field::'+field)
        console.log('setValueOnRecordWithoutFocus-value::'+value);
        let temp=JSON.parse(JSON.stringify(this.productRecord));
        console.log('setValueOnRecordWithoutFocus-prod::'+JSON.stringify(this.productRecord));
        temp[field]=value;
        this.productRecord=temp;
        if(value && this.configuratorFields[field]){
            console.log('setValueOnRecordWithoutFocus-prodAfter::'+JSON.stringify(this.productRecord));
            this.configuratorFields[field].value=value;
            console.log('setValueOnRecordWithoutFocus-value::'+JSON.stringify(this.configuratorFields[field].value));
        }
        if(!value && this.configuratorFields[field]){
            this.configuratorFields[field].value=" ";
        }
    }

    @api options

    async getAvailableQualities(){
        console.log('orderLineConfigurator.getAvailableQualities-bc::'+this.country);
        console.log('orderLineConfigurator.getAvailableQualities-pc::'+this.productCode);
        try {
            const data= await getQualitiesByCountryAndProduct({businessCountry:this.country,productCode:this.productCode});
            if(data){
                console.log('orderLineConfigurator.getAvailableQualities::'+JSON.stringify(data));
                this.template.querySelector('c-configurator-special-field').options=data;
            }
        } catch (error) {
            console.log('error occurred while getting qualities::'+JSON.stringify(error))
        }

    }

    @api
    get checkRequiredFields() {
        console.log('checking required fields');
        let requiredField = [];
        let mergedArrays = [].concat.apply([], [this.firstSection, this.secondSection, this.thirdSection, this.fourthSection, this.fifthSection]);
        console.log('mergedArrays:: ' + JSON.stringify(mergedArrays));
        mergedArrays.forEach(el => {
            if (el!=null && el.required) {
                let checking = this.productRecord?.[el.fieldApiName]
                console.log('checking:: ' + checking);
                if (checking == null || checking == '') {
                    console.log('emptyyy');
                    requiredField.push(el.fieldLabel);
                }
            }
        })
        console.log('required:: ' + JSON.stringify(requiredField));
        return requiredField;

    }

    @api
    get checkFieldDependencies(){
        let missingFields=[];
        for(let prop in this.fieldDependenciesMap){
            if(this.productRecord[prop]!=null){
                let fieldsTocheck=this.fieldDependenciesMap[prop].fields;
                fieldsTocheck.forEach(el => {
                    if(!this.productRecord[el.apiname]){
                        missingFields.push({
                            masterFieldApiName: prop,
                            masterFieldLabel:this.fieldDependenciesMap[prop].label,
                            dependentFieldApiName: el.apiname,
                            dependentFieldLabel: el.label
                        });
                    }
                })
            }
        }

        return missingFields;
    }

    setValueOnSpecialField(value){
        let specialField=this.template.querySelector('c-configurator-special-field');
        if(specialField){
            specialField.value=value;
        }
    }

    showToast(label, msg, type) {
        const event = new ShowToastEvent({
            title: label,
            message: msg,
            variant: type,
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }
    //24-07
    
    
    //04-09-24 - saambrosio@deloitte.it - START:: added context to warnings + skipped PriceDifferent rule for PRODUCT: 85
    warnings = [
        {
            msg: QuantityExceeded,
            validate: function(prod, limitations, trader,context){
                let productCode = prod.Product_Code__c;
                console.log('warning--prodCOde::'+JSON.stringify(productCode));
                let productLimitations =  limitations;
                console.log('warning----PL::'+JSON.stringify(productLimitations));
                let compareProduct = productLimitations?.[productCode];
                console.log('warning--compare::'+JSON.stringify(compareProduct));
                return prod.Quantity + compareProduct?.Orderd__c > compareProduct?.TotalPlannedQuantity;
            },
            //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
            mandatory: false,
            active: true
            //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message
        },
        {
            msg: PriceDifferent,
            validate: function(prod, limitations, trader,context){
                let productCode = prod.Product_Code__c;
                console.log('warning--prodCOde::'+JSON.stringify(productCode));
                let productLimitations =  limitations;
                console.log('warning----PL::'+JSON.stringify(productLimitations));
                let compareProduct = productLimitations?.[productCode];
                console.log('warning--compare::'+JSON.stringify(compareProduct));
                return compareProduct ? prod.C0121_Prezzo__c != compareProduct?.SalesPrice && !context.managedProductWihColli.includes(productCode) : false;
            },
            //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
            mandatory: false,
            active: false
            //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message

        },
        {
            msg: ProductNotOffered,
            validate: function(prod, limitations, trader,context){
                let productCode = prod.Product_Code__c;
                console.log('warning--prodCOde::'+JSON.stringify(productCode));
                let productLimitations =  limitations;
                console.log('warning----PL::'+JSON.stringify(productLimitations));
                let compareProduct = productLimitations?.[productCode];

                return compareProduct || trader ? false : true;
            },
            //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
            mandatory: false,
            active: true
            //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message

        },
        {
            msg: FixedLengthInMM,
            validate: function(prod, limitations, trader,context){
                let fixedLength = prod?.T0171_Lunghezza_fissa_in_mm__c;
                if(!fixedLength || fixedLength.length <= 0){
                    return false;
                }
                let converted = fixedLength/1000;
                return converted <= 1;
            },
            //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
            mandatory: false,
            active: true
            //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message
        },
        {
            msg: OrderedQtyShouldBeMultiple,
            validate: function(prod,limitations,trader,context){
                let productCode = prod.Product_Code__c;
                
                if(!context.managedProductWihColli.includes(productCode))
                    return false;

                let orderedQuantity = parseFloat(prod.C06256_Qnt_ordinata_unita_di_misura__c);
                let unitsperpackage = parseFloat(prod.UnitsPerPackage__c);
                let unitOfMeasure = context.orderUnitOfMeasure;

                return unitOfMeasure === 'NR' && orderedQuantity % unitsperpackage !== 0;
            },
            //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
            mandatory: false,
            active: true
            //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message
        },
        //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
        {
            msg: BasePriceError,
            validate: function(prod,limitations,trader,context){
                let productCode = prod?.Product_Code__c;
                let unitPrice = context.managedProductWihColli.includes(productCode) && context.businesscountry == 'FRA' ? prod?.UnitPrice : prod?.C0121_Prezzo__c;

                let compareProduct = limitations?.[productCode];

                let salesPrice = compareProduct?.SalesPrice || 0;
                let discountPerc = compareProduct?.DiscountPercentage || 0;
                let basePrice = salesPrice - (salesPrice * discountPerc/100);

                console.log('warning:: prezzo > = prezzo base');
                console.log('warning-context.managedProductWithColli:: '+JSON.stringify(context.managedProductWihColli));
                console.log('warning-context.businessCountry:: '+context.businesscountry);
                console.log('warning:: prezzo: '+unitPrice);
                console.log('warning:: base: '+basePrice);

                return unitPrice < basePrice;
            },
            mandatory: true,
            active: true
        }
        //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message

    ]
    //04-09-24 - saambrosio@deloitte.it - END:: added context to warnings + skipped PriceDifferent rule for PRODUCT: 85 + added warning for quantity based on units per package


    validation = {
        'Delivery_Period__c':{
            msg: DeliveryPeriodPastDate,
            validate: function(prod){
                let selectedDate = new Date(prod.Delivery_Period__c);
                let today = new Date();
                today.setHours(0,0,0,0);
                
                return selectedDate >= today;
            },
            onSuccess: function(){
                //do something
                return true;
            },
            onFailure: function(context){
                context.showToast('Error!',this.msg,'error');
                context.setValueOnRecordWithoutFocus('Delivery_Period__c',"");
                context.setValueOnRecordWithoutFocus('C0711_Consegna__c',"");
                return false;
            }
        }
    }

    doValidate(apiName){
        let validator = this.validation[apiName];
        if(validator){
            let msg = validator.msg;
            let result = validator.validate(this.productRecord, this);
            if(result){
                return validator.onSuccess();
            }else{
                return validator.onFailure(this);
            }
        }

    }

    @api
    get checkWarnings(){
        console.log('orderLineConfigurator.checkWarnings::')
        console.log('orderLineConfigurator.checkWarnings-limits::'+JSON.stringify(this.orderWrapper))
        let result=[];
        let anyMandatory = false;
        this.warnings.forEach(warning => {
            //15-11-2024 - saambrosio@deloitte.it - START:: added validation for base price to be greater or equal than proposed price, if lower show message
            if(!warning.active){
                return;
            }
            //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message
            let msg = warning.msg;
            console.log('warning:: '+msg);
            let validate = warning.validate(this.productRecord,this.orderWrapper, this.isTrader,this); 
            console.log('warning:: '+msg+' result::'+validate); 
            let mandatory = warning.mandatory;
            
            if(validate){
                anyMandatory = anyMandatory || mandatory;
                result.push(msg)
            }
        })

        let response = {
            result: result,
            anyMandatory: anyMandatory
        }
        
        return response;
        //15-11-2024 - saambrosio@deloitte.it - END:: added validation for base price to be greater or equal than proposed price, if lower show message
    }
}