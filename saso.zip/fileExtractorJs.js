const jsforce = require('jsforce');
const https = require('https');
const fs = require('fs');
const conn = new jsforce.Connection();
const userName = 'saambrosio@deloitte.it.lmnx';
const password = 'Salvatore99';
const securityToken = '00DE0000000JTmI!AQwAQE.5ruD2itLrgJoFOBX5wSXKdYooAV.W_uK98AbhTxR4h1TMZDuhIDe2D5rkFLy6v4rH5DnOCSjEsIGIroZC_GQqqGfy';
const fileId = '00P2S00001HvwjPUAR';
const fullFileName = './test.pdf';
var files=[];

getJson();

conn.login(userName, password, function(err, res) {
    if (err) { return console.error(err); }

    console.log(conn.accessToken);
    console.log(conn.instanceUrl);
    // logged in user property
    console.log("User ID: " + res.id);
    console.log("Org ID: " + res.organizationId);
    console.log("files "+files.length);

    files.forEach(singleFile => downloadFile(conn,singleFile));

});

function getJson(){
    fs.readFile('./prod18.json', 'utf8', (err, data) => {
        if (err) {
          console.log(`Error reading file from disk: ${err}`)
        } else {
          // parse JSON string to JSON object
          const databases = JSON.parse(data)
            files=databases;
          // print all databases
          console.log(databases[0].id);
        }
      })
}

function downloadFile(conn, singleFile) {

    //console.log('fileid '+singleFile.id);
    //console.log('fileName '+singleFile.FileName);
    //console.log('parent '+singleFile.ParentId);
    const options = {
        hostname: 'luminexcorp.my.salesforce.com',
        port: 443,
        path: '/services/data/v51.0/sobjects/Attachment/'+singleFile.id+'/body',
        method: 'GET',
        headers: {
            'Content-Type': 'application/octet-stream',
            'Authorization': 'OAuth '+conn.accessToken
        }
    }

    https.get(options, (resp) => {
        let data = '';
        console.log('file '+singleFile.ParentId)
        // A chunk of data has been received.
        resp.on('data', (chunk) => {
            console.log('chunk');
            data += chunk;

            try {
                // first check if the directory already exists
                if (!fs.existsSync('./fromProd/'+singleFile.ParentId+' - '+singleFile['Agreement Name'])) {
                  fs.mkdirSync('./fromProd/'+singleFile.ParentId+' - '+singleFile['Agreement Name'])
                  console.log('Directory is created.')
                } else {
                  console.log('Directory already exists.')
                }
              } catch (err) {
                console.log(err)
              }

            fs.appendFile('./fromProd/'+singleFile.ParentId+' - '+singleFile['Agreement Name']+'/'+singleFile.FileName, chunk, function (err) {
                if (err) throw err;
                console.log('chunk updated');
            });

        });

        // The whole response has been received. Print out the result.
        resp.on('end', () => {
            console.log('data downloaded');
        });

    }).on("error", (err) => {
        console.log("Error: " + err.message);
    });
}
