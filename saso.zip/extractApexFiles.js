const fs = require('fs');
const { XMLParser } = require('fast-xml-parser');

// Determine input file path from command-line arguments or default
const inputFilePath = process.argv[2] || 'filelist/package.xml';
const outputFilePath = 'apex_metadata.txt';

fs.readFile(inputFilePath, 'utf8', (err, xmlData) => {
    if (err) {
        console.error(`Error reading XML file: ${inputFilePath}`, err);
        return;
    }

    const parser = new XMLParser({
        ignoreAttributes: false,
        attributeNamePrefix: '@_',
        parseTagValue: true,
        parseAttributeValue: true,
        arrayMode: (tagName) => tagName === 'members' || tagName === 'types',
    });

    try {
        const result = parser.parse(xmlData);

        const packageData = result.Package;
        const apexComponents = [];

        packageData.types.forEach((type) => {
            let basePath = '';
            let extension = '';
            if (type.name === 'ApexClass') {
                basePath = 'force-app/main/default/classes/';
                extension = '.cls';
            } else if (type.name === 'ApexTrigger') {
                basePath = 'force-app/main/default/triggers/';
                extension = '.trigger';
            } else {
                return; // Skip if not ApexClass or ApexTrigger
            }

            if (Array.isArray(type.members)) {
                type.members.forEach((member) => {
                    apexComponents.push(`${basePath}${member}${extension}`);
                });
            } else if (type.members) {
                if (typeof type.members === 'string') {
                    apexComponents.push(`${basePath}${type.members}${extension}`);
                } else if (typeof type.members === 'object' && type.members['#text']) {
                    apexComponents.push(`${basePath}${type.members['#text']}${extension}`);
                }
            }
        });

        const outputContent = apexComponents.join('\n');

        fs.writeFile(outputFilePath, outputContent, 'utf8', (err) => {
            if (err) {
                console.error('Error writing to file:', err);
            } else {
                console.log(`Apex components written to ${outputFilePath}`);
            }
        });
    } catch (parseError) {
        console.error('Error parsing XML:', parseError);
    }
});